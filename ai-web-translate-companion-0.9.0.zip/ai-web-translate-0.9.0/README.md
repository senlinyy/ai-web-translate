# AI Web Translate

*Formerly Codex Web Translate.*

A Manifest V3 Chrome extension that inserts translations below original webpage text. A local native-messaging companion translates with either:

- **Claude** (Claude Opus 5.5, Sonnet 5.5, Haiku 5.5) through your own [Claude Code](https://code.claude.com) installation and sign-in — your Claude subscription, or Anthropic Console API billing if you signed in with `claude auth login --console`.
- **ChatGPT** (GPT-6 Luna, Sol, Astra) through a private Codex runtime with its own ChatGPT OAuth profile.

Pick the model in the popup or settings; models starting with `claude-` use Claude Code, the rest use Codex. No API key or hosted proxy is stored by the extension.

## Install on this Mac

1. Sign in to Claude Code once in Terminal, if you have not already (or if translation says Claude is not signed in):

   ```sh
   claude auth login
   ```

2. Install or update the companion from this checkout:

   ```sh
   npm run install:companion
   npm run doctor
   ```

   The installer moves an existing `Codex Web Translate` profile (including the ChatGPT sign-in) to `AI Web Translate`, removes the old native-host registration, and records the absolute path of `claude` (Chrome starts the companion without your shell `PATH`).

3. In `chrome://extensions`, enable **Developer mode**, then **Reload** the extension (or **Load unpacked** and select this project's `extension` folder).
4. Open **AI Web Translate**, choose a Claude model (Haiku 5.5 is fastest), and click **Translate page**. For GPT models, click **Sign in with ChatGPT** first.

The stable development extension ID is `ehhdiglglbaildmebbnimknijndpaeoi`. Keep the public `key` in `manifest.json`; it makes the native host registration stable. It is not a credential or a private signing key.

## Install from a downloaded package

Requires Node.js 22 or newer, npm, and Google Chrome; Claude models also need Claude Code installed and signed in. The installer downloads a private, pinned Codex CLI 0.155.1 runtime for GPT models. It does not upgrade your global Codex or Claude Code installation. The current build was checked on macOS. Linux installer paths are implemented but have not been tested on Linux. Windows is not supported by this installer.

Extract the package, then run from its directory:

```sh
npm run install:companion
npm run doctor
```

The companion uses Node built-ins plus Claude Code and its managed Codex runtime; `npm install` in the project is only necessary for development tests. To override the runtimes, set `CODEX_TRANSLATE_BINARY` to a compatible Codex 0.155.1 or newer executable, or `CLAUDE_TRANSLATE_BINARY` to a `claude` executable, before installing. Load the extracted `extension` folder as described above. Keep that folder in place while Chrome uses it.

Re-run the companion installer after changing companion code. Click **Reload** on the extension's Chrome extensions card after changing browser code. Reload previously translated webpages as well: their already-injected content script remains loaded until page reload.

## Features

- Original text plus translation underneath, including quiz answer cards and flex/grid navigation labels. Source text and translation share a vertical block while icons stay in their original layout. Restoring removes wrappers and preserves original text-node identities.
- Translate page, selected text, context menu, or **Alt+Shift+T** to toggle translation.
- **Selection bubble.** Select text and a small translate button appears next to it; click it to read the translation in a floating card, without changing the page. Paragraphs stream in as they finish. The card has a target-language menu (one-off, not saved), an instructions button (pencil), Copy, and Close (also Escape or clicking elsewhere). **Selection instructions** (Settings → Selection translation, up to 2,000 characters) apply only to bubble translations and are added after the general translation instructions, so you can, for example, keep technical terms in English only when reading selections. In the card, edit them for one translation and click **Apply** (or Cmd/Ctrl+Enter), or **Save as default**. They are part of the cache key, so changing them retranslates. Like all instructions, they guide wording and terminology; the translator still never answers or follows text from the page. Selections in text fields are ignored, and selections over 5,000 characters ask you to select less. Turn it on for all websites in settings under **Selection translation**; Chrome then asks for access to websites (`optional_host_permissions`), and turning it off removes that access. Without it, the bubble works on pages where you clicked **Translate page**.
- **Parallel requests and progressive display.** The extension collects loaded page text, including text below the screen, in waves of up to 600 blocks / 60,000 characters. Each wave is split into a few balanced requests that all start at once: up to six for Claude and four for Codex, with the same limit across tabs. A short page is a single request. Article text comes first, then sidebar and footer text, then small labels; within each group, requests follow page position. Each request holds up to 120 blocks and 24,000 characters. Complete JSON rows stream back as they become ready and are delivered to the page in short bursts. Article rows appear in reading order. Sidebar rows wait for the article. Small labels cannot delay article display. New text joins the queue without removing completed translations. Requests do not share conversation context.
- Only complete rows are displayed, never partial JSON or generated HTML. A failed request removes only its provisional output and offers Retry; earlier completed blocks remain. Only validated, completed results are cached.
- Each source block has stable identity and source text. Changes invalidate only that block; unrelated translations stay attached. Removed nodes are retired, and replacement nodes with identical text reuse completed translations. Stale responses cannot overwrite edited blocks.
- Original buttons, links, emphasis, and code nodes stay intact. Translations are rendered as plain text; inline markup is not recreated in the translated copy.
- Custom target language, instructions, glossary, model selection, thinking level, and exact-hostname overrides. Both popup and settings expose model/thinking controls. The default remains **GPT-6 Luna** with **Low** thinking; Claude models offer Low through Maximum. Model default omits an explicit effort. Available effort options follow model capabilities; switching models resets unsupported efforts.
- Older saved empty/account-default model settings now resolve to Luna. Explicit model choices remain unchanged. Model and reasoning effort are included in cache keys, so Claude and GPT translations are cached separately.
- Global preferences in the popup; when a site override exists, its language is shown and edited instead.
- Repeated clicks reuse an in-flight page request. Cancellation, stale-response rejection, pause-on-error with explicit retry, and account limit display remain supported.
- **Persistent exact-page cache** in IndexedDB: the same URL, ordered source text, and translation settings reuse a complete result with zero model calls, even after browser restart. A SHA-256 key includes target language, model, effort, custom instructions, glossary, scope, and translator format version. Fragment identifiers are ignored. An additional individual-block cache reuses unchanged text even when a page adds, removes, or reorders other blocks. Only new source text is sent to the model. Block keys include the same URL and translation settings, so changing instructions, glossary, language, model, or thinking level invalidates reuse.
- **Refresh** in the popup or page toolbar bypasses the cache. **Clear translation cache** in settings deletes saved results. The cache expires after 30 days and is limited to 200 page snapshots / 20 MB plus 5,000 individual blocks / 20 MB, with least-recently-used eviction.
- Large documents are processed in bounded waves of at most 600 blocks / 60,000 source characters. The page itself has no whole-document block cap. Scrolling discovers new text without resetting completed blocks.
- Local ChatGPT sign-in, token refresh managed by Codex, and sign-out. Claude sign-in is managed by Claude Code (`claude auth login` / `claude auth logout`); the settings page shows its current state.

Changes to instructions, glossary, language, model, or thinking level take effect on the next translation run. Click **Show original**, then translate again. Per-site settings override global settings for that exact hostname.

## Privacy and execution boundaries

- Translation starts on an explicit action, using `activeTab`. The extension asks for access to all websites only if you turn on the selection bubble in settings, and removes it when you turn it off. Even then, text is sent for translation only when you click the bubble.
- Page text is sent to Anthropic via Claude Code (Claude models) or to OpenAI via the local Codex runtime (GPT models). Treat manually translated private pages accordingly.
- Passwords, editable inputs, hidden nodes, code blocks, and `translate="no"` content are excluded from automatic page extraction.
- Source text and translation instructions are passed separately. Instructions found on a webpage are translation data, not commands.
- Chrome uses native messaging. The companion accepts only the registered extension origin and a small list of translation/account operations. There is no general HTTP server or arbitrary command endpoint.
- Claude Code runs headless (`claude -p`) for each request in an empty private workspace with no tools (`--tools ""`), no MCP servers, no skills or slash commands, no user/project settings or hooks (`--setting-sources ""`), no saved session, and a translation-only system prompt. Its environment is limited to `HOME`, `USER`, `PATH`, `TMPDIR`, and `LANG`, so shell API keys and session variables are not inherited; it uses your stored Claude Code login. Its logs are never forwarded to Chrome.
- Codex uses a dedicated profile, an empty workspace, disabled shell/browser/plugin/app features, read-only restricted turn permissions, and rejected model-initiated approvals. Coding configuration, plugins, and API-key environment variables are not inherited.
- The dedicated profile stores OAuth credentials using Codex's file-backed credential store inside a private application-support directory. Tokens are never returned to content scripts or stored in Chrome. Signing out affects this profile only.
- Translation threads are ephemeral. Cache entries are stored in IndexedDB on this device, persist across worker/browser restarts, expire after 30 days, and are cleared on sign-out or with Clear translation cache. Cached translations can contain private page content. The original source text and URL are represented by a hash rather than stored with the translated blocks. Local runtime diagnostic/state files may still exist; ephemeral threads are not a promise of zero provider-side retention.

## Local files

On macOS:

- Companion and profile: `~/Library/Application Support/AI Web Translate/`
- Chrome native registration: `~/Library/Application Support/Google/Chrome/NativeMessagingHosts/com.ai_web_translate.host.json`

The installer records the absolute Node path, the private Codex runtime path, and the `claude` launcher path. Reinstall after moving or uninstalling Node. An extension reload is required after a companion update so Chrome restarts the native connection with the updated runtime.

To remove: sign out in settings, remove the Chrome extension, then remove the two paths above if you also want to delete this companion and its profile. Neither installation nor removal changes your normal `~/.codex` profile or your Claude Code login.

## Development and verification

```sh
npm ci
npx playwright install chromium
npm run check
npm test
npm run test:browser
npm run test:layout
npm run test:incremental
npm run test:reading-order
npm run test:article-priority
npm run test:cache
npm run test:extension
npm run test:popup
npm run doctor -- --translate
npm run benchmark:page
npm run package
```

- Unit tests exercise Claude Code invocation (headless flags, no inherited API keys, sign-in errors, code fences, retried messages) with a simulated `claude` CLI, framing, streamed JSON boundaries, independent parallel progress, concurrency limits, cancellation, request/output validation, event ordering, and rejecting tool approvals using a simulated Codex process.
- Browser tests exercise real DOM rendering with fixed translation responses. They are not evidence of live model translation quality.
- Extension tests load the actual extension in an isolated Chrome for Testing profile, connect to the installed native host and real Codex runtime, and verify settings through reloads. They do not modify your normal Chrome preferences.
- `doctor -- --translate` makes one real GPT-6 Luna request and one real Claude request (Haiku 5.5 by default; pass `--claude-model=claude-opus-5-5` to change it), after you sign in. A plain `doctor` only reads connection/account/model state.
- `test:cache` verifies persistence through a full browser restart, cache invalidation, duplicate requests, cancellation, refresh, clearing during a request, expiry, and size limits using real IndexedDB.
- `benchmark:page` makes parallel streamed Luna requests using the public quiz fixture, then repeats from cache. It writes timings and model-call counts to `artifacts/stream-benchmark.json`. This is a small sample, not a general latency guarantee.
- Screenshots are written to `artifacts/`. The bilingual quiz screenshot uses fixed test translations.

## Current limitations

The first version targets ordinary HTML pages. Chrome internal pages, Chrome Web Store pages, PDFs, image text/OCR, embedded frames, closed shadow roots, and canvas-rendered text are unsupported. Some unusual layouts may need site-specific extraction rules. Rich markup is preserved in the original, not reconstructed in the translation. Automatic page translation is opt-in per page; automatic per-site activation is not implemented. No Chrome Web Store publication or signed native installer is included.

Versions 0.2 and 0.3 were also checked with a real OAuth-authenticated Luna translation at Low thinking. Automated browser screenshots use fixed translation responses; they are layout evidence, not measurements of model quality. The layout regression fails against version 0.1 and passes against version 0.2.

## Documentation

- [Codex app-server and managed ChatGPT authentication](https://learn.chatgpt.com/docs/app-server)
- [Chrome native messaging](https://developer.chrome.com/docs/extensions/develop/concepts/native-messaging)

## Version 0.3 verification sample

The bundled quiz fixture contained 12 extracted blocks (852 source characters). A live Luna / Low request translated the full snapshot with one model call in 13.9 seconds. Repeating it loaded the cached translation in 27 milliseconds with zero additional model calls. These numbers are from one local run; first-request latency varies with page length and service load. Cache persistence across a full browser restart was verified separately with controlled responses.

## Version 0.4 verification sample

The same 12-block, 852-character quiz used two concurrent Luna / Low threads. The first translated text appeared in 5.2 seconds, the full page finished in 11.0 seconds, and the cached repeat took 6 milliseconds with zero new model calls. This is one local sample, not a controlled comparison or latency guarantee. Large pages can use three concurrent threads; provider limits and the earliest unfinished block can delay ordered display.

## Version 0.5 incremental lifecycle

The previous whole-page fingerprint was an invalidation boundary: one lazy-loaded card cancelled the request, cleared translations, and sent the entire page again. The content script now reconciles individual block records with states for pending, provisional, and completed output. Existing hosts stay in the DOM when unrelated content changes. Only new or changed blocks enter the next request, and the persistent block cache supports reuse across page compositions and browser restarts. Scroll events never cancel an active request. Explicit Original, Refresh, or changed translation settings still start a new session.

`test:incremental` reproduces a news feed growing from 193 to 206 blocks during streaming and verifies stable translation-node identity, no cancellation, exactly 13 additional source blocks sent, one edited headline retranslated, and identical replacement nodes reused. This is a controlled news-page regression, not a claim of live WSJ verification.

## Version 0.5.1 visible reading order

HTML traversal order is not necessarily visual reading order. Off-canvas menus, transparent containers, and clipped content are excluded. Source ranges are sorted by viewport priority and screen coordinates before batching. Completed rows no longer wait behind a missing earlier row in either the background worker or content script. Existing translations still remain attached. A regression fixture places 66 invisible menu labels and a footer before the visible headlines in HTML, and verifies the visible headlines are sent first and appear during streaming even when the first block is delayed. Live WSJ browser access was unavailable in this session, so this is controlled reproduction coverage, not a live-site verification claim.

## Version 0.5.2 popup responsiveness

The popup has its default controls in static HTML and defers module initialization until after the browser has a paint opportunity. Saved preferences load in parallel with the tab lookup; connection discovery runs independently. Controls wait for preferences before accepting edits, and translation actions wait before submitting, preventing accidental use of defaults. The settings link remains responsive while services are pending. Page scans reuse geometry and style reads within each scan and schedule mutation/scroll rescans during browser idle time (with a bounded timeout).

`test:popup` measures first contentful paint with two-second preference/tab delays and a companion that never responds, checks the settings link during that delay, and verifies saved values subsequently appear. This measures popup document rendering, not the native Chrome toolbar click-to-window latency on the user's machine.

## Version 0.5.3 action-popup load boundary

The previous first-paint test did not measure Chrome's action-window opening. Chromium's `ExtensionPopup::DocumentOnLoadCompletedInPrimaryMainFrame` calls `ShowBubble`, so imports started from requestAnimationFrame could still run before the window-show boundary. The popup now embeds its stylesheet (generated from `popup.template.html` and `ui.css` by `npm run build:popup`) and starts imports from a task scheduled after the window load event. There are no native/account/settings requests in the initial-load bootstrap.

`npm run test:action-popup` loads the actual extension into an isolated Chrome profile, calls `chrome.action.openPopup`, checks the real popup target and document, and closes/reopens it alongside a minimal static control. Its report is `artifacts/action-popup-timing.json`. The verification run measured 368 ms on the first opening and 41–45 ms on repeat openings; document load itself took 76 ms first and 21–22 ms thereafter. These are isolated Chrome API-to-window timings, not mouse-click measurements in the user's existing Chrome profile. A separate delayed-service test verifies that saved settings and an unresponsive companion cannot hold the document open.

Popup HTML is generated; edit `popup.template.html` or `ui.css`, then run the build. Checks and packaging regenerate it automatically.

Source: [Chromium extension-popup window lifecycle](https://chromium.googlesource.com/chromium/src/+/main/chrome/browser/ui/views/extensions/extension_popup.cc).

## Version 0.5.4 first-opening scope

Opening the popup now makes **zero runtime messages**: no automatic status request, model discovery, native-host launch, or Codex startup. It reads saved settings and a cached model catalog locally. A cached sign-in observation is explicitly labeled “last checked”; it is not a live connection claim. Use Check connection for current status/sign-in, or Translate to start the companion when needed. Options retains explicit account/model discovery. This removes companion startup from the first-opening path rather than optimizing only repeat openings.

The old action-popup test invoked an already-running worker, and Playwright disabled background-renderer throttling by default. Those timings did not prove cold-click behavior. `npm run benchmark:cold-popup` now waits two minutes in fresh isolated browser processes, stops extension workers, restores normal background-throttling defaults, and triggers the browser action without evaluating the extension worker. It compares the translator with a no-worker, no-permission static control. Debugger observation and headless execution still make it different from a physical toolbar click in the user's existing profile; a fast result is not proof that their reported delay is resolved. Reports are saved under `artifacts/cold-popup-timing.json`.

The reported browser-wide workaround was investigated but is **not recommended or applied**: the user reports only this extension is slow, and the isolated experiment did not establish that workaround as helpful. The installed Chrome configuration remains unchanged.

The v0.5.4 two-minute-idle run measured 522 ms to observed visibility for the translator and 390 ms for the minimal control. The prior run measured 483 ms and 342 ms respectively. These single-run results do **not** demonstrate a cold-start latency improvement, and do not reproduce the user's two-second delay. Zero automatic companion requests is verified as a lifecycle change; the reported user-profile delay remains unresolved.

## Keyboard shortcut

Press **Option + Shift + T** on macOS, or **Alt + Shift + T** on Windows/Linux, to translate the active webpage without opening the popup. Press it again to restore the original. Chrome can leave a conflicting shortcut unassigned. The popup and settings now show Chrome's actual assignment; click the shortcut control to open Chrome's extension-shortcut configuration and choose another combination.

Development constraint: use only the bundled isolated Chromium test browser. Do not run installed Google Chrome for testing. The cold-popup issue remains unresolved; this release adds shortcut discoverability, not a claimed cold-start fix.


## Interface language and glossary examples

The interface defaults to **中文**. Use the language selector at the top of the popup or settings page to switch to **EN**. This preference is saved separately from translation language, model, instructions, glossary, and website overrides. Switching the interface language does not invalidate translation caches. Open translation toolbars also update when the language changes.

Settings → **自定义快捷键 / Configure shortcut** opens Chrome’s shortcut editor. Find **AI Web Translate**, click the pencil, and press your preferred key combination. Chrome controls assignment and conflicts; the extension refreshes its displayed assignment when you return.

The empty glossary shows LLM examples: large language model (LLM), context window, retrieval-augmented generation (RAG), and fine-tuning. These are placeholders only and are not saved or sent to the model unless entered by the user.

`npm run test:interface` verifies Chinese defaults, English persistence, unsaved-form preservation, stable translation settings, glossary placeholders, and shortcut configuration using isolated bundled Chromium.


## Version 0.6.1 ordered display

Version 0.5.1 deliberately displayed any ready row. That reduced waiting but allowed a fast sidebar batch to appear before the article headline. Version 0.6.1 retains concurrent workers and streamed results, but buffers later rows in the content script until preceding blocks in the wave are complete. The wave order stays fixed as translations shift layout or the reader scrolls. Removed or edited source records are skipped rather than blocking the queue. Existing rendered translations remain in place as new content is discovered.

The reading-order regression first reproduced the premature sidebar display, then passed with the fix: the sidebar and footer stay buffered; releasing the first headline shows the first two blocks before the full request finishes. These are isolated Chromium fixture checks, not a live WSJ verification.


## Version 0.6.2 compact navigation

Short labels in semantic navigation, sidebar links/buttons, and recognized media-control containers use hover tooltips instead of inserted paragraphs. This preserves fixed-height bars and narrow icon/label rows. Short controls already containing both Latin and Chinese text are left unchanged. Article text keeps stacked translations. Showing the original restores pre-existing tooltips without overwriting a title changed by the site. `npm run test:compact-ui` covers dimensions, bilingual labels, article rendering, and restoration in an isolated browser fixture; live WSJ was not inspected.


## Version 0.6.3 page-wide reading order

The previous viewport priority put visible text first, below-screen text second, and above-screen text last. Starting translation while scrolled down could therefore translate a later paragraph before the introduction, despite ordering results within each wave. This version removes that priority. It also routes reuse from the in-memory text cache and completed waves through the same page-wide reveal check, so newly inserted earlier text can hold later pending results. Already rendered translations remain attached. Progress counts rendered blocks rather than buffered cache hits.

`npm run test:reading-order` starts scrolled down and checks request/reveal order. `npm run test:page-order` covers reused text below unfinished content and source inserted while a request is running. These are controlled isolated Chromium regressions, not live WSJ verification.


## Version 0.7.0 GPT-6 models

The popup and settings offer GPT-6 Luna (default), GPT-6 Sol, and GPT-6 Astra before contacting the companion. Live Codex model discovery can add other available models and overrides the bootstrap thinking levels. The bootstrap follows the local Codex catalog: Luna supports Low through Max; Sol/Astra also expose Ultra. Translation still disables tools and delegation.

Saved GPT-5.6 Luna and Sol selections, including website overrides, resolve to the corresponding GPT-6 model. Unsupported None/Minimal thinking on those migrated selections becomes Low; other models and preferences are preserved. Model-specific cache keys keep old-model translations separate. The popup does not make automatic companion requests.


## Version 0.7.1 YouTube watch pages

On YouTube watch pages, translate the video title, description, comments, and recommendation titles only. Leave player controls, metadata, buttons, badges, and comment actions untouched. The description translation sits after the collapsed preview, outside its overflow clipping. Recommendation titles use compact hover translations so thumbnails and metadata keep their layout. New comments are discovered without resetting earlier translations. Selection-only translation still works on selected text.

`npm run test:youtube` reproduces a YouTube watch layout and checks translated content, source exclusions, fixed controls, the clipped description, dynamic comments, and exact restoration. An isolated Chromium read of the public 3Blue1Brown video also confirmed the current YouTube elements: 22 source blocks on first load, then 20 comment translations after scrolling, with no translation blocks in the video action controls. The public page displayed a YouTube consent overlay in that isolated session, so it did not provide an unobstructed visual check of the full page.

## Version 0.8.0 article priority and shared label requests

The extension now gives article text priority. It keeps the title and paragraphs in reading order. Menu labels cannot stop article output from appearing. Sidebar text has its own order and appears after the article is ready. Short labels can appear as soon as their results arrive. Existing translations stay in place when new text loads.

Request size now depends on text length and JSON overhead. The previous limit of four blocks, then eight blocks, created many small requests. The new limit allows up to 80 blocks per request. Each block keeps its ID, so grouped results return to the correct source element. The model also receives an instruction to preserve source order.

`npm run test:article-priority` uses an isolated Chromium fixture with an article, a sidebar, and 100 menu labels. It verifies three concurrent article requests, article display before label completion, ordered paragraphs, correct output placement when provider rows arrive in reverse order, new text without resets, and restoration. The 100 labels use two requests. The previous rule required thirteen. This count is a controlled test result. It does not measure live model latency. `artifacts/batch-planning.json` records the count.

A separate live GPT-6 Luna / Low check translated 80 labels in one request. It streamed all 80 complete rows in source order. The first row arrived in 3.7 seconds, and the request finished in 20.7 seconds. This single run checks support for a larger request. It does not prove a speed increase against the previous version. `artifacts/large-label-batch-live.json` records the result.


## Version 0.9.0 Claude support, rename, and faster page translation

The extension is now **AI Web Translate**. Claude Opus 5.5, Sonnet 5.5, and Haiku 5.5 appear in the model menu and run through your local Claude Code sign-in. The native host is now `com.ai_web_translate.host`; the installer migrates the old profile and registration.

Why pages felt slow: version 0.8 split each page into many requests of about 6,000 characters (the first only 1,600) and ran at most three at a time, so a long article needed several rounds, each paying the model's start-up cost. Since rows display in reading order, later requests that finished early still waited. Every Codex request also made an extra sign-in round trip, and every streamed row was a separate message to the page that re-measured the layout of every block.

Changes:

- A wave is split into at most four (Codex) or six (Claude) balanced requests that all start at the same time, so the whole page finishes in about one request's time. A short page is one request.
- Sign-in is checked once and reused for ten minutes instead of before every request.
- Streamed rows reach the page in 40 ms bursts instead of one message per row.

`npm test` covers the new planning (balanced sizes, block limits, provider concurrency) and the Claude runtime. `npm run test:article-priority` verifies a 100-label article page is one wave of four parallel requests while article order still holds. These are controlled fixtures.

A live check on Claude Haiku 5.5 / Low (Claude Max subscription, Claude Code 2.1.123) translated 40 article paragraphs (16,581 characters). One request for the whole page showed its first row after 4.9 s and finished in 19.6 s. The 0.9.0 plan sent six parallel requests: first row after 1.9 s, done in 5.4 s. A two-sentence sample finished in 1.3 s. This is one local run, recorded in `artifacts/claude-benchmark.json`, not a latency guarantee.

Claude Opus 5.5 and other newer models need Claude Code 2.1.280 or newer; older versions report "Run \"claude update\"" in the extension.

### Scrolling panels (app-shell pages)

Many web apps keep the window fixed and scroll an inner panel instead. Earlier versions treated text outside a scrolling panel's current view as hidden. Each rescan then removed translations for paragraphs scrolled out of view, discarded streamed results for them, and re-requested them later. Each request also contained only one screen of text. A clipping frame around the panel (`overflow: hidden`) hid the same text again.

Text inside a scroll container now counts as reachable. Outer clipping frames judge it by the container's box, and only `overflow: hidden`/`clip` or a collapsed container hides text. A block missing from one scan stays translated unless its text changed, it was removed, or it was regrouped. Scroll events from inner panels also trigger discovery of new text.

`npm run test:scroll-container` reproduces the layout: a fixed shell, an `overflow: hidden` frame, and a scrolling panel with 41 blocks. Before the fix only 10 blocks were sent. Now all 41 go in one wave, scrolling mid-request keeps finished and streamed translations, and nothing is re-requested or cancelled. Text clipped by `overflow: hidden` stays excluded. On a local DevPolaris roadmap article (25,000 px panel), the fixed script sent 256 blocks / 29,787 characters in one request. The 25 translations shown before scrolling survived scrolling to the bottom and back, and all 256 rendered with no cancellations. That check used recorded test responses, not a live model.


### Selection bubble

`npm run test:selection` checks the bubble in isolated Chromium with fixed responses. It covers: no request until the bubble is clicked, the selection is kept, paragraphs stream into the card in the saved language, the language menu retranslates, saved selection instructions are sent and one-off edits apply without changing the default until Save as default, Copy, Escape and outside clicks close the card and hide the bubble, text fields and over-long selections are skipped, and page text is unchanged. On the local DevPolaris roadmap article, a real mouse selection showed the bubble beside the site's own highlight toolbar, and the card opened below the selection. `npm run test:extension` (real extension, installed companion) loads the new manifest and settings page and shows both Codex and Claude connected. It now picks any discovered Codex model without Max thinking, since `gpt-5.5` is no longer in the live catalog.

## Chrome Web Store

`store/PUBLISHING.md` is the step-by-step checklist. `npm run package:store` builds the upload zip (`artifacts/store/`) without the development `key`. `npm run store:assets` renders the icons, screenshots and promo tiles. `store/LISTING.md` has the listing text, privacy-tab answers and reviewer notes, and `store/privacy-policy.html` is the policy page to host. The store assigns its own extension ID: put it in `store/extension-id.txt` and re-run `npm run install:companion` (and `npm run package` for the user download) so the companion accepts both the development and the store build.
