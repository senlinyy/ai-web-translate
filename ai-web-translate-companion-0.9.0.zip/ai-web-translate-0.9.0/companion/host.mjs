import { RequestPool } from './stream.mjs';
import { readFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { CodexRuntime } from './runtime.mjs';
import { ClaudeRuntime } from './claude-runtime.mjs';
import { FrameDecoder, encodeFrame, providerOf, validateTranslation } from './protocol.mjs';

const settings = JSON.parse(await readFile(join(dirname(fileURLToPath(import.meta.url)), 'install.json'), 'utf8'));
// Accept only the registered extensions: the development build and, once published, the Chrome Web Store build.
const allowed = (settings.extensionIds || [settings.extensionId]).map(id => `chrome-extension://${id}/`);
if (!allowed.includes(process.argv[2])) process.exit(1);
const runtime = new CodexRuntime(settings);
const claude = new ClaudeRuntime({ binary: settings.claudeBinary, profile: settings.profile });
const write = value => process.stdout.write(encodeFrame(value));
// Each Claude request is its own process; Codex shares one app-server, so it gets fewer slots.
const jobs = new Map(); const pools = { codex: new RequestPool(4), claude: new RequestPool(6) };
runtime.on('notification', ({ method, params }) => {
  if (method === 'account/login/completed') write({ event: 'login', success: params.success, error: params.success ? null : 'Sign-in did not complete. Please try again.' });
});
async function handle(message) {
  const { id, method, params = {} } = message || {};
  if (typeof id !== 'string' || id.length > 100) return;
  try {
    let result;
    switch (method) {
      case 'status': result = params.provider === 'claude' ? await claude.status() : await runtime.status(); break;
      case 'login':
        await runtime.start(); result = await runtime.request('account/login/start', { type: 'chatgpt' }); break;
      case 'loginCancel':
        if (typeof params.loginId !== 'string') throw new Error('Invalid login ID.');
        await runtime.start(); result = await runtime.request('account/login/cancel', { loginId: params.loginId }); break;
      case 'logout':
        for (const job of jobs.values()) job.abort();
        await runtime.start(); result = await runtime.request('account/logout'); runtime.checked = null; break;
      case 'models':
        await runtime.start(); result = await runtime.request('model/list', { includeHidden: false }); break;
      case 'limits':
        await runtime.start(); result = await runtime.request('account/rateLimits/read'); break;
      case 'cancel': jobs.get(params.requestId)?.abort(); result = {}; break;
      case 'translate': {
        const input = validateTranslation(params);
        if (jobs.size >= 24 || jobs.has(id)) throw new Error('Translation queue is full. Try again shortly.');
        const controller = new AbortController(); jobs.set(id, controller);
        const provider = providerOf(input.model), engine = provider === 'claude' ? claude : runtime;
        try { result = await pools[provider].run(controller.signal, () => engine.translate(input, controller.signal,
          translation => { if (!controller.signal.aborted) write({ id, event: 'translationProgress', translation }); })); }
        finally { jobs.delete(id); }
        break;
      }
      default: throw new Error('Unknown companion operation.');
    }
    write({ id, result });
  } catch (error) { write({ id, error: error.name === 'AbortError' ? 'Translation cancelled.' : error.message }); }
}
const decoder = new FrameDecoder(message => { handle(message).catch(() => process.exit(1)); });
process.stdin.on('data', chunk => { try { decoder.push(chunk); } catch { process.exitCode = 1; process.stdin.destroy(); runtime.close(); } });
process.stdin.on('end', () => { runtime.close(); process.exit(0); });
process.on('SIGTERM', () => { runtime.close(); process.exit(0); });
