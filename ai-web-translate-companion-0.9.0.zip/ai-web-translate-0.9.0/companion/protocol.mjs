export const HOST_NAME = 'com.ai_web_translate.host';
export const LEGACY_HOST_NAME = 'com.codex_web_translate.host';
// Claude models run through the local Claude Code CLI; everything else through Codex.
export const providerOf = model => /^claude-/.test(model) ? 'claude' : 'codex';
export const MAX_FRAME = 512 * 1024;
export function encodeFrame(value) {
  const body = Buffer.from(JSON.stringify(value));
  if (body.length > MAX_FRAME) throw new Error('Message is too large.');
  const header = Buffer.alloc(4); header.writeUInt32LE(body.length);
  return Buffer.concat([header, body]);
}
export class FrameDecoder {
  buffer = Buffer.alloc(0);
  constructor(onMessage) { this.onMessage = onMessage; }
  push(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    while (this.buffer.length >= 4) {
      const size = this.buffer.readUInt32LE(0);
      if (!size || size > MAX_FRAME) throw new Error('Invalid native message size.');
      if (this.buffer.length < size + 4) return;
      const message = JSON.parse(this.buffer.subarray(4, size + 4).toString('utf8'));
      this.buffer = this.buffer.subarray(size + 4);
      this.onMessage(message);
    }
  }
}
export function validateTranslation(value) {
  if (!value || !Array.isArray(value.blocks) || !value.blocks.length || value.blocks.length > 600) throw new Error('Send between 1 and 600 text blocks; select a section for larger pages.');
  const ids = new Set(); let total = 0;
  const blocks = value.blocks.map(b => {
    if (!b || typeof b.id !== 'string' || !/^[a-zA-Z0-9_-]{1,80}$/.test(b.id) || ids.has(b.id)) throw new Error('Invalid or duplicate block ID.');
    if (typeof b.text !== 'string' || !b.text.trim() || b.text.length > 6000) throw new Error('Invalid text block.');
    ids.add(b.id); total += b.text.length; return { id: b.id, text: b.text };
  });
  if (total > 60000) throw new Error('This page is too large for one translation request. Select a section instead.');
  const string = (key, fallback, max) => {
    const result = value[key] ?? fallback;
    if (typeof result !== 'string' || result.length > max) throw new Error(`Invalid ${key}.`);
    return result;
  };
  const language = string('language', 'Simplified Chinese', 80).trim();
  if (!language) throw new Error('Choose a target language.');
  const effort = string('effort', 'low', 20);
  if (!['', 'none', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max', 'ultra'].includes(effort)) throw new Error('Invalid thinking level.');
  return { blocks, language, effort, instructions: string('instructions', '', 8000), glossary: string('glossary', '', 8000), model: string('model', 'gpt-6-luna', 100) || 'gpt-6-luna' };
}
// Claude has no output schema here, so tolerate a Markdown code fence around the JSON.
export const stripFence = text => text.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
export function validateOutput(text, blocks) {
  let value;
  try { value = JSON.parse(stripFence(text)); } catch { throw new Error('The model returned malformed output. Try again.'); }
  if (!Array.isArray(value.translations) || value.translations.length !== blocks.length) throw new Error('The model returned an incomplete translation. Try again.');
  const remaining = new Set(blocks.map(b => b.id));
  for (const row of value.translations) {
    if (!row || !remaining.delete(row.id) || typeof row.text !== 'string' || !row.text.trim() || row.text.length > 24000) throw new Error('The model returned invalid translation blocks.');
  }
  return value.translations;
}
export function outputSchema(blocks) {
  return { type: 'object', additionalProperties: false, required: ['translations'], properties: {
    translations: { type: 'array', minItems: blocks.length, maxItems: blocks.length, items: {
      type: 'object', additionalProperties: false, required: ['id', 'text'], properties: {
        id: { type: 'string', enum: blocks.map(b => b.id) }, text: { type: 'string' }
      }
    } }
  } };
}
