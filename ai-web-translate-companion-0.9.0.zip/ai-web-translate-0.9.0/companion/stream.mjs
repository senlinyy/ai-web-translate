// Decode complete translation rows only; JSON strings may cross arbitrary token boundaries.
export class TranslationStream {
  constructor(blocks, emit) { this.ids = new Set(blocks.map(b => b.id)); this.emit = emit; this.buffer = ''; this.started = false; this.seen = new Map(); this.replay = false; }
  // A retried model message starts over; identical rows already emitted are skipped.
  reset() { this.buffer = ''; this.started = false; this.replay = true; }
  push(delta) {
    this.buffer += delta;
    if (this.buffer.length > 2_000_000) throw new Error('Translation stream is too large.');
    if (!this.started) {
      const match = /^\s*(?:```(?:json)?\s*)?\{\s*"translations"\s*:\s*\[/i.exec(this.buffer);
      if (!match) return;
      this.buffer = this.buffer.slice(match[0].length); this.started = true;
    }
    while (true) {
      this.buffer = this.buffer.replace(/^[\s,]+/, '');
      if (!this.buffer.startsWith('{')) return;
      let depth = 0, quoted = false, escaped = false, end = -1;
      for (let i = 0; i < this.buffer.length; i++) {
        const ch = this.buffer[i];
        if (quoted) { if (escaped) escaped = false; else if (ch === '\\') escaped = true; else if (ch === '"') quoted = false; }
        else if (ch === '"') quoted = true;
        else if (ch === '{') depth++;
        else if (ch === '}' && --depth === 0) { end = i + 1; break; }
      }
      if (end < 0) return;
      const row = JSON.parse(this.buffer.slice(0, end)); this.buffer = this.buffer.slice(end);
      if (this.replay && this.seen.get(row?.id) === row?.text) continue;
      if (!this.ids.has(row.id) || typeof row.text !== 'string' || !row.text.trim() || row.text.length > 24000 || this.seen.has(row.id)) throw new Error('Invalid streamed translation.');
      this.seen.set(row.id, row.text); this.emit?.(row);
    }
  }
}

export class RequestPool {
  constructor(limit = 3) { this.limit = limit; this.active = 0; this.waiting = []; }
  async run(signal, work) {
    signal.throwIfAborted();
    await new Promise((resolve, reject) => {
      const entry = { start: () => { signal.removeEventListener('abort', abort); this.active++; resolve(); } };
      const abort = () => { this.waiting = this.waiting.filter(item => item !== entry); reject(signal.reason); };
      if (this.active < this.limit) entry.start();
      else { this.waiting.push(entry); signal.addEventListener('abort', abort, { once: true }); }
    });
    try { signal.throwIfAborted(); return await work(); }
    finally { this.active--; this.waiting.shift()?.start(); }
  }
}
