import { readSettings, normalizeSettings, withSelectionInstructions } from './settings.js';
import { PageCache } from './page-cache.js';
import { PageTranslations } from './page-translations.js';
const HOST = 'com.ai_web_translate.host';
let port; const pending = new Map();
function connect() {
  if (port) return port;
  const current = port = chrome.runtime.connectNative(HOST);
  current.onMessage.addListener(message => {
    if (message.event === 'translationProgress') { const task = pending.get(message.id); try { task?.onProgress?.(message.translation); } catch (error) { task?.reject(error); } return; }
    if (message.event) { chrome.runtime.sendMessage({ type: 'accountEvent', ...message }).catch(() => {}); return; }
    const task = pending.get(message.id); if (!task) return;
    pending.delete(message.id); clearTimeout(task.timer);
    if (!message.error && task.method === 'status') chrome.storage.session.set({ [`popupConnection:${message.result?.provider || 'codex'}`]: message.result }).catch(() => {});
    if (!message.error && task.method === 'models') chrome.storage.local.set({ modelCatalog: message.result }).catch(() => {});
    message.error ? task.reject(new Error(message.error)) : task.resolve(message.result);
  });
  current.onDisconnect.addListener(() => {
    const error = chrome.runtime.lastError?.message || 'Companion disconnected.';
    if (port === current) port = null;
    for (const task of pending.values()) { clearTimeout(task.timer); task.reject(new Error(`${error} Run the companion installer, then reconnect.`)); }
    pending.clear();
  });
  return current;
}
function native(method, params = {}, id = crypto.randomUUID(), onProgress) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { pending.delete(id); if (method === 'translate') port?.postMessage({ id: crypto.randomUUID(), method: 'cancel', params: { requestId: id } }); reject(new Error('The companion took too long. Retry or reconnect.')); }, method === 'translate' ? 300000 : 40000);
    pending.set(id, { resolve, reject, timer, onProgress, method });
    try { connect().postMessage({ id, method, params }); }
    catch (error) { clearTimeout(timer); pending.delete(id); reject(error); }
  });
}
const pageTranslations = new PageTranslations(new PageCache(), async (input, signal, onProgress) => {
  const id = crypto.randomUUID();
  const cancel = () => native('cancel', { requestId: id }).catch(() => {});
  signal.throwIfAborted(); signal.addEventListener('abort', cancel, { once: true });
  try { return await native('translate', input, id, onProgress); }
  finally { signal.removeEventListener('abort', cancel); }
}, new PageCache({ name: 'codex-block-translations', maxEntries: 5000 }));
async function cancelTab(tabId) {
  pageTranslations.cancel(tabId); pageTranslations.cancel(`selection:${tabId}`);
}
// The selection bubble runs on every site only after the user grants optional host access in settings.
const SITES = ['http://*/*', 'https://*/*'];
async function syncSelectionScript() {
  const [{ selectionBubble = false }, granted, registered] = await Promise.all([
    chrome.storage.local.get('selectionBubble'), chrome.permissions.contains({ origins: SITES }),
    chrome.scripting.getRegisteredContentScripts({ ids: ['selection'] })
  ]);
  if (selectionBubble && granted && !registered.length) await chrome.scripting.registerContentScripts([{ id: 'selection', js: ['selection.js'], matches: SITES, runAt: 'document_idle', persistAcrossSessions: true }]);
  if (!(selectionBubble && granted) && registered.length) await chrome.scripting.unregisterContentScripts({ ids: ['selection'] });
}
const syncSelection = () => syncSelectionScript().catch(() => {});
chrome.runtime.onStartup.addListener(syncSelection);
chrome.permissions.onAdded.addListener(syncSelection); chrome.permissions.onRemoved.addListener(syncSelection);
function progressSender(tabId, sender, streamId) {
  // Rows arrive one at a time from several parallel requests; send them to the page in small bursts.
  let queued = [], flush = null;
  const deliver = () => {
    flush = null; const translations = queued; queued = [];
    if (translations.length) chrome.tabs.sendMessage(tabId, { type: 'translationProgress', streamId, translations },
      sender.documentId ? { documentId: sender.documentId } : { frameId: 0 }).catch(() => {});
  };
  return {
    push(translations) { if (typeof streamId !== 'string') return; queued.push(...translations); flush ??= setTimeout(deliver, 40); },
    flush() { clearTimeout(flush); deliver(); }
  };
}
async function activate(tab, selection = false, toggle = false, force = false) {
  if (!tab?.id || !/^https?:\/\//.test(tab.url || '')) throw new Error('Open a normal webpage to translate. Chrome pages, the Web Store, and PDFs are not supported.');
  await chrome.storage.session.set({ [`authorized:${tab.id}`]: new URL(tab.url).origin });
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['selection.js', 'content.js'] });
  const settingsKey = JSON.stringify(normalizeSettings(await readSettings(new URL(tab.url).hostname)));
  const { uiLanguage = 'zh-CN' } = await chrome.storage.local.get('uiLanguage');
  return chrome.tabs.sendMessage(tab.id, { type: 'start', selection, toggle, force, settingsKey, uiLanguage });
}
async function handle(message, sender) {
  if (sender.id !== chrome.runtime.id) throw new Error('Invalid sender.');
  const isUi = sender.url?.startsWith(chrome.runtime.getURL('')) === true;
  if (sender.tab && !isUi) {
    const tabId = sender.tab.id;
    if (sender.frameId !== 0 || !/^https?:\/\//.test(sender.url || '')) throw new Error('Unsupported page.');
    const origin = new URL(sender.url).origin;
    const authorized = (await chrome.storage.session.get(`authorized:${tabId}`))[`authorized:${tabId}`] === origin
      || (message.type === 'translateSelection' && await chrome.permissions.contains({ origins: [origin + '/*'] }));
    if (!authorized) throw new Error('Click Translate page to allow this page.');
    if (message.type === 'cancel') { await cancelTab(tabId); return {}; }
    const settings = normalizeSettings(await readSettings(new URL(sender.url).hostname));
    if (message.type === 'translateSelection') {
      if (message.language !== undefined && (typeof message.language !== 'string' || !message.language.trim() || message.language.length > 80)) throw new Error('Choose a target language.');
      if (message.instructions !== undefined && (typeof message.instructions !== 'string' || message.instructions.length > 2000)) throw new Error('Selection instructions are too long (2,000 characters at most).');
      const instructions = withSelectionInstructions(settings.instructions, message.instructions ?? (await chrome.storage.local.get('selectionInstructions')).selectionInstructions);
      const owner = `selection:${tabId}`, progress = progressSender(tabId, sender, message.streamId);
      // A new selection replaces the previous one.
      pageTranslations.cancel(owner);
      const input = { ...settings, instructions, ...(message.language ? { language: message.language.trim() } : {}), blocks: Array.isArray(message.blocks) ? message.blocks.map(block => ({ id: block?.id, text: block?.text, kind: 'main' })) : [] };
      try {
        return await pageTranslations.translate({ owner, url: sender.url, input, scope: 'selection', force: message.force === true, onProgress: rows => progress.push(rows) });
      } finally { progress.flush(); }
    }
    if (message.type !== 'translate') throw new Error('Unsupported page request.');
    const input = { ...settings, blocks: message.blocks }, progress = progressSender(tabId, sender, message.streamId);
    try {
      return await pageTranslations.translate({ owner: tabId, url: sender.url, input, scope: message.scope === 'selection' ? 'selection' : 'page', force: message.force === true,
        onProgress: rows => progress.push(rows) });
    } finally { progress.flush(); }
  }
  if (!isUi) throw new Error('Unsupported sender.');
  switch (message.type) {
    case 'status': return native('status', { provider: message.provider === 'claude' ? 'claude' : 'codex' });
    case 'models': return native('models');
    case 'limits': return native('limits');
    case 'login': {
      const result = await native('login');
      const url = new URL(result.authUrl);
      if (url.protocol !== 'https:' || !['auth.openai.com', 'chatgpt.com'].includes(url.hostname)) throw new Error('Unexpected sign-in address from Codex.');
      await chrome.storage.session.set({ loginId: result.loginId });
      await chrome.tabs.create({ url: url.href }); return { started: true };
    }
    case 'loginCancel': {
      const { loginId } = await chrome.storage.session.get('loginId');
      return loginId ? native('loginCancel', { loginId }) : {};
    }
    case 'logout': pageTranslations.cancelAll(); await pageTranslations.clear(); await chrome.storage.session.remove('popupConnection:codex'); return native('logout');
    case 'clearCache': await pageTranslations.clear(); return {};
    case 'activate': {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      return activate(tab, message.selection, false, message.force === true);
    }
    case 'restore': {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) { await cancelTab(tab.id); await chrome.tabs.sendMessage(tab.id, { type: 'restore' }).catch(() => {}); }
      return {};
    }
    default: throw new Error('Unknown operation.');
  }
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.type === 'accountEvent') return;
  handle(message, sender).then(result => respond({ ok: true, result }), error => respond({ ok: false, error: error.message })); return true;
});
chrome.runtime.onInstalled.addListener(async () => {
  syncSelection();
  const { uiLanguage } = await chrome.storage.local.get('uiLanguage');
  chrome.contextMenus.removeAll(() => chrome.contextMenus.create({ id: 'translate-selection', title: uiLanguage === 'en' ? 'Translate selection' : '翻译选中内容', contexts: ['selection'] }));
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'translate-selection') activate(tab, true).catch(() => chrome.action.setBadgeText({ tabId: tab.id, text: '!' }));
});
chrome.commands.onCommand.addListener(async name => {
  if (name !== 'toggle-translation') return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  activate(tab, false, true).catch(() => chrome.action.setBadgeText({ tabId: tab?.id, text: '!' }));
});
chrome.tabs.onRemoved.addListener(id => { cancelTab(id); chrome.storage.session.remove(`authorized:${id}`); });
chrome.tabs.onUpdated.addListener((id, change) => {
  if (change.status === 'loading') { cancelTab(id); chrome.storage.session.remove(`authorized:${id}`); }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.selectionBubble) syncSelection();
  if (area === 'local' && changes.uiLanguage) chrome.contextMenus.update('translate-selection', {
    title: changes.uiLanguage.newValue === 'en' ? 'Translate selection' : '翻译选中内容'
  }, () => void chrome.runtime.lastError);
});
