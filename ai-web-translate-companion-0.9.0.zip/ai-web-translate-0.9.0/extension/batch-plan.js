// Requests per wave run in parallel; each streams complete rows in source order.
// One request per page is slow (output streams serially) and many small requests
// each pay model start-up cost, so split a wave into a few balanced requests.
export const BATCH_LIMITS = { min: 1500, max: 24000, blocks: 120 };
export const CONCURRENCY = { codex: 4, claude: 6 };
export const BLOCK_KINDS = ['main', 'secondary', 'label'];
export const blockKind = block => block.kind || 'main';
export const providerOf = model => /^claude-/.test(model || '') ? 'claude' : 'codex';
// Include an allowance for each ID and JSON object in the text budget.
const cost = block => block.text.length + block.id.length + 24;

// Article first, then sidebar, then labels; source order within each group.
export function planBatches(blocks, concurrency = CONCURRENCY.codex) {
  const ordered = BLOCK_KINDS.flatMap(kind => blocks.filter(block => blockKind(block) === kind));
  if (!ordered.length) return [];
  const total = ordered.reduce((sum, block) => sum + cost(block), 0);
  const count = Math.max(1, Math.min(concurrency, Math.ceil(total / BATCH_LIMITS.min)), Math.ceil(total / BATCH_LIMITS.max));
  const target = total / count;
  const batches = []; let batch = [], size = 0;
  for (const block of ordered) {
    const next = cost(block);
    // Close a batch near the balanced target, or at the per-request block limit.
    if (batch.length && (batch.length >= BATCH_LIMITS.blocks || (batches.length < count - 1 && size + next / 2 > target))) {
      batches.push(batch); batch = []; size = 0;
    }
    batch.push(block); size += next;
  }
  batches.push(batch);
  return batches;
}
