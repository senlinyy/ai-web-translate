(() => {
  if (globalThis.__codexWebTranslate) return;
  globalThis.__codexWebTranslate = true;
  let uiLanguage = 'en', lastStatus = '';
  const labels = {
    'Retry': '重试', 'Original': '原文', 'Refresh': '刷新',
    'Preparing translation…': '正在准备翻译…',
    'Bilingual reading · loaded from cache': '双语阅读 · 已从缓存加载',
    'Bilingual reading · page translated': '双语阅读 · 页面已翻译',
    'Stop translation and restore original text': '停止翻译并恢复原文',
    'Translate this page again without using the cache': '跳过缓存，重新翻译当前页面'
  };
  const localize = value => uiLanguage === 'en' ? value : labels[value] || value.replace(/^Translating · (\d+) \/ (\d+) blocks$/, '正在翻译 · $1 / $2 个文本块');
  function renderLocale() {
    if (status) status.textContent = localize(lastStatus);
    for (const button of toolbar?.shadowRoot?.querySelectorAll('button') || []) {
      button.textContent = localize(button.dataset.label);
      if (button.dataset.title) button.title = localize(button.dataset.title);
    }
  }
  chrome.storage?.onChanged?.addListener((changes, area) => {
    if (area === 'local' && changes.uiLanguage) { uiLanguage = changes.uiLanguage.newValue === 'en' ? 'en' : 'zh-CN'; renderLocale(); }
  });
  const OWN = 'data-codex-translation';
  const SKIP = `script,style,noscript,textarea,input,select,option,pre,[contenteditable]:not([contenteditable="false"]),[translate="no"],[aria-hidden="true"],[hidden],[${OWN}]`;
  const YOUTUBE_WATCH = /(^|\.)youtube\.com$/.test(location.hostname) && location.pathname === '/watch';
  const YOUTUBE_TEXT = 'ytd-watch-metadata #title h1, ytd-watch-metadata #description #attributed-snippet-text, ytd-watch-metadata #description #plain-snippet-text, #comments #content-text, #secondary #video-title, #secondary .ytLockupMetadataViewModelTitle';
  const SEMANTIC = /^(P|H[1-6]|LI|BLOCKQUOTE|FIGCAPTION|TD|TH|BUTTON|LABEL|SUMMARY|DT|DD)$/;
  let enabled = false, generation = 0, running = false, toolbar, status, retryButton, scanTimer;
  let selectionMode = false, paused = false, idleScan = null;
  let scanStyles = new WeakMap(), scanRects = new WeakMap(), scanVisibility = new WeakMap();
  const styleOf = element => { if (!scanStyles.has(element)) scanStyles.set(element, getComputedStyle(element)); return scanStyles.get(element); };
  const rectOf = element => { if (!scanRects.has(element)) scanRects.set(element, element.getBoundingClientRect()); return scanRects.get(element); };
  const records = new Map(); const sourceWrappers = new WeakMap();
  let activeSettingsKey = '', selectedSnapshot = null, forceNext = false, sequence = 0;
  const completedText = new Map();
  const tooltipStates = new WeakMap();
  let cancellation = Promise.resolve(), starting = null, progress = null;
  
  const isLayout = element => /^(inline-)?(flex|grid)$/.test(getComputedStyle(element).display);
  const normalize = text => text.replace(/\s+/g, ' ').trim();
  const send = async payload => {
    const response = await chrome.runtime.sendMessage(payload);
    if (!response?.ok) throw new Error(response?.error || 'Extension disconnected. Reload this page and try again.');
    return response.result;
  };
  function visible(element) {
    if (!scanVisibility.has(element)) scanVisibility.set(element, checkVisible(element));
    return scanVisibility.get(element);
  }
  function checkVisible(element) {
    const rect = rectOf(element);
    if (rect.width <= 0 || rect.height <= 0) return false;
    // Text inside a scroll container is reachable by scrolling, so outer clipping
    // ancestors judge it by that container's box rather than by its current position.
    const box = { left: rect.left, right: rect.right, top: rect.top, bottom: rect.bottom };
    for (let ancestor = element; ancestor; ancestor = ancestor.parentElement) {
      const style = styleOf(ancestor);
      if (style.visibility === 'hidden' || style.visibility === 'collapse' || style.display === 'none' || Number(style.opacity) === 0) return false;
      if (ancestor === element || ancestor === document.body || ancestor === document.documentElement) continue;
      const x = style.overflowX, y = style.overflowY;
      if (!/(hidden|clip|auto|scroll)/.test(x + y)) continue;
      const clip = rectOf(ancestor);
      if (/hidden|clip/.test(x) && (box.right <= clip.left || box.left >= clip.right)) return false;
      if (/hidden|clip/.test(y) && (box.bottom <= clip.top || box.top >= clip.bottom)) return false;
      if (/auto|scroll/.test(x)) { if (clip.width <= 0) return false; box.left = clip.left; box.right = clip.right; }
      if (/auto|scroll/.test(y)) { if (clip.height <= 0) return false; box.top = clip.top; box.bottom = clip.bottom; }
    }
    // Off-canvas drawers sit beside the window; the window scrolls vertically, so only x is checked.
    return box.right > 0 && box.left < innerWidth;
  }
  function readingOrder() {
    return [...records.values()].filter(valid).map((record, index) => {
      const range = document.createRange();
      let rect = record.element.getBoundingClientRect();
      if (record.nodes.length) {
        range.setStartBefore(record.nodes[0]); range.setEndAfter(record.nodes.at(-1));
        const textRect = range.getBoundingClientRect(); if (textRect.width && textRect.height) rect = textRect;
      }
      return { record, rect, index };
    }).sort((a, b) => ['main', 'secondary', 'label'].indexOf(a.record.kind) - ['main', 'secondary', 'label'].indexOf(b.record.kind) || a.rect.top - b.rect.top || a.rect.left - b.rect.left || a.index - b.index).map(item => item.record);
  }
  function groups() {
    scanStyles = new WeakMap(); scanRects = new WeakMap(); scanVisibility = new WeakMap();
    const found = new Map();
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode(node) {
      const parent = node.parentElement;
      if (YOUTUBE_WATCH && !parent?.closest(YOUTUBE_TEXT)) return NodeFilter.FILTER_REJECT;
      if (!parent || parent.closest(SKIP) || !normalize(node.textContent)) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    } });
    let node;
    while ((node = walker.nextNode())) {
      const wrapped = sourceWrappers.get(node.parentElement);
      if (wrapped) {
        if (!visible(wrapped.element)) continue;
        if (!found.has(wrapped.key)) found.set(wrapped.key, { element: wrapped.element, nodes: [] });
        found.get(wrapped.key).nodes.push(node);
        continue;
      }
      let element = YOUTUBE_WATCH ? node.parentElement.closest(YOUTUBE_TEXT) : node.parentElement;
      if (!element) continue;
      while (!YOUTUBE_WATCH && element.parentElement && element !== document.body) {
        if (SEMANTIC.test(element.tagName) || /^(block|flex|grid|inline-flex|inline-grid|flow-root|list-item|table-cell)$/.test(styleOf(element).display)) break;
        element = element.parentElement;
      }
      if (element === document.body || !visible(element)) continue;
      // Direct text is an anonymous flex/grid item. Keep distinct items around icons separate.
      const key = node.parentElement === element && isLayout(element) ? node : element;
      if (!found.has(key)) found.set(key, { element, nodes: [] });
      found.get(key).nodes.push(node);
    }
    return found;
  }
  function compactElement(element, source) {
    if (YOUTUBE_WATCH && element.closest('#secondary')) return element.closest('a') || element;
    if (source.length > 120) return null;
    const control = element.closest('a,button,[role="button"],[role="menuitem"],[role="tab"]') || element;
    if (control.closest('nav,[role="navigation"],[role="menu"],[role="menubar"],[role="tablist"]')) return control;
    if (control.closest('aside') && control.matches('a,button,[role="button"],[role="menuitem"]')) return control;
    // Media controls have fixed geometry and often clip injected block content.
    if (control.closest('[class*="video-player"],[class*="video-controls"],[class*="media-controls"]')) return control;
    return null;
  }
  function textOf(nodes) { return normalize(nodes.map(n => n.textContent).join('')); }
  function contentKind(element, text, compact) {
    if (selectionMode) return 'main';
    if (compact || element.closest('nav,[role="navigation"],[role="menu"],[role="menubar"],[role="tablist"],button,[role="button"],label')) return 'label';
    if (element.closest('aside,[role="complementary"],footer,[role="contentinfo"]') || (YOUTUBE_WATCH && element.closest('#secondary'))) return 'secondary';
    if (YOUTUBE_WATCH && element.matches(YOUTUBE_TEXT)) return 'main';
    if (element.closest('article,[role="article"],[itemprop="articleBody"],main,[role="main"]') || /^H[1-6]$/.test(element.tagName) || /^(P|BLOCKQUOTE|FIGCAPTION|LI|TD|TH|DT|DD)$/.test(element.tagName) || text.length > 160) return 'main';
    return 'label';
  }
  function pieces(text) {
    const chunks = [];
    while (text.length > 5000) {
      let split = text.lastIndexOf(' ', 5000); if (split < 2500) split = 5000;
      chunks.push(text.slice(0, split)); text = text.slice(split).trimStart();
    }
    if (text) chunks.push(text); return chunks;
  }
  function makeSnapshot(entries) {
    const jobs = [], snapshotRecords = []; let characters = 0;
    for (const [key, { element, nodes, selectedText }] of entries) {
      const source = textOf(nodes), text = selectedText ?? source;
      if (text.length < 2 || !/\p{L}/u.test(text)) continue;
      const compact = compactElement(element, text);
      const label = compact?.textContent || text;
      if (compact && label.length <= 160 && /[A-Za-z]/.test(label) && /\p{Script=Han}/u.test(label)) continue;
      const chunks = pieces(text);
      const record = { key, element, nodes, source, kind: contentKind(element, text, compact), results: [], remaining: chunks.length };
      snapshotRecords.push(record);
      for (const [index, part] of chunks.entries()) {
        jobs.push({ id: `b${jobs.length + 1}`, text: part, index, record }); characters += part.length;
      }
    }
    return { jobs, records: snapshotRecords, tooLarge: jobs.length > 600 || characters > 60000,
      signature: JSON.stringify([location.href.split('#')[0], jobs.map(job => job.text)]) };
  }
  function capture() { return selectionMode ? selectedSnapshot : makeSnapshot(groups()); }
  function valid(record) {
    return records.get(record.key) === record && record.element.isConnected && record.nodes.every(node => node.isConnected && record.element.contains(node)) && textOf(record.nodes) === record.source;
  }
  function report(cached = false) {
    const all = [...records.values()], done = all.filter(record => record.host?.isConnected).length;
    updateStatus(all.every(record => record.done) ? (cached ? 'Bilingual reading · loaded from cache' : 'Bilingual reading · page translated') : `Translating · ${done} / ${all.length} blocks`);
  }
  function scan() {
    if (!enabled || paused) return;
    const snapshot = capture(); if (!snapshot) return;
    if (selectionMode && snapshot.records.some(record => !record.element.isConnected || textOf(record.nodes) !== record.source)) {
      paused = true; updateStatus('The selected text changed. Select it again to translate.'); return;
    }
    const present = new Set();
    for (const fresh of snapshot.records) {
      present.add(fresh.key);
      let record = records.get(fresh.key);
      if (record && (record.source !== fresh.source || record.nodes.length !== fresh.nodes.length || record.nodes.some((node, i) => node !== fresh.nodes[i]))) {
        removeRendering(record); records.delete(fresh.key); record = null;
      }
      if (!record) {
        record = fresh;
        const parts = snapshot.jobs.filter(job => job.record === fresh).map(job => job.text);
        record.textKey = JSON.stringify(parts);
        record.jobs = parts.map((text, index) => ({ id: `b${++sequence}`, text, index, record }));
        record.results = []; record.done = false; record.pending = false; record.force = forceNext;
        records.set(record.key, record);
        const saved = completedText.get(record.textKey);
        if (saved) { record.results = [...saved]; record.done = true; }
      }
      record.kind = fresh.kind;
    }
    // A block missing from this scan may only be out of view; keep it unless it changed or was regrouped.
    const claimed = new Set(snapshot.records.flatMap(record => record.nodes));
    for (const [key, record] of records) if (!present.has(key) && (!valid(record) || record.nodes.some(node => claimed.has(node)))) { removeRendering(record); records.delete(key); }
    forceNext = false;
    revealReady();
    if (running) { report(); return; }
    const jobs = []; let characters = 0;
    // Bound each wave, not the entire document. New content never cancels existing work.
    for (const record of readingOrder()) {
      if (record.done || record.pending) continue;
      for (const job of record.jobs) {
        if (typeof record.results[job.index] === 'string') continue;
        if (jobs.length >= 600 || characters + job.text.length > 60000) break;
        jobs.push(job); characters += job.text.length;
      }
      if (jobs.length >= 600 || characters >= 55000) break;
    }
    if (!jobs.length) { report(); return; }
    translateSnapshot({ jobs });
  }
  function revealReady() {
    // Keep article order across requests and cache hits. Labels cannot block it.
    const ordered = readingOrder(); let mainComplete = true;
    for (const kind of ['main', 'secondary', 'label']) {
      if (kind === 'secondary' && !mainComplete) continue;
      for (const record of ordered.filter(record => record.kind === kind)) {
        if (!record.jobs.every(part => typeof record.results[part.index] === 'string')) {
          if (kind === 'main') mainComplete = false;
          if (kind !== 'label') break;
          continue;
        }
        if (!record.host?.isConnected) { removeRendering(record); render(record); }
      }
    }
  }
  function clearRendering() {
    for (const record of records.values()) removeRendering(record);
    records.clear();
  }
  function scheduleScan() {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(() => {
      if (idleScan !== null) return;
      idleScan = requestIdleCallback(() => { idleScan = null; scan(); }, { timeout: 750 });
    }, 250);
  }
  function removeRendering(record) {
    record.host?.remove();
    if (record.tooltip) {
      const element = record.tooltip, state = tooltipStates.get(element);
      if (state) {
        state.rows.delete(record);
        if (element.getAttribute('title') === state.value) {
          state.value = [state.previous, ...state.rows.values()].filter(Boolean).join('\n');
          if (!state.rows.size && state.previous === null) element.removeAttribute('title');
          else element.setAttribute('title', state.value);
        }
        if (!state.rows.size) tooltipStates.delete(element);
      }
      record.tooltip = null;
    }
    if (record.wrapper) {
      sourceWrappers.delete(record.wrapper);
      record.wrapper.replaceWith(...record.wrapper.childNodes);
      record.wrapper = null;
    }
  }
  function render(record) {
    if (!record.element.isConnected || textOf(record.nodes) !== record.source) return;
    const host = document.createElement('span'); host.setAttribute(OWN, ''); host.setAttribute('translate', 'no');
    const compact = compactElement(record.element, record.source);
    if (compact) {
      let state = tooltipStates.get(compact);
      if (!state) { state = { previous: compact.getAttribute('title'), rows: new Map() }; tooltipStates.set(compact, state); }
      state.rows.set(record, record.results.join('\n'));
      state.value = [state.previous, ...state.rows.values()].filter(Boolean).join('\n');
      compact.setAttribute('title', state.value);
      record.tooltip = compact;
      host.hidden = true; compact.append(host); record.host = host;
      return;
    }
    host.style.cssText = 'display:block!important;margin:0.55em 0 0.2em!important;padding:0!important;white-space:normal!important;';
    const shadow = host.attachShadow({ mode: 'open' });
    const style = document.createElement('style'); style.textContent = ':host{font:inherit;color:inherit}span{font:inherit;color:inherit;line-height:1.65;white-space:pre-wrap;overflow-wrap:anywhere}';
    const text = document.createElement('span'); text.textContent = record.results.join('\n');
    shadow.append(style, text);
    let anchor = record.nodes.at(-1);
    while (anchor?.parentNode && anchor.parentNode !== record.element) anchor = anchor.parentNode;
    if (isLayout(record.element) && record.nodes.length && record.nodes.every(node => node.parentNode === record.element)) {
      // Wrap original text nodes, preserving their identity and the surrounding icon/label layout.
      const wrapper = document.createElement('span');
      wrapper.setAttribute('data-codex-source', '');
      wrapper.style.cssText = 'display:block!important;min-width:0!important;max-width:100%!important;';
      record.nodes[0].before(wrapper);
      for (const node of record.nodes) wrapper.append(node);
      wrapper.append(host); record.wrapper = wrapper; sourceWrappers.set(wrapper, record);
    } else if (YOUTUBE_WATCH && record.element.matches('ytd-watch-metadata #title h1')) {
      (record.element.closest('#title') || record.element).after(host);
    } else if (YOUTUBE_WATCH && record.element.matches('ytd-watch-metadata #description #attributed-snippet-text, ytd-watch-metadata #description #plain-snippet-text')) {
      (record.element.closest('ytd-text-inline-expander') || record.element).after(host);
    } else if (YOUTUBE_WATCH && record.element.matches('#comments #content-text')) {
      record.element.after(host);
    } else if (anchor?.parentNode === record.element) anchor.after(host); else record.element.append(host);
    record.host = host;
  }
  function updateStatus(message, error = false) {
    if (!status) return;
    lastStatus = message;
    status.textContent = localize(message);
    retryButton.hidden = !error;
  }
  async function translateSnapshot(snapshot) {
    running = true;
    const current = generation, force = snapshot.jobs.some(job => job.record.force);
    const streamId = `${current}:${Date.now()}:${Math.random()}`, received = new Map();
    const batchRecords = new Set(snapshot.jobs.map(job => job.record));
    for (const record of batchRecords) record.pending = true;
    const apply = rows => {
      if (!enabled || current !== generation) return;
      for (const row of rows) if (typeof row.text === 'string') received.set(row.id, row.text);
      for (const job of snapshot.jobs) {
        if (!received.has(job.id)) continue;
        if (!valid(job.record)) continue;
        job.record.results[job.index] = received.get(job.id);

      }
      revealReady();
      const visible = [...records.values()].filter(record => record.host?.isConnected).length;
      updateStatus(`Translating · ${visible} / ${records.size} blocks`);
    };
    progress = { streamId, apply }; report();
    try {
      const result = await send({ type: 'translate', streamId, scope: selectionMode ? 'selection' : 'page', force,
        blocks: snapshot.jobs.map(({ id, text, record }) => ({ id, text, kind: record.kind })) });
      if (!enabled || current !== generation) return;
      const translations = new Map(result.translations.map(row => [row.id, row.text]));
      if (translations.size !== snapshot.jobs.length || snapshot.jobs.some(job => typeof translations.get(job.id) !== 'string')) throw new Error('Incomplete translation. Please retry.');
      apply(result.translations);
      for (const record of batchRecords) if (valid(record) && record.jobs.every(job => typeof record.results[job.index] === 'string')) {
        record.done = true; record.force = false; completedText.set(record.textKey, [...record.results]);
        if (completedText.size > 5000) completedText.delete(completedText.keys().next().value);
      }
      report(result.cached);
    } catch (error) {
      if (enabled && current === generation) {
        // Keep earlier successful blocks; roll back only this failed wave's provisional rows.
        for (const job of snapshot.jobs) if (valid(job.record)) { removeRendering(job.record); delete job.record.results[job.index]; }
        paused = true; updateStatus(error.message, true);
      }
    } finally {
      for (const record of batchRecords) record.pending = false;
      if (progress?.streamId === streamId) progress = null;
      await cancellation; running = false;
      if (enabled && !paused && (current !== generation || [...records.values()].some(record => !record.done))) scan();
    }
  }
  function makeToolbar() {
    toolbar = document.createElement('div'); toolbar.setAttribute(OWN, '');
    toolbar.style.cssText = 'position:fixed!important;bottom:20px!important;right:20px!important;z-index:2147483647!important;';
    const shadow = toolbar.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = ':host{all:initial}.bar{font:13px/1.5 system-ui,sans-serif;display:flex;gap:12px;align-items:center;max-width:430px;padding:12px 16px;background:#173c34;color:#fff;border-radius:14px;box-shadow:0 6px 28px #0003}span{overflow-wrap:anywhere}button{font:inherit;cursor:pointer;border:1px solid #ffffff50;background:transparent;color:white;border-radius:7px;padding:5px 9px;white-space:nowrap}button[hidden]{display:none}';
    const bar = document.createElement('div'); bar.className = 'bar';
    status = document.createElement('span'); status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
    retryButton = document.createElement('button'); retryButton.textContent = 'Retry'; retryButton.hidden = true; retryButton.onclick = () => { paused = false; scan(); };
    const close = document.createElement('button'); close.textContent = 'Original'; close.title = 'Stop translation and restore original text'; close.onclick = restore;
    const refresh = document.createElement('button'); refresh.textContent = 'Refresh'; refresh.title = 'Translate this page again without using the cache'; refresh.hidden = selectionMode; refresh.onclick = () => start(false, false, true);
    for (const button of [retryButton, refresh, close]) { button.dataset.label = button.textContent; button.dataset.title = button.title; }
    bar.append(status, retryButton, refresh, close); shadow.append(style, bar); document.documentElement.append(toolbar); renderLocale();
  }
  async function restore() {
    enabled = false; progress = null; generation++; completedText.clear(); clearTimeout(scanTimer);
    if (idleScan !== null) { cancelIdleCallback(idleScan); idleScan = null; }
    clearRendering(); toolbar?.remove(); toolbar = status = null;
    cancellation = send({ type: 'cancel' }).catch(() => {});
    await cancellation;
  }
  async function start(selection, toggle, force = false, settingsKey = activeSettingsKey) {
    if (toggle && enabled) { await restore(); return { restored: true }; }
    if (enabled && running && !force && settingsKey === activeSettingsKey && Boolean(selection) === Boolean(selectionMode)) return { started: true, reused: true };
    // Capture selection before inserting UI or clearing the previous translation.
    const selected = selection ? window.getSelection() : null;
    const range = selected?.rangeCount ? selected.getRangeAt(0).cloneRange() : null;
    const selectedText = selected ? normalize(selected.toString()) : '';
    if (selection && (!range || !selectedText)) throw new Error('Select some webpage text first.');
    if (selection && (range.commonAncestorContainer.parentElement?.closest(SKIP))) throw new Error('This selection cannot be translated.');
    await restore(); paused = false; enabled = true; selectionMode = Boolean(selection); activeSettingsKey = settingsKey; forceNext = force; makeToolbar();
    updateStatus('Preparing translation…');
    if (selection) {
      const anchor = range.endContainer.nodeType === Node.ELEMENT_NODE ? range.endContainer : range.endContainer.parentElement;
      const nodes = range.endContainer.nodeType === Node.TEXT_NODE ? [range.endContainer] : [];
      selectedSnapshot = makeSnapshot([[anchor, { element: anchor, nodes, selectedText }]]);
    }
    scan();
    return { started: true };
  }
  new MutationObserver(mutations => {
    if (!enabled) return;
    if (mutations.some(m => !m.target.parentElement?.closest(`[${OWN}]`) && [...m.addedNodes, ...m.removedNodes].some(n => !(n.nodeType === 1 && n.hasAttribute(OWN))) || m.type === 'characterData')) scheduleScan();
  }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  // Capture scrolls of inner panels too; app-shell pages never scroll the window.
  addEventListener('scroll', scheduleScan, { passive: true, capture: true }); addEventListener('resize', scheduleScan);
  chrome.runtime.onMessage.addListener((message, _sender, respond) => {
    if (message.type === 'translationProgress') { if (progress?.streamId === message.streamId) progress.apply(message.translations || []); return; }
    if (!['start', 'restore'].includes(message.type)) return;
    let operation;
    if (message.type === 'start') {
      if (message.uiLanguage) { uiLanguage = message.uiLanguage === 'en' ? 'en' : 'zh-CN'; renderLocale(); }
      if (!starting) starting = start(message.selection, message.toggle, message.force, message.settingsKey).finally(() => { starting = null; });
      operation = starting;
    } else operation = restore().then(() => ({ restored: true }));
    operation.then(respond, error => respond({ error: error.message }));
    return true;
  });
})();
