import { DEFAULTS, providerOf } from './settings.js';
const label = effort => ({ none: 'None', minimal: 'Minimal', low: 'Low · faster', medium: 'Medium', high: 'High', xhigh: 'Extra high', max: 'Maximum', ultra: 'Ultra' })[effort] || effort;
// Common effort values supported by the minimum Codex runtime, used until discovery completes.
const FALLBACK_EFFORTS = ['low', 'medium', 'high', 'xhigh'];
const CLAUDE_EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'];
// Bootstrap capabilities from the local Codex catalog; live discovery takes precedence.
// Claude models run through the local Claude Code CLI and are not part of Codex discovery.
const BUILT_INS = [
  { model: 'gpt-6-luna', displayName: 'GPT-6 Luna (default)', efforts: ['low', 'medium', 'high', 'xhigh', 'max'] },
  { model: 'gpt-6-sol', displayName: 'GPT-6 Sol', efforts: ['low', 'medium', 'high', 'xhigh', 'max', 'ultra'] },
  { model: 'gpt-6-astra', displayName: 'GPT-6 Astra', efforts: ['low', 'medium', 'high', 'xhigh', 'max', 'ultra'] },
  { model: 'claude-opus-5-5', displayName: 'Claude Opus 5.5', efforts: CLAUDE_EFFORTS },
  { model: 'claude-sonnet-5-5', displayName: 'Claude Sonnet 5.5', efforts: CLAUDE_EFFORTS },
  { model: 'claude-haiku-5-5', displayName: 'Claude Haiku 5.5 · fastest', efforts: CLAUDE_EFFORTS }
];
function builtInOptions() {
  const group = (text, provider) => {
    const element = document.createElement('optgroup'); element.label = text;
    element.append(...BUILT_INS.filter(entry => providerOf(entry.model) === provider).map(entry => new Option(entry.displayName, entry.model)));
    return element;
  };
  return [group('ChatGPT · Codex', 'codex'), group('Claude · Claude Code', 'claude')];
}
export class ModelControls {
  constructor(model, effort, hint) {
    Object.assign(this, { model, effort, hint, catalog: [] });
    model.addEventListener('change', () => this.fillEfforts(effort.value));
    this.model.replaceChildren(...builtInOptions());
    this.set(DEFAULTS);
  }
  get provider() { return providerOf(this.model.value); }
  set({ model, effort }) {
    model ||= DEFAULTS.model;
    if (![...this.model.options].some(option => option.value === model)) this.model.add(new Option(model === DEFAULTS.model ? 'GPT-6 Luna (default)' : model, model));
    this.model.value = model;
    this.fillEfforts(effort ?? DEFAULTS.effort);
  }
  fillEfforts(selected) {
    const entry = this.catalog.find(item => item.model === this.model.value);
    const efforts = entry?.supportedReasoningEfforts?.map(item => item.reasoningEffort) || (BUILT_INS.find(item => item.model === this.model.value)?.efforts || FALLBACK_EFFORTS);
    this.effort.replaceChildren(new Option('Model default', ''), ...efforts.map(value => new Option(label(value), value)));
    this.effort.value = efforts.includes(selected) ? selected : '';
    this.hint.textContent = this.provider === 'claude' ? 'Uses your Claude Code sign-in. Low thinking is fastest. Changes apply to the next translation.'
      : this.loaded && !entry ? 'This model is not listed by your installed Codex. If unavailable, update Codex or select a listed model.' : 'Higher thinking levels can take longer. Changes apply to the next translation.';
  }
  async load(request) {
    const result = await request('models');
    const selected = { model: this.model.value, effort: this.effort.value };
    this.catalog = result.data || []; this.loaded = true;
    this.model.replaceChildren(...builtInOptions());
    const codex = this.model.querySelector('optgroup');
    for (const entry of this.catalog) if (!BUILT_INS.some(item => item.model === entry.model)) codex.append(new Option(entry.displayName || entry.model, entry.model));
    this.set(selected);
  }
}
