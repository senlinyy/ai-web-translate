import { initializeInterface } from './ui-locale.js';
initializeInterface();
import { setupShortcuts } from './shortcut-controls.js';
import { readSettings, normalizeSettings } from './settings.js';
import { ModelControls } from './model-controls.js';
const $ = id => document.getElementById(id);
setupShortcuts($('shortcuts'), $('shortcutDetail')); 
const models = new ModelControls($('model'), $('effort'), $('modelHint'));
const stable = value => JSON.stringify(value, (_key, item) => item && typeof item === 'object' && !Array.isArray(item) ? Object.fromEntries(Object.keys(item).sort().map(key => [key, item[key]])) : item);
async function request(type, extra = {}) { const r = await chrome.runtime.sendMessage({ type, ...extra }); if (!r?.ok) throw new Error(r?.error || 'Companion unavailable.'); return r.result; }
function status(text, error = false) { $('status').textContent = text; $('status').classList.toggle('error', error); }
function fill(settings) { for (const key of ['language', 'instructions', 'glossary']) $(key).value = settings[key]; models.set(settings); }
function hostname() { const value = $('hostname').value.trim().toLowerCase(); if (!value || /[\s/:?#]/.test(value) || !value.includes('.')) throw new Error('Enter a hostname such as learn.microsoft.com.'); return new URL('https://' + value).hostname; }
async function refresh() {
  const result = await request('status');
  $('account').textContent = result.signedIn ? `Connected · ${result.account.email || result.account.planType || 'ChatGPT'}` : 'Companion ready. Sign in to start translating.';
  $('login').hidden = result.signedIn; $('logout').hidden = !result.signedIn;
  await models.load(request).catch(() => {});
  if (result.signedIn) {
    try { const limits = await request('limits'); const bucket = limits.rateLimitsByLimitId?.codex || limits.rateLimits; $('limits').textContent = bucket?.primary ? `${Math.max(0, 100 - bucket.primary.usedPercent)}% remaining in the current usage window` : ''; } catch { $('limits').textContent = 'Usage information is unavailable.'; }
  }
}
async function refreshClaude() {
  $('claudeAccount').textContent = 'Checking Claude Code…';
  try {
    const result = await request('status', { provider: 'claude' });
    $('claudeAccount').textContent = result.signedIn ? `Connected · ${[result.account.email, result.account.planType].filter(Boolean).join(' · ') || 'Claude'}` : 'Not signed in to Claude Code.';
  } catch { $('claudeAccount').textContent = 'Claude Code unavailable. Install it, then re-run the companion installer.'; }
}
$('claudeRefresh').onclick = refreshClaude;
const SITES = { origins: ['http://*/*', 'https://*/*'] };
async function loadSelectionBubble() {
  const [{ selectionBubble = false }, granted] = await Promise.all([chrome.storage.local.get('selectionBubble'), chrome.permissions.contains(SITES)]);
  $('selectionBubble').checked = selectionBubble && granted;
}
$('selectionBubble').onchange = async () => {
  const enable = $('selectionBubble').checked;
  try {
    // Requested from this click, so Chrome can show its permission prompt.
    if (enable && !(await chrome.permissions.request(SITES))) { $('selectionBubble').checked = false; status('Selection translation needs access to websites.', true); return; }
    await chrome.storage.local.set({ selectionBubble: enable });
    if (!enable) await chrome.permissions.remove(SITES).catch(() => {});
    status(enable ? 'Selection translation is on. Reload open tabs to use it.' : 'Selection translation is off.');
  } catch (error) { status(error.message, true); }
};
loadSelectionBubble().catch(() => {});
chrome.storage.local.get('selectionInstructions').then(({ selectionInstructions = '' }) => { $('selectionInstructions').value = selectionInstructions; }, () => {});
$('saveSelectionInstructions').onclick = async () => {
  try {
    await chrome.storage.local.set({ selectionInstructions: $('selectionInstructions').value.trim().slice(0, 2000) });
    status('Selection instructions saved.');
  } catch (error) { status(error.message, true); }
};
$('scope').onchange = async () => { $('siteFields').hidden = $('scope').value !== 'site'; if (!$('scope').value) fill(await readSettings()); };
$('loadSite').onclick = async () => { try { fill(await readSettings(hostname())); status('Website preferences loaded.'); } catch (error) { status(error.message, true); } };
$('removeSite').onclick = async () => { try { const settings = await readSettings(); delete settings.sites[hostname()]; await chrome.storage.local.set({ settings }); fill(settings); status('Website now uses the global preferences.'); } catch (error) { status(error.message, true); } };
$('form').onsubmit = async event => {
  event.preventDefault();
  try {
    const values = normalizeSettings(Object.fromEntries(['language', 'model', 'effort', 'instructions', 'glossary'].map(key => [key, $(key).value])));
    const settings = await readSettings();
    if ($('scope').value === 'site') settings.sites = { ...settings.sites, [hostname()]: values }; else Object.assign(settings, values);
    await chrome.storage.local.set({ settings });
    const persisted = (await chrome.storage.local.get('settings')).settings;
    if (stable(persisted) !== stable(settings)) throw new Error('Preferences were not saved. Please retry.');
    status('Saved. Start translation again to apply your preferences.');
  } catch (error) { status(error.message, true); }
};
for (const [id, action] of Object.entries({ login: () => request('login'), logout: async () => { await request('logout'); await refresh(); }, refresh, clearCache: () => request('clearCache') })) {
  $(id).onclick = async () => { $(id).disabled = true; try { await action(); status(id === 'login' ? 'Complete sign-in in the opened tab.' : id === 'clearCache' ? 'Translation cache cleared.' : 'Connection updated.'); } catch (error) { status(error.message, true); } finally { $(id).disabled = false; } };
}
chrome.runtime.onMessage.addListener(message => { if (message.type === 'accountEvent') refresh().catch(error => status(error.message, true)); });
fill(await readSettings()); refreshClaude(); refresh().catch(error => { $('account').textContent = 'Local companion unavailable. Install it, then refresh the connection.'; status(error.message, true); });
