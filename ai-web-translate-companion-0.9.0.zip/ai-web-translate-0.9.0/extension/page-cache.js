// Whole-page results stay on this device. Keys hash the source and settings; source text is not stored.
export const CACHE_VERSION = 1;
export const CACHE_TTL = 30 * 24 * 60 * 60 * 1000;
export async function pageCacheKey(url, input, scope = 'page') {
  const page = new URL(url); page.hash = '';
  const snapshot = {
    version: CACHE_VERSION, url: page.href, scope,
    language: input.language, model: input.model, effort: input.effort,
    instructions: input.instructions, glossary: input.glossary,
    blocks: input.blocks.map(block => block.text)
  };
  const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(JSON.stringify(snapshot)));
  return Array.from(new Uint8Array(hash), byte => byte.toString(16).padStart(2, '0')).join('');
}
export class PageCache {
  constructor({ name = 'codex-page-translations', maxBytes = 20 * 1024 * 1024, maxEntries = 200, ttl = CACHE_TTL, now = Date.now } = {}) {
    Object.assign(this, { name, maxBytes, maxEntries, ttl, now, epoch: 0 });
  }
  open() {
    if (!this.database) this.database = new Promise((resolve, reject) => {
      const request = indexedDB.open(this.name, 1);
      request.onupgradeneeded = () => request.result.createObjectStore('pages', { keyPath: 'key' });
      request.onsuccess = () => { const db = request.result; db.onversionchange = () => { db.close(); this.database = null; }; resolve(db); };
      request.onerror = () => { this.database = null; reject(request.error); };
    });
    return this.database;
  }
  async get(key) {
    const epoch = this.epoch; const db = await this.open();
    if (epoch !== this.epoch) return null;
    return new Promise((resolve, reject) => {
      const transaction = db.transaction('pages', 'readwrite'); const store = transaction.objectStore('pages');
      let texts = null;
      const request = store.get(key);
      request.onsuccess = () => {
        const row = request.result;
        if (!row) return;
        if (this.now() - row.created >= this.ttl) { store.delete(key); return; }
        texts = row.texts; store.put({ ...row, accessed: this.now() });
      };
      transaction.oncomplete = () => resolve(epoch === this.epoch ? texts : null);
      transaction.onabort = () => reject(transaction.error || new Error('Cache read failed.'));
    });
  }
  async put(key, texts) { return this.putMany([{ key, texts }]); }
  async putMany(entries) {
    const epoch = this.epoch;
    const rowsToWrite = entries.map(({key, texts}) => ({ key, texts, bytes: new TextEncoder().encode(JSON.stringify(texts)).byteLength }));
    if (rowsToWrite.some(row => row.bytes > this.maxBytes)) return false;
    const db = await this.open();
    if (epoch !== this.epoch) return false;
    return new Promise((resolve, reject) => {
      const transaction = db.transaction('pages', 'readwrite'); const store = transaction.objectStore('pages');
      for (const row of rowsToWrite) store.put({ ...row, created: this.now(), accessed: this.now() });
      const request = store.getAll();
      request.onsuccess = () => {
        let rows = request.result;
        for (const row of rows) if (this.now() - row.created >= this.ttl) store.delete(row.key);
        rows = rows.filter(row => this.now() - row.created < this.ttl).sort((a, b) => a.accessed - b.accessed || a.created - b.created);
        let total = rows.reduce((sum, row) => sum + row.bytes, 0);
        while (rows.length > this.maxEntries || total > this.maxBytes) { const row = rows.shift(); store.delete(row.key); total -= row.bytes; }
      };
      transaction.oncomplete = () => resolve(epoch === this.epoch);
      transaction.onabort = () => reject(transaction.error || new Error('Cache write failed.'));
    });
  }
  async clear() {
    this.epoch++;
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction('pages', 'readwrite'); transaction.objectStore('pages').clear();
      transaction.oncomplete = () => resolve(); transaction.onabort = () => reject(transaction.error || new Error('Cache clear failed.'));
    });
  }
}
