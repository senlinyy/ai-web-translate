import { pageCacheKey } from './page-cache.js';
import { BLOCK_KINDS, CONCURRENCY, planBatches, providerOf } from './batch-plan.js';
export const PAGE_LIMITS = { blocks: 600, characters: 60000 };
export const TOO_LARGE = 'This page is too large to translate at once (600 blocks / 60,000 characters). Select a section and use Selection only.';
export function validatePageBlocks(blocks) {
  if (!Array.isArray(blocks) || !blocks.length) throw new Error('No text to translate.');
  if (blocks.length > PAGE_LIMITS.blocks) throw new Error(TOO_LARGE);
  const ids = new Set(); let length = 0;
  for (const block of blocks) {
    if (!block || typeof block.id !== 'string' || !/^[a-zA-Z0-9_-]{1,80}$/.test(block.id) || ids.has(block.id) || typeof block.text !== 'string' || !block.text.trim() || block.text.length > 6000 || (block.kind !== undefined && !BLOCK_KINDS.includes(block.kind))) throw new Error('Invalid page text.');
    ids.add(block.id); length += block.text.length;
  }
  if (length > PAGE_LIMITS.characters) throw new Error(TOO_LARGE);
}
export class PageTranslations {
  constructor(cache, request, blockCache = null) { this.blockCache = blockCache; this.cache = cache; this.request = request; this.flights = new Map(); this.epoch = 0; this.ownerEpochs = new Map(); this.cancelEpoch = 0; }
  async translate({ owner, url, input, scope = 'page', force = false, onProgress }) {
    validatePageBlocks(input.blocks);
    const ownerEpoch = this.ownerEpochs.get(owner) || 0, cancelEpoch = this.cancelEpoch;
    const key = await pageCacheKey(url, input, scope);
    if (ownerEpoch !== (this.ownerEpochs.get(owner) || 0) || cancelEpoch !== this.cancelEpoch) throw new Error('Translation cancelled.');
    const flightKey = `${owner}:${key}`;
    // The same page/settings request from this tab shares its existing model call.
    let flight = this.flights.get(flightKey);
    if (!flight) {
      const controller = new AbortController();
      flight = { owner, controller, listeners: new Set(), progress: [] };
      flight.promise = this.run(key, input, force, controller.signal, rows => {
        flight.progress.push(...rows);
        for (const listener of flight.listeners) listener(rows);
      }, url, scope).finally(() => { if (this.flights.get(flightKey) === flight) this.flights.delete(flightKey); });
      this.flights.set(flightKey, flight);
    }
    const listener = rows => { try { onProgress?.(rows.map(({ index, text }) => ({ id: input.blocks[index].id, text }))); } catch {} };
    flight.listeners.add(listener); listener(flight.progress);
    try {
      const result = await flight.promise;
      return { ...result, translations: input.blocks.map((block, index) => ({ id: block.id, text: result.texts[index] })), texts: undefined };
    } finally { flight.listeners.delete(listener); }
  }
  async run(key, input, force, signal, onProgress, url, scope) {
    const epoch = this.epoch;
    if (!force) {
      const texts = await this.cache.get(key).catch(() => null);
      signal.throwIfAborted();
      if (Array.isArray(texts) && texts.length === input.blocks.length && texts.every(text => typeof text === 'string' && text.trim())) return { texts, cached: true };
    }
    signal.throwIfAborted();
    const blockKeys = this.blockCache ? await Promise.all(input.blocks.map(block => pageCacheKey(url, { ...input, blocks: [block] }, scope))) : [];
    const saved = this.blockCache && !force ? await Promise.all(blockKeys.map(key => this.blockCache.get(key).catch(() => null))) : [];
    signal.throwIfAborted();
    const texts = new Array(input.blocks.length), positions = new Map(input.blocks.map((b, i) => [b.id, i]));
    for (let i = 0; i < saved.length; i++) if (Array.isArray(saved[i]) && saved[i].length === 1 && typeof saved[i][0] === 'string' && saved[i][0].trim()) texts[i] = saved[i][0];
    let nextBatch = 0; const revealed = new Set();
    const reveal = () => {
      const ready = [];
      for (let index = 0; index < texts.length; index++) if (texts[index] !== undefined && !revealed.has(index)) { ready.push({ index, text: texts[index] }); revealed.add(index); }
      if (ready.length) onProgress(ready);
    };
    reveal();
    const concurrency = CONCURRENCY[providerOf(input.model)];
    const batches = planBatches(input.blocks.filter(block => texts[positions.get(block.id)] === undefined), concurrency);
    const controller = new AbortController();
    const abort = () => controller.abort(signal.reason);
    signal.addEventListener('abort', abort, { once: true });
    const accept = (rows, allowed) => {
      controller.signal.throwIfAborted();
      for (const row of rows) {
        const index = positions.get(row?.id);
        if (!allowed.has(row?.id) || typeof row.text !== 'string' || !row.text.trim() || row.text.length > 24000 || (texts[index] !== undefined && texts[index] !== row.text)) throw new Error('Invalid streamed translation. Please retry.');
        texts[index] = row.text;
      }
      reveal();
    };
    const worker = async () => {
      while (nextBatch < batches.length) {
        controller.signal.throwIfAborted();
        const blocks = batches[nextBatch++], allowed = new Set(blocks.map(b => b.id));
        const result = await this.request({ ...input, blocks }, controller.signal, row => accept([row], allowed));
        controller.signal.throwIfAborted();
        const rows = result?.translations;
        if (!Array.isArray(rows) || rows.length !== blocks.length || new Set(rows.map(row => row?.id)).size !== blocks.length) throw new Error('The model returned an incomplete translation. Please retry.');
        accept(rows, allowed);
      }
    };
    try {
      await Promise.all(Array.from({ length: Math.min(concurrency, batches.length) }, () => worker().catch(error => { controller.abort(error); throw error; })));
    } finally { signal.removeEventListener('abort', abort); }
    signal.throwIfAborted();
    if (epoch === this.epoch) {
      await this.cache.put(key, texts).catch(() => false);
      if (this.blockCache && !signal.aborted && epoch === this.epoch) await this.blockCache.putMany(blockKeys.map((key, i) => ({ key, texts: [texts[i]] }))).catch(() => false);
    }
    signal.throwIfAborted();
    return { texts, cached: batches.length === 0 };
  }
  cancel(owner) { this.ownerEpochs.set(owner, (this.ownerEpochs.get(owner) || 0) + 1); for (const [key, flight] of this.flights) if (flight.owner === owner) { flight.controller.abort(); this.flights.delete(key); } }
  cancelAll() { this.cancelEpoch++; for (const flight of this.flights.values()) flight.controller.abort(); this.flights.clear(); }
  async clear() { this.epoch++; await Promise.all([this.cache.clear(), this.blockCache?.clear()]); }
}
