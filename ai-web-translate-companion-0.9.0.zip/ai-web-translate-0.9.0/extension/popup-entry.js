// Chrome shows an action popup after DocumentOnLoadCompleted. Do not import
// modules or contact services until that event has finished, even if rAF ran.
window.addEventListener('load', () => {
  setTimeout(() => {
    import('./popup.js').catch(() => {
      const status = document.getElementById('status');
      status.textContent = 'Could not initialize the popup. Close it and try again.';
      status.classList.add('error');
    });
  }, 0);
}, { once: true });
