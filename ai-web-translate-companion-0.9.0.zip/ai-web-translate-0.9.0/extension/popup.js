import { initializeInterface } from './ui-locale.js';
initializeInterface();
import { setupShortcuts } from './shortcut-controls.js';
import { readSettings } from './settings.js';
import { ModelControls } from './model-controls.js';
const $ = id => document.getElementById(id);
let saveQueue = Promise.resolve();
const models = new ModelControls($('model'), $('effort'), $('modelHint'));
async function request(type, extra = {}) { const r = await chrome.runtime.sendMessage({ type, ...extra }); if (!r?.ok) throw new Error(r?.error || 'No response.'); return r.result; }
function showError(error) { $('status').textContent = error.message; $('status').classList.add('error'); }
function showConnection(result, cached = false) {
  const claude = result.provider === 'claude';
  $('account').textContent = result.signedIn ? (claude ? (cached ? 'Claude signed in · last checked' : 'Connected with Claude') : (cached ? 'ChatGPT signed in · last checked' : 'Connected with ChatGPT')) : 'Ready to connect';
  $('accountDetail').textContent = result.signedIn ? [result.account?.email, result.account?.planType].filter(Boolean).join(' · ')
    : claude ? 'Run "claude auth login" in Terminal, then check the connection again.' : 'Sign in to use your Codex account for translation.';
  if (!cached) { $('dot').classList.toggle('online', result.signedIn); $('login').hidden = claude || result.signedIn; }
}
async function check() {
  $('reconnect').hidden = true;
  try {
    const provider = models.provider;
    showConnection({ provider, ...await request('status', { provider }) });
    if (provider === 'codex') await models.load(request).catch(() => {});
  } catch (error) { $('account').textContent = 'Companion unavailable'; $('accountDetail').textContent = 'Install the local companion, then reconnect.'; $('reconnect').hidden = false; showError(error); }
}
for (const [id, action] of Object.entries({ translate: () => request('activate'), refreshTranslation: () => request('activate', { force: true }), selection: () => request('activate', { selection: true }), restore: () => request('restore'), login: () => request('login'), reconnect: check })) {
  $(id).onclick = async () => { $(id).disabled = true; $('status').textContent = ''; $('status').classList.remove('error'); try { await saveQueue; const r = await action(); if (r?.error) throw new Error(r.error); if (['translate', 'selection', 'refreshTranslation'].includes(id)) window.close(); if (id === 'login') $('status').textContent = 'Complete sign-in in the opened tab.'; } catch (error) { showError(error); } finally { $(id).disabled = false; } };
}
$('settings').onclick = () => chrome.runtime.openOptionsPage();
setupShortcuts($('shortcuts'));
let hostname;
async function initializeSettings() {
  const [[currentTab], global] = await Promise.all([chrome.tabs.query({ active: true, currentWindow: true }), readSettings()]);
  hostname = /^https?:\/\//.test(currentTab?.url || '') ? new URL(currentTab.url).hostname : undefined;
  const settings = hostname && global.sites?.[hostname] ? { ...global, ...global.sites[hostname] } : global;
  if (![...$('language').options].some(o => o.value === settings.language)) $('language').add(new Option(settings.language, settings.language));
  $('language').value = settings.language;
  models.set(settings);
}
// Actions wait for saved preferences, but the popup itself never waits to display.
saveQueue = initializeSettings().catch(showError).finally(() => { for (const id of ['language', 'model', 'effort']) $(id).disabled = false; });
for (const key of ['language', 'model', 'effort']) $(key).addEventListener('change', () => {
  const values = { language: $('language').value, model: $('model').value, effort: $('effort').value };
  saveQueue = saveQueue.catch(() => {}).then(async () => {
    const current = await readSettings();
    if (hostname && current.sites?.[hostname]) Object.assign(current.sites[hostname], values); else Object.assign(current, values);
    await chrome.storage.local.set({ settings: current });
  }).catch(showError);
});
chrome.runtime.onMessage.addListener(message => { if (message.type === 'accountEvent') check(); });
// Opening the popup never wakes the background worker or launches native Codex.
// Status is explicitly a cached observation; translation still verifies sign-in.
async function restoreCachedConnection() {
  const provider = models.provider, key = `popupConnection:${provider}`;
  const cached = (await chrome.storage.session.get(key))[key];
  if (provider !== models.provider) return;
  $('dot').classList.remove('online'); $('login').hidden = true;
  if (cached?.signedIn) showConnection({ provider, ...cached }, true);
  else { $('account').textContent = 'Ready to translate'; $('accountDetail').textContent = 'Connection is checked when you translate.'; }
}
async function restoreCachedState() {
  const { modelCatalog } = await chrome.storage.local.get('modelCatalog');
  if (modelCatalog) await models.load(async () => modelCatalog);
  await saveQueue.catch(() => {});
  await restoreCachedConnection();
}
restoreCachedState().catch(() => {});
$('model').addEventListener('change', () => { restoreCachedConnection().catch(() => {}); });
