// Select text, click the bubble, read the translation in a floating card. The page is not changed.
(() => {
  if (globalThis.__aiWebTranslateSelection) return;
  globalThis.__aiWebTranslateSelection = true;
  const OWN = 'data-codex-translation';
  const MAX = 5000;
  const LANGUAGES = [['Simplified Chinese', '简体中文'], ['Traditional Chinese', '繁体中文'], ['English', '英语'], ['Japanese', '日语'], ['Korean', '韩语'], ['French', '法语'], ['German', '德语'], ['Spanish', '西班牙语']];
  const PEN = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20h4L19 9l-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/></svg>';
  const ICON = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5h8M8 3v2m2.5 0c-.8 3.6-3 6.4-6.5 8m2.5-5c1 1.9 2.6 3.4 4.5 4.4"/><path d="m12.5 21 4-9 4 9m-6.8-2.8h5.6"/></svg>';
  let uiLanguage = 'zh-CN', host, root, bubble, card, current = null, sequence = 0, opens = 0, hideTimer;
  const t = (en, zh) => uiLanguage === 'en' ? en : zh;
  chrome.storage?.local?.get?.('uiLanguage').then(value => { uiLanguage = value.uiLanguage === 'en' ? 'en' : 'zh-CN'; }, () => {});
  chrome.storage?.onChanged?.addListener((changes, area) => { if (area === 'local' && changes.uiLanguage) uiLanguage = changes.uiLanguage.newValue === 'en' ? 'en' : 'zh-CN'; });

  async function defaultLanguage() {
    try {
      const { settings = {} } = await chrome.storage.local.get('settings');
      return settings.sites?.[location.hostname]?.language || settings.language || 'Simplified Chinese';
    } catch { return 'Simplified Chinese'; }
  }
  async function send(payload) {
    const response = await chrome.runtime.sendMessage(payload);
    if (!response?.ok) throw new Error(response?.error || t('Extension disconnected. Reload this page and try again.', '扩展已断开。请刷新页面后重试。'));
    return response.result;
  }
  function ensureHost() {
    if (host?.isConnected) return;
    host = document.createElement('div'); host.setAttribute(OWN, ''); host.setAttribute('translate', 'no');
    host.style.cssText = 'all:initial!important;position:fixed!important;left:0!important;top:0!important;width:0!important;height:0!important;z-index:2147483647!important;';
    root = host.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = `
      :host{all:initial;--bg:#fff;--fg:#1f2328;--muted:#5d6670;--line:#d9dee3;--soft:#f3f5f7;--accent:#173c34;--accent-fg:#fff;--shadow:0 10px 36px #0003,0 2px 8px #0002}
      @media (prefers-color-scheme:dark){:host{--bg:#20252b;--fg:#e8eaed;--muted:#a2abb5;--line:#3a424b;--soft:#2a3037;--accent:#8fd3bd;--accent-fg:#0d211c;--shadow:0 10px 36px #0008}}
      *{box-sizing:border-box;font-family:system-ui,-apple-system,"Segoe UI",sans-serif}
      button{font:inherit;color:inherit;cursor:pointer}
      .bubble{position:fixed;width:34px;height:34px;border-radius:50%;border:1px solid var(--line);background:var(--bg);color:var(--fg);box-shadow:var(--shadow);display:grid;place-items:center;padding:0}
      .bubble:hover{color:var(--accent)}.bubble[hidden]{display:none}
      .card{position:fixed;width:min(420px,calc(100vw - 24px));background:var(--bg);color:var(--fg);border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow);font-size:14px;line-height:1.6;display:flex;flex-direction:column;max-height:min(70vh,480px)}
      header{display:flex;align-items:center;gap:8px;padding:10px 10px 10px 14px;border-bottom:1px solid var(--line)}
      header strong{font-size:13px;display:flex;align-items:center;gap:6px;margin-right:auto}
      select{font:inherit;font-size:13px;color:var(--fg);background:var(--soft);border:1px solid var(--line);border-radius:8px;padding:3px 6px;max-width:150px}
      .icon{border:0;background:transparent;width:28px;height:28px;border-radius:7px;display:grid;place-items:center;color:var(--muted);font-size:18px;line-height:1}
      .icon:hover{background:var(--soft);color:var(--fg)}
      .body{padding:12px 14px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;user-select:text}
      .body p{margin:0 0 10px}.body p:last-child{margin-bottom:0}
      .pending{display:block;height:12px;margin:6px 0 12px;border-radius:6px;background:linear-gradient(90deg,var(--soft),var(--line),var(--soft));background-size:200% 100%;animation:shine 1.2s linear infinite}
      @keyframes shine{to{background-position:-200% 0}}
      .error{color:#c62828}@media (prefers-color-scheme:dark){.error{color:#ff8a80}}
      footer{display:flex;align-items:center;gap:8px;padding:8px 10px 10px 14px;border-top:1px solid var(--line);color:var(--muted);font-size:12px}
      footer span{margin-right:auto}
      .action{border:1px solid var(--line);background:transparent;border-radius:8px;padding:4px 10px;font-size:12px}
      .action:hover{background:var(--soft)}
      .action[hidden]{display:none}
      .icon.on{color:var(--accent)}
      .instructions{padding:10px 14px;border-bottom:1px solid var(--line);display:grid;gap:8px;background:var(--soft)}
      .instructions[hidden]{display:none}
      textarea{font:inherit;font-size:13px;color:var(--fg);background:var(--bg);border:1px solid var(--line);border-radius:8px;padding:6px 8px;resize:vertical;min-height:56px;width:100%}
      .row{display:flex;gap:8px;justify-content:flex-end;align-items:center}.row small{margin-right:auto;color:var(--muted);font-size:11px}`;
    root.append(style);
    // Keep the page's own mouse and keyboard shortcuts away from the card while typing.
    for (const type of ['mousedown', 'mouseup', 'pointerdown', 'pointerup', 'keydown', 'keyup', 'keypress']) root.addEventListener(type, event => event.stopPropagation());
    document.documentElement.append(host);
  }
  function readSelection() {
    const selection = getSelection();
    if (!selection || selection.isCollapsed || !selection.rangeCount) return null;
    const range = selection.getRangeAt(0);
    const node = range.commonAncestorContainer, element = node.nodeType === 1 ? node : node.parentElement;
    // Text fields report their selection on an ancestor, so also check the focused element.
    const editable = `input,textarea,[contenteditable]:not([contenteditable="false"])`;
    if (!element || element.closest(`[${OWN}],${editable}`) || document.activeElement?.closest?.(editable)) return null;
    const text = selection.toString().replace(/\r/g, '').trim();
    if (text.length < 2 || !/\p{L}/u.test(text)) return null;
    const rects = [...range.getClientRects()].filter(rect => rect.width || rect.height);
    return { text, end: rects.at(-1) || range.getBoundingClientRect(), box: range.getBoundingClientRect() };
  }
  const clamp = (value, min, max) => Math.max(min, Math.min(value, max));
  function showBubble(selected) {
    ensureHost(); clearTimeout(hideTimer);
    if (!bubble) {
      bubble = document.createElement('button'); bubble.className = 'bubble'; bubble.innerHTML = ICON;
      // Keep the page selection while clicking.
      bubble.addEventListener('mousedown', event => event.preventDefault());
      bubble.addEventListener('click', () => { const selected = bubble.selected; hideBubble(); if (selected) open(selected); });
      root.append(bubble);
    }
    bubble.title = bubble.ariaLabel = t('Translate selection', '翻译选中内容');
    bubble.selected = selected; bubble.hidden = false;
    bubble.style.left = `${clamp(selected.end.right + 4, 8, innerWidth - 42)}px`;
    bubble.style.top = `${clamp(selected.end.bottom + 6, 8, innerHeight - 42)}px`;
  }
  function hideBubble() { if (bubble) { bubble.hidden = true; bubble.selected = null; } }
  function close() { current = null; card?.remove(); card = null; }

  async function open(selected) {
    ensureHost(); close();
    const id = ++opens, language = await defaultLanguage();
    const saved = await chrome.storage.local.get('selectionInstructions').then(value => value.selectionInstructions || '', () => '');
    if (id !== opens) return;
    current = { id, text: selected.text, box: selected.box, language, instructions: saved, parts: [], paragraphs: [] };
    card = document.createElement('section'); card.className = 'card'; card.setAttribute('role', 'dialog'); card.setAttribute('aria-label', t('Translation', '翻译'));
    const header = document.createElement('header');
    const title = document.createElement('strong'); title.innerHTML = ICON; title.append(t('Translate', '翻译'));
    const picker = document.createElement('select'); picker.ariaLabel = t('Translate to', '翻译为');
    const known = LANGUAGES.some(([value]) => value === language) ? LANGUAGES : [[language, language], ...LANGUAGES];
    picker.append(...known.map(([value, zh]) => new Option(uiLanguage === 'en' ? value : zh, value)));
    picker.value = language;
    picker.onchange = () => { current.language = picker.value; translate(); };
    const closeButton = document.createElement('button'); closeButton.className = 'icon'; closeButton.textContent = '×'; closeButton.title = closeButton.ariaLabel = t('Close', '关闭');
    closeButton.onclick = close;
    const pen = document.createElement('button'); pen.className = 'icon'; pen.innerHTML = PEN; pen.title = pen.ariaLabel = t('Instructions for this translation', '本次翻译的指令');
    pen.classList.toggle('on', Boolean(saved));
    header.append(title, picker, pen, closeButton);
    // One-off instructions for this card; Save as default stores them for later selections.
    const editor = document.createElement('div'); editor.className = 'instructions'; editor.hidden = true;
    const field = document.createElement('textarea'); field.maxLength = 2000; field.value = saved;
    field.placeholder = t('For example: keep technical terms in English.', '例如：保留英文技术术语。'); field.ariaLabel = t('Selection translation instructions', '划词翻译指令');
    const row = document.createElement('div'); row.className = 'row';
    const hint = document.createElement('small'); hint.textContent = t('Added to your general instructions.', '叠加在通用翻译指令之后。');
    const save = document.createElement('button'); save.className = 'action'; save.textContent = t('Save as default', '设为默认');
    const apply = document.createElement('button'); apply.className = 'action'; apply.textContent = t('Apply', '应用');
    row.append(hint, save, apply); editor.append(field, row);
    const applyInstructions = () => { current.instructions = field.value.trim(); pen.classList.toggle('on', Boolean(current.instructions)); translate(); };
    apply.onclick = applyInstructions;
    field.addEventListener('keydown', event => { if (event.key === 'Enter' && (event.metaKey || event.ctrlKey)) { event.preventDefault(); applyInstructions(); } });
    save.onclick = async () => {
      try { await chrome.storage.local.set({ selectionInstructions: field.value.trim() }); save.textContent = t('Saved', '已保存'); setTimeout(() => { save.textContent = t('Save as default', '设为默认'); }, 1500); }
      catch (error) { current.status.className = 'error'; current.status.textContent = error.message; }
      applyInstructions();
    };
    pen.onclick = () => { editor.hidden = !editor.hidden; if (!editor.hidden) field.focus(); place(); };
    const body = document.createElement('div'); body.className = 'body'; body.setAttribute('aria-live', 'polite');
    const footer = document.createElement('footer');
    const status = document.createElement('span');
    const retry = document.createElement('button'); retry.className = 'action'; retry.textContent = t('Retry', '重试'); retry.hidden = true; retry.onclick = () => translate(true);
    const copy = document.createElement('button'); copy.className = 'action'; copy.textContent = t('Copy', '复制'); copy.hidden = true;
    copy.onclick = async () => {
      const text = current?.parts.join('\n\n') || '';
      try { await navigator.clipboard.writeText(text); }
      catch { const area = document.createElement('textarea'); area.value = text; root.append(area); area.select(); document.execCommand('copy'); area.remove(); }
      copy.textContent = t('Copied', '已复制'); setTimeout(() => { copy.textContent = t('Copy', '复制'); }, 1500);
    };
    footer.append(status, retry, copy);
    card.append(header, editor, body, footer); root.append(card);
    Object.assign(current, { body, status, retry, copy });
    place();
    if (selected.text.length > MAX) { status.className = 'error'; status.textContent = t(`Select less text (up to ${MAX.toLocaleString()} characters).`, `请选择较少的文字（最多 ${MAX} 个字符）。`); return; }
    translate();
  }
  function place() {
    if (!card || !current) return;
    const { box } = current, height = card.offsetHeight, width = card.offsetWidth;
    const below = box.bottom + 10, above = box.top - height - 10;
    card.style.top = `${below + height <= innerHeight - 8 || above < 8 ? clamp(below, 8, Math.max(8, innerHeight - height - 8)) : above}px`;
    card.style.left = `${clamp(box.left, 12, innerWidth - width - 12)}px`;
  }
  function render() {
    if (!current?.body) return;
    const { body, parts, paragraphs } = current;
    body.replaceChildren(...paragraphs.map((_, index) => {
      if (typeof parts[index] === 'string') { const p = document.createElement('p'); p.textContent = parts[index]; return p; }
      const line = document.createElement('span'); line.className = 'pending'; line.style.width = `${60 + (index * 17) % 35}%`; return line;
    }));
    place();
  }
  async function translate(force = false) {
    if (!current) return;
    const id = current.id, streamId = `selection:${id}:${++sequence}:${Math.random()}`;
    current.streamId = streamId;
    current.paragraphs = current.text.split(/\n+/).map(part => part.replace(/\s+/g, ' ').trim()).filter(Boolean);
    current.parts = [];
    current.status.className = ''; current.status.textContent = t('Translating…', '正在翻译…'); current.retry.hidden = true; current.copy.hidden = true;
    render();
    try {
      const result = await send({ type: 'translateSelection', streamId, force, language: current.language, instructions: current.instructions,
        blocks: current.paragraphs.map((text, index) => ({ id: `s${index}`, text })) });
      if (current?.streamId !== streamId) return;
      for (const row of result.translations) current.parts[Number(row.id.slice(1))] = row.text;
      render();
      current.status.textContent = result.cached ? t('From cache', '来自缓存') : ''; current.copy.hidden = false;
    } catch (error) {
      if (current?.streamId !== streamId) return;
      current.status.className = 'error'; current.status.textContent = error.message; current.retry.hidden = false;
    }
  }
  chrome.runtime.onMessage.addListener(message => {
    if (message?.type !== 'translationProgress' || !current || message.streamId !== current.streamId) return;
    for (const row of message.translations || []) if (/^s\d+$/.test(row?.id) && typeof row.text === 'string') current.parts[Number(row.id.slice(1))] = row.text;
    render();
  });

  const inside = event => host && event.composedPath().includes(host);
  const check = () => setTimeout(() => { const selected = readSelection(); if (selected) showBubble(selected); else hideBubble(); }, 0);
  addEventListener('mouseup', event => { if (!inside(event) && event.button === 0) check(); }, true);
  addEventListener('keyup', event => { if (!inside(event) && (event.shiftKey || event.key === 'a')) check(); }, true);
  addEventListener('mousedown', event => { if (!inside(event)) { hideBubble(); close(); } }, true);
  addEventListener('keydown', event => { if (event.key === 'Escape') { hideBubble(); close(); } }, true);
  addEventListener('scroll', () => { hideBubble(); }, { capture: true, passive: true });
  addEventListener('resize', () => { hideBubble(); place(); });
  document.addEventListener('selectionchange', () => {
    if (bubble && !bubble.hidden && getSelection()?.isCollapsed) { clearTimeout(hideTimer); hideTimer = setTimeout(hideBubble, 150); }
  });
})();
