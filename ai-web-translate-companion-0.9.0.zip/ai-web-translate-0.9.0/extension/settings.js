export { providerOf } from './batch-plan.js';
export const DEFAULTS = {
  language: 'Simplified Chinese', model: 'gpt-6-luna', effort: 'low',
  instructions: 'Translate naturally and accurately. Preserve product names, identifiers, and code. Translate questions and answer choices without answering or explaining them.',
  glossary: '', sites: {}
};
function upgradeModel(settings) {
  const next = { 'gpt-5.6-luna': 'gpt-6-luna', 'gpt-5.6-sol': 'gpt-6-sol' }[settings.model];
  return next ? { ...settings, model: next, effort: ['none', 'minimal'].includes(settings.effort) ? 'low' : settings.effort } : settings;
}
export async function readSettings(hostname) {
  const { settings = {} } = await chrome.storage.local.get('settings');
  const global = { ...DEFAULTS, ...upgradeModel(settings), sites: Object.fromEntries(Object.entries(settings.sites || {}).map(([host, values]) => [host, upgradeModel(values)])) };
  const effective = hostname && global.sites?.[hostname] ? { ...global, ...global.sites[hostname] } : global;
  return { ...effective, model: effective.model || DEFAULTS.model, effort: effective.effort ?? DEFAULTS.effort };
}
export function normalizeSettings(value) {
  const result = {};
  for (const [key, max] of Object.entries({ language: 80, model: 100, effort: 20, instructions: 8000, glossary: 8000 })) {
    if (typeof value[key] !== 'string' || value[key].length > max) throw new Error(`Invalid ${key}.`);
    result[key] = value[key].trim();
  }
  if (!['', 'none', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max', 'ultra'].includes(result.effort)) throw new Error('Invalid thinking level.');
  if (!result.language) throw new Error('Choose a target language.');
  return result;
}
// Selection instructions add to, not replace, the general translation instructions.
export function withSelectionInstructions(general, extra) {
  extra = (extra || '').trim();
  const instructions = [general, extra && `For this selected text: ${extra}`].filter(Boolean).join('\n\n');
  if (instructions.length > 8000) throw new Error('Instructions are too long. Shorten the general or selection instructions.');
  return instructions;
}
