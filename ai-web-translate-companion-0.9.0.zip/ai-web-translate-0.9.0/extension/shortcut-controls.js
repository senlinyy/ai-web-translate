// Read Chrome's actual assignment, including user edits or an unassigned shortcut.
export async function setupShortcuts(button, detail) {
  button.addEventListener('click', () => chrome.tabs.create({ url: 'chrome://extensions/shortcuts' }));
  async function update() {
  try {
    const commands = await chrome.commands.getAll();
    const toggle = commands.find(command => command.name === 'toggle-translation');
    const shortcut = toggle?.shortcut;
    if (detail) detail.textContent = shortcut ? `${shortcut} — translate this page or show the original. Works without opening the popup.` : 'No shortcut assigned. Choose a key combination below to translate without opening the popup.';
    else button.textContent = shortcut || 'Set shortcut';
    button.title = shortcut ? `${shortcut}: translate page / show original. Click to change the shortcut.` : 'Assign a keyboard shortcut for page translation';
  } catch {
    if (detail) detail.textContent = 'Set a keyboard shortcut to translate pages without opening the popup.';
    button.title = 'Configure the page translation shortcut';
  }
  }
  window.addEventListener('focus', update);
  await update();
}
