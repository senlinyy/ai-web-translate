import { translations } from './ui-translations.js';
const english = new Map(Object.entries(translations).map(([en, zh]) => [zh, en]));
const patterns = [
  [/^Connected · (.*)$/, /^已连接 · (.*)$/, 'Connected · $1', '已连接 · $1'],
  [/^(.*)% remaining in the current usage window$/, /^当前用量周期剩余 (.*)%$/, '$1% remaining in the current usage window', '当前用量周期剩余 $1%'],
  [/^(.*) — translate this page or show the original\. Works without opening the popup\.$/, /^(.*) — 翻译页面或显示原文，无需打开弹窗。$/, '$1 — translate this page or show the original. Works without opening the popup.', '$1 — 翻译页面或显示原文，无需打开弹窗。'],
  [/^(.*): translate page \/ show original\. Click to change the shortcut\.$/, /^(.*)：翻译页面或显示原文。点击更改快捷键。$/, '$1: translate page / show original. Click to change the shortcut.', '$1：翻译页面或显示原文。点击更改快捷键。'],
  [/^Version (.*) · HTML webpages · Mac & Linux companion · PDFs, image text, and embedded frames are not supported yet\.$/, /^版本 (.*) · HTML 网页 · Mac 和 Linux 本地服务 · 暂不支持 PDF、图片文字和嵌入框架。$/, 'Version $1 · HTML webpages · Mac & Linux companion · PDFs, image text, and embedded frames are not supported yet.', '版本 $1 · HTML 网页 · Mac 和 Linux 本地服务 · 暂不支持 PDF、图片文字和嵌入框架。']
];
export function translateLabel(text, locale) {
  const source = english.get(text) || text;
  if (translations[source]) return locale === 'en' ? source : translations[source];
  for (const [en, zh, enValue, zhValue] of patterns) {
    const match = en.test(text) ? en : zh.test(text) ? zh : null;
    if (match) return text.replace(match, locale === 'en' ? enValue : zhValue);
  }
  return text;
}
// Only extension-owned UI is visited. Input values, user instructions and provider
// model names stay untouched. Dynamic status updates use the same label catalog.
export function initializeInterface() {
  let locale = 'zh-CN', revision = 0;
  const picker = document.getElementById('uiLanguage');
  function render() {
    document.documentElement.lang = locale;
    picker.value = locale;
    const walker = document.createTreeWalker(document.documentElement, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const node of nodes) {
      if (node.parentElement?.closest('script,style,textarea,input,#uiLanguage')) continue;
      const value = translateLabel(node.data, locale);
      if (node.data !== value) node.data = value;
    }
    for (const node of document.querySelectorAll('[title],[placeholder]')) {
      for (const attr of ['title', 'placeholder']) if (node.hasAttribute(attr)) {
        const value = translateLabel(node.getAttribute(attr), locale);
        if (node.getAttribute(attr) !== value) node.setAttribute(attr, value);
      }
    }
  }
  const observer = new MutationObserver(render);
  observer.observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['title', 'placeholder'] });
  picker.addEventListener('change', async () => {
    revision++;
    locale = picker.value === 'en' ? 'en' : 'zh-CN';
    render();
    try { await chrome.storage.local.set({ uiLanguage: locale }); }
    catch (error) { document.getElementById('status').textContent = error.message; }
  });
  chrome.storage.onChanged?.addListener((changes, area) => {
    if (area !== 'local' || !changes.uiLanguage) return;
    revision++;
    locale = changes.uiLanguage.newValue === 'en' ? 'en' : 'zh-CN'; render();
  });
  render();
  const initialRevision = revision;
  chrome.storage.local.get('uiLanguage').then(result => {
    if (revision !== initialRevision) return;
    locale = result.uiLanguage === 'en' ? 'en' : 'zh-CN'; render();
  }).catch(() => {});
}
