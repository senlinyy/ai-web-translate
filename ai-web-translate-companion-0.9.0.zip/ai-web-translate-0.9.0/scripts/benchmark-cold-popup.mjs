import { chromium } from 'playwright';
import {mkdtemp,rm,cp,writeFile,readFile}from'node:fs/promises';import{tmpdir}from'node:os';import{join}from'node:path';
const results=[], runs=[];
const idleMs=Number(process.env.POPUP_IDLE_MS || 120000);
if(!Number.isFinite(idleMs) || idleMs < 0) throw new Error('Invalid idle time');
try {
for(const variant of (process.env.POPUP_VARIANTS || 'translator,minimal').split(',')){
const dir=await mkdtemp(join(tmpdir(),'cold-popup-')),ext=join(dir,'extension');await cp('extension',ext,{recursive:true});
if(variant==='minimal'){const manifest=JSON.parse(await readFile(join(ext,'manifest.json'),'utf8'));delete manifest.background;manifest.permissions=[];manifest.action.default_popup='minimal.html';await writeFile(join(ext,'manifest.json'),JSON.stringify(manifest));await writeFile(join(ext,'minimal.html'),'<html><body style="width:360px;height:500px">Minimal popup</body></html>')}
if(variant==='static-ui' || variant==='ascii-ui'){
 const manifest=JSON.parse(await readFile(join(ext,'manifest.json'),'utf8'));delete manifest.background;manifest.permissions=[];await writeFile(join(ext,'manifest.json'),JSON.stringify(manifest));
 let html=await readFile(join(ext,'popup.html'),'utf8');html=html.replace(/<script[^>]*>[\s\S]*?<\/script>/g,'');if(variant==='ascii-ui')html=html.replace(/[^\x00-\x7F]/g,'');await writeFile(join(ext,'popup.html'),html);
}
const context=await chromium.launchPersistentContext(join(dir,'profile'),{channel:'chromium',headless:true,ignoreDefaultArgs:['--disable-extensions','--disable-renderer-backgrounding','--disable-backgrounding-occluded-windows','--disable-background-timer-throttling'],args:[...(variant==='translator-loading-voter'?['--enable-features=PMLoadingPageVoter']:[]),'--enable-unsafe-extension-debugging',`--disable-extensions-except=${ext}`,`--load-extension=${ext}`]});
const pageCdp=await context.newCDPSession(context.pages()[0]);await pageCdp.send('ServiceWorker.enable');await pageCdp.send('ServiceWorker.stopAllWorkers');const cdp=await context.browser().newBrowserCDPSession();const targetInfo=(await cdp.send('Target.getTargets',{filter:[{type:'tab',exclude:false}]})).targetInfos[0];
runs.push({variant,dir,context,cdp,targetInfo});
}

console.log(`Waiting ${idleMs} ms with no extension-worker evaluation and normal background throttling.`);
await new Promise(resolve=>setTimeout(resolve,idleMs));
for(const {variant,context,cdp,targetInfo} of runs){
const start=performance.now();await cdp.send('Extensions.triggerAction',{id:'ehhdiglglbaildmebbnimknijndpaeoi',targetId:targetInfo.targetId});let target;for(let i=0;i<200;i++){target=(await cdp.send('Target.getTargets')).targetInfos.find(t=>t.type==='page'&&t.url.startsWith('chrome-extension:'));if(target)break;await new Promise(r=>setTimeout(r,10));}if(!target)throw new Error('No popup');const targetMs=performance.now()-start;
const {sessionId}=await cdp.send('Target.attachToTarget',{targetId:target.targetId,flatten:false});
let sequence=0;
const evaluate=expression=>new Promise(async(resolve,reject)=>{
 const id=++sequence;const timeout=setTimeout(()=>{cdp.off('Target.receivedMessageFromTarget',listener);reject(new Error('Inspection timeout'))},5000);
 const listener=e=>{if(e.sessionId!==sessionId)return;const message=JSON.parse(e.message);if(message.id!==id)return;clearTimeout(timeout);cdp.off('Target.receivedMessageFromTarget',listener);resolve(message.result?.result?.value)};
 cdp.on('Target.receivedMessageFromTarget',listener);
 try{await cdp.send('Target.sendMessageToTarget',{sessionId,message:JSON.stringify({id,method:'Runtime.evaluate',params:{expression,returnByValue:true}})})}catch(e){clearTimeout(timeout);cdp.off('Target.receivedMessageFromTarget',listener);reject(e)}
});
let doc;
for(let i=0;i<200;i++){doc=await evaluate('({state:document.readyState,visibility:document.visibilityState,loadMs:performance.getEntriesByType("navigation")[0]?.loadEventEnd})');if(doc?.state==='complete'&&doc.visibility==='visible')break;await new Promise(r=>setTimeout(r,10))}
if(doc?.state!=='complete'||doc.visibility!=='visible')throw new Error('Popup did not become visible');
results.push({variant,idleMs,triggerToTargetMs:targetMs,triggerToObservedVisibleMs:performance.now()-start,documentLoadMs:doc.loadMs});console.log(results.at(-1));
await context.close();
}
await writeFile(process.env.POPUP_REPORT || 'artifacts/cold-popup-timing.json',JSON.stringify({note:'Isolated headless Chrome; first action via Extensions.triggerAction after idle and worker stop. Normal background-throttling defaults restored. Target inspection can affect scheduling; not a physical toolbar click.',results},null,2)+'\n');
} finally {for(const {context,dir} of runs){await context.close();await rm(dir,{recursive:true,force:true})}}
