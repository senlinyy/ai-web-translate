// Concurrent streamed model calls, followed by a cached repeat. Uses only the bundled public quiz fixture.
import { chromium } from 'playwright';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createServer } from 'node:http';
import assert from 'node:assert/strict';
import { CodexRuntime } from '../companion/runtime.mjs';
import { base } from './paths.mjs';
const runtime = new CodexRuntime(JSON.parse(await readFile(join(base, 'companion/install.json'), 'utf8')));
const server = createServer(async (req, res) => {
  const module = ['/page-cache.js', '/page-translations.js', '/batch-plan.js'].includes(req.url);
  res.setHeader('Content-Type', module ? 'text/javascript' : 'text/html'); res.end(await readFile(module ? 'extension' + req.url : 'fixtures/quiz.html'));
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({ headless: true }); let calls = 0, blockCount = 0, sourceCharacters = 0, active = 0, peak = 0;
try {
  const page = await browser.newPage({ viewport: { width: 1180, height: 1700 } });
  await page.exposeFunction('translateWithCodex', async (input, requestId) => {
    calls++; active++; peak = Math.max(peak, active); blockCount += input.blocks.length; sourceCharacters += input.blocks.reduce((sum, block) => sum + block.text.length, 0);
    try { return await runtime.translate(input, AbortSignal.timeout(240000), row => { page.evaluate(({ requestId, row }) => window.callbacks.get(requestId)?.(row), { requestId, row }).catch(() => {}); }); } finally { active--; }
  });
  await page.goto(`http://127.0.0.1:${server.address().port}/`);
  await page.evaluate(async () => {
    const { PageCache } = await import('/page-cache.js'); const { PageTranslations } = await import('/page-translations.js');
    window.callbacks = new Map();
    const service = new PageTranslations(new PageCache(), async (input, signal, emit) => {
      const id = crypto.randomUUID(); callbacks.set(id, emit);
      try { return await window.translateWithCodex(input, id); } finally { callbacks.delete(id); }
    });
    window.chrome = { runtime: {
      onMessage: { addListener(fn) { window.listener = fn; } },
      async sendMessage(message) {
        if (message.type === 'cancel') { service.cancel(1); return { ok: true, result: {} }; }
        try {
          const result = await service.translate({ owner: 1, url: location.href, input: { blocks: message.blocks, model: 'gpt-6-luna', effort: 'low', language: 'Simplified Chinese', instructions: 'Translate without answering questions. Preserve product names and identifiers.', glossary: '' }, force: message.force, onProgress: translations => window.listener({ type: 'translationProgress', streamId: message.streamId, translations }, {}, () => {}) });
          return { ok: true, result };
        } catch (error) { return { ok: false, error: error.message }; }
      }
    } };
    window.command = message => new Promise(resolve => window.listener(message, {}, resolve));
  });
  await page.addScriptTag({ path: 'extension/content.js' });
  const firstStart = Date.now(); await page.evaluate(() => command({ type: 'start' }));
  await page.waitForFunction(() => document.querySelector('[data-codex-translation]:not(div)'));
  const firstVisibleMs = Date.now() - firstStart;
  await page.getByRole('status').filter({ hasText: 'page translated' }).waitFor({ timeout: 250000 });
  const firstMs = Date.now() - firstStart;
  assert.ok(calls > 0); assert.ok(peak >= 1 && peak <= 3);
  const firstModelCalls = calls; assert.ok(firstVisibleMs < firstMs);
  const secondStart = Date.now(); await page.evaluate(() => command({ type: 'start' }));
  await page.getByRole('status').filter({ hasText: 'loaded from cache' }).waitFor({ timeout: 5000 });
  const cachedMs = Date.now() - secondStart;
  assert.equal(calls, firstModelCalls, 'Cached repeat must not call Codex');
  const report = { model: 'gpt-6-luna', effort: 'low', blockCount, sourceCharacters, firstVisibleMs, firstMs, cachedMs, peakConcurrentThreads: peak, firstModelCalls, repeatModelCalls: 0 };
  await writeFile('artifacts/stream-benchmark.json', JSON.stringify(report, null, 2) + '\n');
  await page.screenshot({ path: 'artifacts/stream-live.png' });
  console.log(JSON.stringify(report, null, 2));
} finally { runtime.close(); await browser.close(); server.close(); }
