import { readFile, writeFile } from 'node:fs/promises';
// Keep the tiny action document self-contained; options still use ui.css.
const template = await readFile('extension/popup.template.html', 'utf8');
const css = await readFile('extension/ui.css', 'utf8');
await writeFile('extension/popup.html', template.replace('<!-- POPUP_STYLE -->', `<style>${css}\nhtml{width:360px}</style>`));
