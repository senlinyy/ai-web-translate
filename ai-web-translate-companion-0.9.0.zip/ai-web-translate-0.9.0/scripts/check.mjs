import { readdir, readFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
for (const directory of ['extension', 'companion', 'scripts', 'tests']) {
  for (const file of await readdir(directory)) if (/\.(mjs|js)$/.test(file)) execFileSync(process.execPath, ['--check', `${directory}/${file}`]);
}
const manifest = JSON.parse(await readFile('extension/manifest.json', 'utf8'));
if (manifest.manifest_version !== 3 || manifest.host_permissions) throw new Error('Unexpected extension permissions.');
console.log('JavaScript syntax and extension manifest checks passed.');
