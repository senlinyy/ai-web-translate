import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { CodexRuntime } from '../companion/runtime.mjs';
import { ClaudeRuntime } from '../companion/claude-runtime.mjs';
import { base } from './paths.mjs';
const config = JSON.parse(await readFile(join(base, 'companion/install.json'), 'utf8'));
const runtime = new CodexRuntime(config);
const claude = new ClaudeRuntime({ binary: config.claudeBinary, profile: config.profile });
const sample = { language: 'Simplified Chinese', instructions: 'Translate without answering the question.', glossary: '', effort: 'low', blocks: [{ id: 'sample', text: 'You have an Azure subscription. What should you do?' }] };
async function timed(label, model, engine) {
  const started = Date.now();
  const result = await engine.translate({ ...sample, model });
  console.log(JSON.stringify({ provider: label, ...result, model, effort: 'low', elapsedMs: Date.now() - started }, null, 2));
}
try {
  const state = await runtime.status();
  console.log(JSON.stringify({ runtime: 'connected', signedIn: state.signedIn, accountType: state.account?.type || null, extensionId: config.extensionId }, null, 2));
  const models = await runtime.request('model/list', { includeHidden: false });
  console.log(`Model discovery: ${models.data?.length ?? 0} models.`);
  if (process.argv.includes('--translate')) await timed('codex', 'gpt-6-luna', runtime);
} catch (error) { console.log(`Codex: ${error.message}`); } finally { runtime.close(); }
if (!config.claudeBinary) console.log('Claude Code: not found by the installer.');
else {
  try {
    const state = await claude.status();
    console.log(JSON.stringify({ claude: config.claudeBinary, signedIn: state.signedIn, authMethod: state.account?.type || null, plan: state.account?.planType || null }, null, 2));
    const model = process.argv.find(arg => arg.startsWith('--claude-model='))?.split('=')[1] || 'claude-haiku-5-5';
    if (process.argv.includes('--translate') && state.signedIn) await timed('claude', model, claude);
  } catch (error) { console.log(`Claude: ${error.message}`); }
}
