import { generateKeyPairSync, createHash } from 'node:crypto';
import { readFile, writeFile, mkdir, cp, chmod, rename, rm, access } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { HOST_NAME, LEGACY_HOST_NAME } from '../companion/protocol.mjs';
import { base, legacyBase, hostDir } from './paths.mjs';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const manifestPath = join(root, 'extension/manifest.json');
const manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
if (!manifest.key) {
  manifest.key = generateKeyPairSync('rsa', { modulusLength: 2048 }).publicKey.export({ type: 'spki', format: 'der' }).toString('base64');
  await writeFile(manifestPath, JSON.stringify(manifest, null, 2) + '\n');
}
const extensionId = createHash('sha256').update(Buffer.from(manifest.key, 'base64')).digest('hex').slice(0, 32).replace(/[0-9a-f]/g, c => String.fromCharCode(97 + parseInt(c, 16)));
// The Chrome Web Store assigns its own ID; record it in store/extension-id.txt (or pass --extension-id=<id>).
const storeIds = [
  ...await readFile(join(root, 'store/extension-id.txt'), 'utf8').then(text => text.split(/\s+/), () => []),
  ...process.argv.filter(arg => arg.startsWith('--extension-id=')).map(arg => arg.slice('--extension-id='.length))
].map(id => id.trim()).filter(Boolean);
for (const id of storeIds) if (!/^[a-p]{32}$/.test(id)) throw new Error(`Invalid Chrome extension ID: ${id}`);
const extensionIds = [...new Set([extensionId, ...storeIds])];
if (!['darwin', 'linux'].includes(process.platform)) throw new Error('This installer currently supports macOS and Linux.');
const exists = path => access(path).then(() => true, () => false);
// Keep the existing Codex sign-in when upgrading from Codex Web Translate.
if (!(await exists(base)) && await exists(legacyBase)) { await rename(legacyBase, base); console.log(`Moved ${legacyBase} to ${base}`); }
await rm(join(hostDir, LEGACY_HOST_NAME + '.json'), { force: true });

await mkdir(base, { recursive: true, mode: 0o700 });
// Pin a private runtime so new models work without changing the user's global Codex installation.
const runtimeVersion = '0.155.1';
const arch = { arm64: 'aarch64', x64: 'x86_64' }[process.arch];
if (!arch) throw new Error(`Unsupported CPU architecture: ${process.arch}`);
const target = `${arch}-${process.platform === 'darwin' ? 'apple-darwin' : 'unknown-linux-musl'}`;
const runtimeDir = join(base, 'runtime');
let binary = process.env.CODEX_TRANSLATE_BINARY;
if (!binary) {
  binary = join(runtimeDir, 'node_modules', '@openai', `codex-${process.platform}-${process.arch}`, 'vendor', target, 'bin', 'codex');
  let installed = false;
  try { installed = execFileSync(binary, ['--version'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim() === `codex-cli ${runtimeVersion}`; } catch {}
  if (!installed) {
    const args = ['install', '--prefix', runtimeDir, '--no-audit', '--no-fund', '--ignore-scripts', '--save-exact', `@openai/codex@${runtimeVersion}`];
    if (process.env.npm_execpath) execFileSync(process.execPath, [process.env.npm_execpath, ...args], { stdio: 'inherit' });
    else execFileSync('npm', args, { stdio: 'inherit' });
  }
}
console.log(execFileSync(binary, ['--version'], { encoding: 'utf8' }).trim());
// Claude models use the user's own Claude Code installation and sign-in (Chrome launches the host without the shell PATH).
let claudeBinary = process.env.CLAUDE_TRANSLATE_BINARY;
if (!claudeBinary) try { claudeBinary = execFileSync('/bin/sh', ['-lc', 'command -v claude'], { encoding: 'utf8' }).trim(); } catch {}
// Keep the launcher path (not its resolved version) so Claude Code updates keep working.
if (claudeBinary) {
  try { console.log(`Claude Code ${execFileSync(claudeBinary, ['--version'], { encoding: 'utf8' }).trim()}`); } catch { console.warn(`Warning: ${claudeBinary} --version failed.`); }
} else console.warn('Claude Code was not found. Install it and re-run this installer to use Claude models.');

await mkdir(hostDir, { recursive: true });
await cp(join(root, 'companion'), join(base, 'companion'), { recursive: true });
await writeFile(join(base, 'companion/install.json'), JSON.stringify({ extensionId, extensionIds, binary, claudeBinary, profile: join(base, 'profile') }, null, 2) + '\n', { mode: 0o600 });
const quote = value => "'" + value.replaceAll("'", "'\\''") + "'";
const launcher = join(base, 'launch-host');
await writeFile(launcher, `#!/bin/sh\nexec ${quote(process.execPath)} ${quote(join(base, 'companion/host.mjs'))} "$@"\n`, { mode: 0o700 });
await chmod(launcher, 0o700);
await writeFile(join(hostDir, HOST_NAME + '.json'), JSON.stringify({ name: HOST_NAME, description: 'Local AI Web Translate companion (Claude Code and Codex)', path: launcher, type: 'stdio', allowed_origins: extensionIds.map(id => `chrome-extension://${id}/`) }, null, 2) + '\n');
console.log(`Companion installed.\nExtension IDs: ${extensionIds.join(', ')}\nLoad unpacked: ${join(root, 'extension')}\nCodex: ${binary}\nClaude Code: ${claudeBinary || 'not found'}\nProfile: ${join(base, 'profile')}`);
