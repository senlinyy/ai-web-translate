// Builds the Chrome Web Store upload: the extension folder only, manifest.json at the zip root,
// without the development `key` (the store assigns its own) or build-only inputs.
import { mkdtemp, mkdir, cp, readFile, writeFile, rm, readdir, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const EXCLUDE = new Set(['popup.template.html', '.DS_Store']);
const manifest = JSON.parse(await readFile('extension/manifest.json', 'utf8'));
const { version } = JSON.parse(await readFile('package.json', 'utf8'));
if (manifest.version !== version) throw new Error(`manifest.json version ${manifest.version} does not match package.json ${version}.`);
for (const path of Object.values(manifest.icons || {})) await stat(join('extension', path));
if (!manifest.icons?.['128']) throw new Error('The store requires a 128 px icon in manifest.icons.');
if (manifest.description.length > 132) throw new Error('manifest description must be 132 characters or fewer.');
if (manifest.host_permissions) throw new Error('Unexpected required host permissions.');

const staging = await mkdtemp(join(tmpdir(), 'ai-translate-store-'));
try {
  await cp('extension', staging, { recursive: true, filter: source => !EXCLUDE.has(source.split('/').pop()) });
  const { key, ...storeManifest } = manifest;
  await writeFile(join(staging, 'manifest.json'), JSON.stringify(storeManifest, null, 2) + '\n');
  await mkdir('artifacts/store', { recursive: true });
  const archive = resolve('artifacts/store', `ai-web-translate-${version}-chrome-web-store.zip`);
  await rm(archive, { force: true });
  execFileSync('/usr/bin/zip', ['-q', '-r', '-X', archive, '.'], { cwd: staging });
  const files = execFileSync('/usr/bin/zipinfo', ['-1', archive], { encoding: 'utf8' }).trim().split('\n');
  if (files.includes('popup.template.html') || !files.includes('manifest.json') || !files.includes('popup.html')) throw new Error('Unexpected package contents.');
  const bytes = (await stat(archive)).size;
  const hash = createHash('sha256').update(await readFile(archive)).digest('hex');
  await writeFile(archive + '.sha256', `${hash}  ${archive.split('/').pop()}\n`);
  console.log(`Store package: ${archive}\nFiles: ${files.length} (${(bytes / 1024).toFixed(0)} KB)\nSHA-256: ${hash}\nmanifest key removed: ${!('key' in storeManifest)}`);
} finally { await rm(staging, { recursive: true, force: true }); }
