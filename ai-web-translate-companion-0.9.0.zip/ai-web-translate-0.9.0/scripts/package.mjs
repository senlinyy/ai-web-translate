import { mkdtemp, mkdir, cp, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
const { version } = JSON.parse(await readFile('package.json', 'utf8'));
const staging = await mkdtemp(join(tmpdir(), 'ai-translate-package-'));
const name = `ai-web-translate-${version}`;
try {
  await mkdir(join(staging, name));
  for (const path of ['extension', 'companion', 'scripts', 'tests', 'fixtures', 'README.md', 'package.json', 'package-lock.json']) await cp(path, join(staging, name, path), { recursive: true });
  // Ship the Chrome Web Store ID so the companion accepts the published extension.
  await cp('store/extension-id.txt', join(staging, name, 'store/extension-id.txt')).catch(() => {});
  // Never package machine-specific native registration or authentication state.
  await rm(join(staging, name, 'companion/install.json'), { force: true });
  await mkdir('artifacts', { recursive: true });
  const archive = resolve('artifacts', `${name}.zip`);
  await rm(archive, { force: true });
  execFileSync('/usr/bin/zip', ['-q', '-r', archive, name], { cwd: staging });
  const hash = createHash('sha256').update(await readFile(archive)).digest('hex');
  await writeFile(archive + '.sha256', `${hash}  ${name}.zip\n`);
  console.log(`Package: ${archive}\nSHA-256: ${hash}`);
} finally { await rm(staging, { recursive: true, force: true }); }
