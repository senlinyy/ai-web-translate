import { homedir } from 'node:os';
import { join } from 'node:path';
const mac = process.platform === 'darwin';
export const base = mac ? join(homedir(), 'Library/Application Support/AI Web Translate') : join(homedir(), '.local/share/ai-web-translate');
// Installs before 0.9.0 used the Codex-specific name; the installer moves that profile here.
export const legacyBase = mac ? join(homedir(), 'Library/Application Support/Codex Web Translate') : join(homedir(), '.local/share/codex-web-translate');
export const hostDir = mac ? join(homedir(), 'Library/Application Support/Google/Chrome/NativeMessagingHosts') : join(homedir(), '.config/google-chrome/NativeMessagingHosts');
