// Renders extension icons and Chrome Web Store images with the real extension UI.
// Translations are fixed sample text; no model or companion is contacted.
import { chromium } from 'playwright';
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';

const ICON_DIR = 'extension/icons', ASSETS = 'store/assets';
const GLYPH = '<path d="M4 5h8M8 3v2m2.5 0c-.8 3.6-3 6.4-6.5 8m2.5-5c1 1.9 2.6 3.4 4.5 4.4"/><path d="m12.5 21 4-9 4 9m-6.8-2.8h5.6"/>';
const iconSvg = size => `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 128 128">
  <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2f6f57"/><stop offset="1" stop-color="#193c34"/></linearGradient></defs>
  <rect x="${size <= 16 ? 0 : 4}" y="${size <= 16 ? 0 : 4}" width="${size <= 16 ? 128 : 120}" height="${size <= 16 ? 128 : 120}" rx="${size <= 16 ? 26 : 28}" fill="url(#g)"/>
  <g transform="translate(20 20) scale(3.67)" fill="none" stroke="#fff" stroke-width="${size <= 16 ? 2.6 : size <= 32 ? 2.2 : 1.9}" stroke-linecap="round" stroke-linejoin="round">${GLYPH}</g></svg>`;

// Sample article (original text) with reviewed Simplified Chinese translations.
const ARTICLE = [
  ['h1', 'Understanding Latency in Web Applications', '理解 Web 应用中的延迟'],
  ['p', 'Latency is the time between a user’s action and the moment they see a result. Even small delays add up: a page that waits on five slow requests in a row feels sluggish, no matter how fast each server is.', '延迟是指从用户执行操作到看到结果之间的时间。即使是很小的延迟也会累积：一个页面如果要依次等待五个缓慢的请求，无论每台服务器有多快，都会让人感觉迟缓。'],
  ['p', 'The first step is to measure where the time goes. Browser developer tools show every request on a timeline, so you can spot work that runs one after another when it could run in parallel.', '第一步是测量时间花在了哪里。浏览器开发者工具会在时间线上显示每个请求，帮助你发现那些本可以并行、却在依次执行的工作。'],
  ['h2', 'Three common fixes', '三种常见的改进方法'],
  ['li', 'Cache responses that rarely change, close to the user.', '在靠近用户的位置缓存很少变化的响应。'],
  ['li', 'Send independent requests at the same time instead of in sequence.', '让相互独立的请求同时发出，而不是逐个发送。'],
  ['li', 'Stream results as they become ready, so readers can start early.', '在结果就绪时立即流式返回，让读者可以更早开始阅读。'],
  ['p', 'None of these changes require new hardware. They come from looking at the timeline and asking which waits are truly necessary.', '这些改进都不需要新的硬件，它们来自于仔细查看时间线，并思考哪些等待是真正必要的。']
];
const TRANSLATIONS = Object.fromEntries(ARTICLE.map(([, en, zh]) => [en, zh]));
const articleHtml = (layout = '') => {
  let list = false, body = '';
  for (const [tag, en] of ARTICLE) {
    if (tag === 'li' && !list) { body += '<ul>'; list = true; }
    if (tag !== 'li' && list) { body += '</ul>'; list = false; }
    body += `<${tag}>${en}</${tag}>`;
  }
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Engineering Notes</title><style>
    body{margin:0;background:#fbfbf8;color:#1d2621;font:18px/1.7 Georgia,"Times New Roman",serif}
    .top{height:64px;border-bottom:1px solid #e5e7e1;display:flex;align-items:center;padding:0 48px;font:600 16px system-ui,sans-serif;letter-spacing:.2px;color:#3b4a43;background:#fff}
    article{max-width:720px;margin:44px auto 120px;padding:0 24px}h1{font-size:40px;line-height:1.2;margin:0 0 20px}h2{font-size:26px;margin:34px 0 10px}
    p{margin:0 0 22px}ul{padding-left:26px}li{margin:0 0 10px}.left article{margin-left:96px;max-width:700px}</style></head>
    <body class="${layout}"><div class="top" translate="no">Engineering Notes</div><article>${body}</article></body></html>`;
};
const fakeRuntime = () => {
  // Answers page and selection requests with the fixed sample translations.
  window.__listeners = [];
  window.chrome = {
    storage: { local: { store: { settings: { language: 'Simplified Chinese' }, uiLanguage: 'en', selectionInstructions: '' },
      async get(key) { return { [key]: this.store[key] }; }, async set() {} }, onChanged: { addListener() {} } },
    runtime: { onMessage: { addListener(fn) { window.__listeners.push(fn); } }, async sendMessage(message) {
      if (message.type === 'cancel') return { ok: true, result: {} };
      return { ok: true, result: { translations: message.blocks.map(block => ({ id: block.id, text: window.__translations[block.text.replace(/\s+/g, ' ').trim()] || block.text })) } };
    } }
  };
  window.__command = message => new Promise(resolve => window.__listeners[0](message, {}, resolve));
};
async function shot(page, path, options = {}) { await page.screenshot({ path, ...options }); console.log(`wrote ${path}`); }

await mkdir(ICON_DIR, { recursive: true }); await mkdir(ASSETS, { recursive: true });
const server = createServer((req, res) => { res.setHeader('content-type', 'text/html; charset=utf-8'); res.end(articleHtml(req.url.includes('left') ? 'left' : '')); });
await new Promise(done => server.listen(0, '127.0.0.1', done));
const articleUrl = `http://127.0.0.1:${server.address().port}/`;
const browser = await chromium.launch({ headless: true });
const profile = await mkdtemp(join(tmpdir(), 'store-assets-'));
let context;
try {
  // Icons.
  for (const size of [16, 32, 48, 128]) {
    const page = await browser.newPage({ viewport: { width: size, height: size } });
    await page.setContent(`<style>html,body{margin:0;background:transparent}</style>${iconSvg(size)}`);
    await shot(page, `${ICON_DIR}/icon-${size}.png`, { omitBackground: true });
    await page.close();
  }
  // Store icon (128 px with transparent padding is what the store recommends).
  { const page = await browser.newPage({ viewport: { width: 128, height: 128 } });
    await page.setContent(`<style>html,body{margin:0;background:transparent}</style><div style="padding:16px;line-height:0">${iconSvg(96)}</div>`);
    await shot(page, `${ASSETS}/store-icon-128.png`, { omitBackground: true }); await page.close(); }

  // 1. Bilingual article with the real content script.
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  await page.goto(articleUrl + '?left');
  await page.evaluate(fakeRuntime); await page.evaluate(map => { window.__translations = map; }, TRANSLATIONS);
  await page.addScriptTag({ path: 'extension/content.js' });
  await page.evaluate(() => window.__command({ type: 'start', uiLanguage: 'en' }));
  await page.getByRole('status').filter({ hasText: 'page translated' }).waitFor();
  const article = await page.screenshot();

  // Real popup from the loaded extension (no companion: it makes no requests when opened).
  context = await chromium.launchPersistentContext(profile, { channel: 'chromium', headless: true, args: [`--disable-extensions-except=${resolve('extension')}`, `--load-extension=${resolve('extension')}`] });
  const worker = context.serviceWorkers()[0] || await context.waitForEvent('serviceworker');
  const extensionId = new URL(worker.url()).host;
  const settingsPage = await context.newPage();
  await settingsPage.goto(`chrome-extension://${extensionId}/options.html`);
  await settingsPage.evaluate(() => chrome.storage.local.set({ uiLanguage: 'en', settings: { language: 'Simplified Chinese', model: 'claude-haiku-5-5', effort: 'low', instructions: 'Translate naturally and accurately. Keep product names and code in English.', glossary: 'latency = 延迟\nthroughput = 吞吐量\ncache = 缓存', sites: {} } }));
  const popup = await context.newPage();
  await popup.setViewportSize({ width: 360, height: 640 });
  await popup.goto(`chrome-extension://${extensionId}/popup.html`);
  await popup.waitForFunction(() => !document.getElementById('model').disabled && document.documentElement.lang === 'en');
  await popup.waitForTimeout(300);
  const popupImage = await popup.locator('body').screenshot();

  const compose = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  await compose.setContent(`<style>body{margin:0;position:relative;width:1280px;height:800px;overflow:hidden}
    .bg{position:absolute;inset:0}.pop{position:absolute;right:28px;top:14px;border-radius:12px;box-shadow:0 18px 50px #0003,0 2px 10px #0002;border:1px solid #dfe3dd;overflow:hidden;background:#f5f7f1}</style>
    <img class="bg" src="data:image/png;base64,${article.toString('base64')}"><img class="pop" src="data:image/png;base64,${popupImage.toString('base64')}">`);
  await compose.waitForFunction(() => [...document.images].every(image => image.complete));
  await shot(compose, `${ASSETS}/screenshot-1-bilingual-page.png`);

  // 2. Selection bubble card with the real selection script.
  const select = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  await select.goto(articleUrl);
  await select.evaluate(fakeRuntime); await select.evaluate(map => { window.__translations = map; }, TRANSLATIONS);
  await select.addScriptTag({ path: 'extension/selection.js' });
  await select.evaluate(() => {
    const p = document.querySelectorAll('p')[1], range = document.createRange(); range.selectNodeContents(p);
    getSelection().removeAllRanges(); getSelection().addRange(range);
    p.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, button: 0 }));
  });
  await select.locator('button.bubble').click();
  await select.locator('section.card').getByText('第一步是测量').waitFor();
  await shot(select, `${ASSETS}/screenshot-2-selection-card.png`);

  // 3. Settings: model, instructions, glossary, selection translation.
  await settingsPage.setViewportSize({ width: 1280, height: 800 });
  await settingsPage.reload();
  await settingsPage.waitForFunction(() => document.documentElement.lang === 'en' && document.getElementById('instructions').value);
  await settingsPage.evaluate(() => { document.getElementById('selectionInstructions').value = 'Keep technical terms in English and add the Chinese in parentheses.'; document.getElementById('status').textContent = ''; });
  await settingsPage.addStyleTag({ content: '.page{max-width:1100px!important}' });
  await settingsPage.locator('#form').scrollIntoViewIfNeeded();
  await settingsPage.evaluate(() => document.getElementById('form').scrollIntoView({ block: 'start' }));
  await shot(settingsPage, `${ASSETS}/screenshot-3-settings.png`);

  // Promo tiles.
  const tile = (width, height, big) => `<style>body{margin:0;width:${width}px;height:${height}px;display:flex;align-items:center;gap:${big ? 48 : 22}px;padding:0 ${big ? 96 : 34}px;box-sizing:border-box;
    background:linear-gradient(135deg,#f5f7f1 0%,#e3ecdf 100%);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#193c34}
    h1{margin:0;font-size:${big ? 64 : 34}px;letter-spacing:-1px;line-height:1.05}p{margin:${big ? 18 : 10}px 0 0;font-size:${big ? 28 : 15}px;white-space:nowrap;color:#40564d;line-height:1.35}
    .zh{font-size:${big ? 24 : 15}px;color:#245b46;margin-top:${big ? 10 : 6}px}</style>
    ${iconSvg(big ? 200 : 104)}<div><h1>AI Web Translate</h1><p>Read webpages in two languages<br>with Claude or ChatGPT.</p><p class="zh">原文与译文对照阅读</p></div>`;
  for (const [name, width, height, big] of [['promo-small-440x280.png', 440, 280, false], ['promo-marquee-1400x560.png', 1400, 560, true]]) {
    const promo = await browser.newPage({ viewport: { width, height } });
    await promo.setContent(tile(width, height, big));
    await shot(promo, `${ASSETS}/${name}`);
  }
  await writeFile(`${ASSETS}/README.md`, 'Generated by `npm run store:assets`. Screenshots use the real extension UI with fixed sample translations; no account details are shown.\n');
} finally {
  await context?.close(); await browser.close(); server.close(); await rm(profile, { recursive: true, force: true });
}
