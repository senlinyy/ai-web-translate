// Exercise Chrome's actual action-popup window, not popup.html in a normal tab.
import { chromium } from 'playwright';
import { mkdtemp, cp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import assert from 'node:assert/strict';
const dir = await mkdtemp(join(tmpdir(), 'translator-action-'));
const extension = join(dir, 'extension'); await cp('extension', extension, { recursive: true });
await writeFile(join(extension, 'control.html'), '<html><body style="width:360px;height:500px">Minimal popup</body></html>');
const context = await chromium.launchPersistentContext(join(dir, 'profile'), { channel: 'chromium', headless: true, ignoreDefaultArgs: ['--disable-renderer-backgrounding', '--disable-backgrounding-occluded-windows', '--disable-background-timer-throttling'], args: [`--disable-extensions-except=${resolve(extension)}`, `--load-extension=${resolve(extension)}`] });
try {
  const worker = context.serviceWorkers()[0] || await context.waitForEvent('serviceworker');
  const cdp = await context.newCDPSession(context.pages()[0]);
  const results = [];
  for (const popup of ['popup.html', 'control.html', 'popup.html', 'popup.html', 'control.html']) {
    const timing = await worker.evaluate(async popup => {
      await chrome.action.setPopup({ popup }); const start = performance.now();
      await chrome.action.openPopup(); return { popup, shownMs: performance.now() - start };
    }, popup);
    const target = (await cdp.send('Target.getTargets')).targetInfos.find(t => t.url.endsWith('/' + popup));
    assert(target, 'Chrome must create the actual popup target');
    const { sessionId } = await cdp.send('Target.attachToTarget', { targetId: target.targetId, flatten: false });
    const value = new Promise((resolve, reject) => {
      const timer = setTimeout(() => { cdp.off('Target.receivedMessageFromTarget', listener); reject(new Error('Popup inspection timed out')); }, 5000);
      const listener = event => {
        if (event.sessionId !== sessionId) return;
        const message = JSON.parse(event.message);
        if (message.id !== 1) return;
        clearTimeout(timer); cdp.off('Target.receivedMessageFromTarget', listener);
        resolve(message.result?.result?.value);
      };
      cdp.on('Target.receivedMessageFromTarget', listener);
    });
    await cdp.send('Target.sendMessageToTarget', { sessionId, message: JSON.stringify({ id: 1, method: 'Runtime.evaluate', params: { returnByValue: true, expression: `({loadMs:performance.getEntriesByType('navigation')[0].loadEventEnd,ready:document.readyState,width:document.body.getBoundingClientRect().width,visible:document.visibilityState,stylesheets:document.querySelectorAll('link[rel=stylesheet]').length})` } }) });
    const document = await value;
    assert.equal(document.ready, 'complete'); assert.equal(document.width, 360);
    if (popup === 'popup.html') assert.equal(document.stylesheets, 0, 'Initial popup must not fetch a blocking stylesheet');
    results.push({ ...timing, ...document });
    await cdp.send('Target.closeTarget', { targetId: target.targetId });
  }
  await writeFile('artifacts/action-popup-timing.json', JSON.stringify({ measurement: 'chrome.action.openPopup resolution after native popup ShowBubble; isolated headless Chrome with normal background throttling; worker is already running, so this is NOT a cold toolbar click', results }, null, 2) + '\n');
  console.log(JSON.stringify(results));
} finally { await context.close(); await rm(dir, { recursive: true, force: true }); }
