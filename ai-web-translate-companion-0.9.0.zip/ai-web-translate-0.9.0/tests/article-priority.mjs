import { chromium } from 'playwright';
import { readFile, writeFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import assert from 'node:assert/strict';

const fixture = `<!doctype html><style>body{font:16px system-ui}nav{display:flex;flex-wrap:wrap;gap:8px}aside{float:right;width:200px}article{max-width:650px}</style>
<nav>${Array.from({ length: 100 }, (_, i) => `<a id="label${i}" href="#">Menu label ${i}</a>`).join('')}</nav>
<aside><p id="sidebar">Sidebar story text</p></aside><article><h1 id="title">Article title</h1>
<p id="first">First paragraph ${'source '.repeat(450)}</p><p id="second">Second paragraph ${'source '.repeat(450)}</p></article>`;
const server = createServer(async (req, res) => {
  if (['/page-translations.js', '/page-cache.js', '/batch-plan.js'].includes(req.url)) {
    res.setHeader('content-type', 'text/javascript'); res.end(await readFile('extension' + req.url));
  } else { res.setHeader('content-type', 'text/html'); res.end(fixture); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({ channel: 'chromium', headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1200, height: 800 } });
  await page.goto(`http://127.0.0.1:${server.address().port}`);
  await page.evaluate(async () => {
    const { PageTranslations } = await import('/page-translations.js');
    window.requests = []; window.peak = 0; let active = 0;
    const service = new PageTranslations({ async get() { return null; }, async put() {} }, (input, signal, emit) => {
      active++; peak = Math.max(peak, active);
      return new Promise(resolve => requests.push({ input, emit, finish() {
        active--; resolve({ translations: input.blocks.map(block => ({ id: block.id, text: '译 ' + block.text })).reverse() });
      } }));
    });
    window.chrome = { runtime: { onMessage: { addListener(fn) { window.listener = fn; } }, async sendMessage(message) {
      if (message.type === 'cancel') { service.cancel(1); return { ok: true, result: {} }; }
      try { return { ok: true, result: await service.translate({ owner: 1, url: location.href, input: { blocks: message.blocks },
        onProgress: translations => listener({ type: 'translationProgress', streamId: message.streamId, translations }, {}, () => {}) }) }; }
      catch (error) { return { ok: false, error: error.message }; }
    } } };
    window.command = message => new Promise(resolve => listener(message, {}, resolve));
    window.emitRow = (request, index = 0) => { const block = requests[request].input.blocks[index]; requests[request].emit({ id: block.id, text: '译 ' + block.text }); };
  });
  await page.addScriptTag({ path: 'extension/content.js' });
  await page.evaluate(() => command({ type: 'start' }));
  // One balanced wave: every request starts at once and the article comes first.
  await page.waitForFunction(() => requests.length === 4);
  const plan = await page.evaluate(() => requests.map(request => request.input.blocks.map(block => block.kind)));
  assert.deepEqual(plan.slice(0, 2), [['main', 'main'], ['main']]);
  assert.equal(plan[2][0], 'secondary'); assert(plan.slice(2).flat().slice(1).every(kind => kind === 'label'));
  assert.equal(await page.evaluate(() => requests[0].input.blocks[0].text), 'Article title');
  await page.evaluate(() => emitRow(1));
  assert.equal(await page.locator('#second [data-codex-translation]').count(), 0, 'The second paragraph must wait for the title and first paragraph');
  await page.evaluate(() => emitRow(0));
  assert.equal(await page.locator('#title [data-codex-translation]').count(), 1, 'The title must show while navigation and paragraphs are still pending');
  assert.equal(await page.locator('#first [data-codex-translation]').count(), 0);
  await page.evaluate(() => { emitRow(2, 0); emitRow(3, 0); });
  assert.equal(await page.locator('#sidebar [data-codex-translation]').count(), 0, 'The sidebar must wait for the article');
  assert(await page.evaluate(() => [...document.querySelectorAll('nav a')].some(a => a.title.startsWith('译 '))), 'Labels can appear before the article finishes');
  await page.evaluate(() => requests[0].finish());
  assert.equal(await page.locator('#first [data-codex-translation]').count(), 1);
  assert.equal(await page.locator('#second [data-codex-translation]').count(), 1, 'The buffered second paragraph must show before its request finishes');
  assert.equal(await page.locator('#sidebar [data-codex-translation]').count(), 1);
  const labelSizes = await page.evaluate(() => requests.map(request => request.input.blocks.filter(block => block.kind === 'label').length).filter(Boolean));
  assert.equal(labelSizes.reduce((sum, size) => sum + size, 0), 100);
  assert(labelSizes.every(size => size <= 120));
  await page.evaluate(() => { for (const index of [1, 2, 3]) requests[index].finish(); });
  await page.getByRole('status').filter({ hasText: 'page translated' }).waitFor();
  assert.equal(await page.evaluate(() => peak), 4);
  assert(await page.evaluate(() => Array.from({ length: 100 }, (_, i) => document.querySelector(`#label${i}`).title).every((title, i) => title === `译 Menu label ${i}`)), 'Each grouped label must return to its own element');
  assert(await page.evaluate(() => ['title', 'first', 'second', 'sidebar'].every(id => {
    const element = document.getElementById(id), host = element.querySelector('[data-codex-translation]');
    const source = [...element.childNodes].filter(node => node !== host).map(node => node.textContent).join('').replace(/\s+/g, ' ').trim();
    return host.shadowRoot.querySelector('span').textContent === '译 ' + source;
  })), 'Reversed provider rows must still map to the correct paragraphs');
  await page.evaluate(() => { window.originalHost = document.querySelector('#title [data-codex-translation]'); document.querySelector('article').insertAdjacentHTML('beforeend', '<p id="new">New article paragraph</p>'); });
  await page.waitForFunction(() => requests.length === 5);
  assert.deepEqual(await page.evaluate(() => requests[4].input.blocks.map(block => block.text)), ['New article paragraph']);
  assert(await page.evaluate(() => originalHost === document.querySelector('#title [data-codex-translation]')));
  await page.evaluate(() => requests[4].finish());
  await page.waitForFunction(() => document.querySelector('#new [data-codex-translation]'));
  await page.screenshot({ path: 'artifacts/article-priority.png' });
  await writeFile('artifacts/batch-planning.json', JSON.stringify({ controlledFixture: true, labels: 100, requestsForWholePage: 4, labelBatchSizes: labelSizes, firstRequests: 'title + first paragraph, second paragraph, sidebar + labels, labels', peakConcurrentRequests: 4, liveModelLatencyMeasured: false }, null, 2) + '\n');
  await page.evaluate(() => command({ type: 'restore' }));
  assert.equal(await page.locator('[data-codex-translation]').count(), 0);
  assert.equal(await page.locator('#label0').getAttribute('title'), null);
  console.log('Article priority passed: the page is one wave of four parallel requests, article order holds, labels never block the article, IDs map correctly, new text keeps existing translations, and restore clears all output.');
} finally { await browser.close(); server.close(); }
