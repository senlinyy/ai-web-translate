import test from 'node:test';
import assert from 'node:assert/strict';
import { planBatches, BATCH_LIMITS, CONCURRENCY, providerOf } from '../extension/batch-plan.js';
import { PageTranslations, validatePageBlocks } from '../extension/page-translations.js';

test('article requests precede sidebar and labels and keep source order', () => {
  const labels = Array.from({ length: 100 }, (_, i) => ({ id: `label${i}`, text: `Menu label ${i}`, kind: 'label' }));
  const title = { id: 'title', text: 'Article title', kind: 'main' };
  const paragraph = { id: 'paragraph', text: 'Article text. '.repeat(250), kind: 'main' };
  const side = { id: 'side', text: 'Sidebar story', kind: 'secondary' };
  const batches = planBatches([...labels, side, title, paragraph]);
  assert.deepEqual(batches.flat(), [title, paragraph, side, ...labels]);
  assert.equal(batches[0][0].id, 'title');
  assert(batches.length <= CONCURRENCY.codex, 'A wave this size fits in one round of parallel requests');
  assert(batches.every(batch => batch.length <= BATCH_LIMITS.blocks));
  assert.throws(() => validatePageBlocks([{ id: 'bad', text: 'Source', kind: 'unknown' }]), /Invalid/);
});

test('a short page is one request; a long page is split into balanced parallel requests', () => {
  const short = Array.from({ length: 12 }, (_, i) => ({ id: `s${i}`, text: 'Short paragraph '.repeat(4), kind: 'main' }));
  assert.equal(planBatches(short).length, 1);
  const long = Array.from({ length: 300 }, (_, i) => ({ id: `b${i}`, text: 'A longer article paragraph. '.repeat(7), kind: 'main' }));
  for (const [provider, limit] of Object.entries(CONCURRENCY)) {
    const batches = planBatches(long, limit);
    assert.deepEqual(batches.flat(), long);
    assert.equal(batches.length, limit, provider);
    const sizes = batches.map(batch => batch.reduce((sum, block) => sum + block.text.length, 0));
    assert(Math.max(...sizes) / Math.min(...sizes) < 1.2, 'Parallel requests should finish at about the same time');
  }
  const labels = Array.from({ length: 500 }, (_, i) => ({ id: `l${i}`, text: 'Menu', kind: 'label' }));
  assert(planBatches(labels).every(batch => batch.length <= BATCH_LIMITS.blocks));
  assert.equal(providerOf('claude-haiku-5-5'), 'claude'); assert.equal(providerOf('gpt-6-luna'), 'codex');
});

test('grouped and reordered results return to the caller IDs and survive cache reuse', async () => {
  const stored = new Map(), calls = [];
  const service = new PageTranslations({ async get(key) { return stored.get(key); }, async put(key, texts) { stored.set(key, texts); } }, async input => {
    calls.push(input.blocks);
    return { translations: input.blocks.map(block => ({ id: block.id, text: '译 ' + block.text })).reverse() };
  });
  const blocks = [{ id: 'label', text: 'Menu', kind: 'label' }, { id: 'title', text: 'Title', kind: 'main' }];
  const first = await service.translate({ owner: 1, url: 'https://example.com', input: { blocks } });
  assert.deepEqual(calls.map(batch => batch.map(block => block.id)), [['title', 'label']]);
  assert.deepEqual(first.translations, blocks.map(block => ({ id: block.id, text: '译 ' + block.text })));
  const nextBlocks = blocks.map(block => ({ ...block, id: 'new_' + block.id }));
  const second = await service.translate({ owner: 1, url: 'https://example.com', input: { blocks: nextBlocks } });
  assert.equal(second.cached, true); assert.equal(calls.length, 1);
  assert.deepEqual(second.translations, nextBlocks.map(block => ({ id: block.id, text: '译 ' + block.text })));
});
