import { chromium } from 'playwright';
import { readFile, mkdir } from 'node:fs/promises';
import { createServer } from 'node:http';
import assert from 'node:assert/strict';
const fixture = await readFile('fixtures/quiz.html');
const server = createServer((_req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fixture); });
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({ headless: true });
await mkdir('artifacts', { recursive: true });
try {
  const page = await browser.newPage({ viewport: { width: 1180, height: 1700 } });
  await page.addInitScript(() => {
    window.requests = []; window.delay = 0; window.fail = false;
    window.chrome = { runtime: {
      onMessage: { addListener(fn) { window.extensionListener = fn; } },
      async sendMessage(message) {
        if (message.type === 'cancel') return { ok: true, result: {} };
        window.requests.push(message);
        if (window.delay) await new Promise(resolve => setTimeout(resolve, window.delay));
        if (window.fail) return { ok: false, error: 'Test connection failure' };
        const dictionary = {
          'Cloud knowledge check': '云知识测验',
          'Practice / Azure governance': '练习 / Azure 治理',
          'You have an Azure subscription linked to an Azure Active Directory tenant. The tenant includes a user account named User1.': '你有一个与 Azure Active Directory 租户关联的 Azure 订阅。该租户包含一个名为 User1 的用户帐户。',
          'You need to ensure that User1 can assign a policy to the tenant root management group.': '你需要确保 User1 能够将策略分配给租户根管理组。',
          'What should you do?': '你应该怎么做？',
          'Choose one answer.': '请选择一个答案。',
          'Assign the Owner role for the Azure Subscription to User1, and then modify the default conditional access policies.': '将 Azure 订阅的所有者角色分配给 User1，然后修改默认的条件访问策略。',
          'Assign the Owner role for the Azure subscription to User1, and then instruct User1 to configure access management for Azure resources.': '将 Azure 订阅的所有者角色分配给 User1，然后指示 User1 配置 Azure 资源的访问管理。',
          'Assign the Global administrator role to User1, and then instruct User1 to configure access management for Azure resources.': '将全局管理员角色分配给 User1，然后指示 User1 配置 Azure 资源的访问管理。',
          'Create a new management group and delegate User1 as the owner of the new management group.': '创建一个新的管理组，并将 User1 指定为该管理组的所有者。'
        };
        return { ok: true, result: { translations: message.blocks.map(b => ({ id: b.id, text: dictionary[b.text] || `译文：${b.text}` })) } };
      }
    } };
    window.command = message => new Promise(resolve => window.extensionListener(message, {}, resolve));
  });
  await page.goto(`http://127.0.0.1:${server.address().port}`);
  await page.addScriptTag({ path: 'extension/content.js' });
  const command = message => page.evaluate(m => window.command(m), message);
  await command({ type: 'start' });
  await page.waitForFunction(() => document.querySelector('#answer-c [data-codex-translation]'));
  assert.equal(await page.locator('#answer-c [data-codex-translation]').count(), 1);
  await page.locator('#answer-c').click(); assert.equal(await page.evaluate(() => answerClicks), 1);
  assert.equal(await page.locator('#inline a').getAttribute('href'), '#reference');
  const sent = await page.evaluate(() => requests.flatMap(r => r.blocks).map(b => b.text).join('\n'));
  assert(!sent.includes('Private value')); assert(!sent.includes('Private editable')); assert(!sent.includes('do_not_translate')); assert(!sent.includes('Do not translate this paragraph.'));
  assert(sent.includes('Additional content appears'), 'The first request must include loaded text below the viewport');
  assert.equal(await page.evaluate(() => requests.length), 1, 'The content script must submit one logical page request');
  await page.screenshot({ path: 'artifacts/quiz-bilingual.png', fullPage: false });
  const count = await page.locator('[data-codex-translation]').count();
  await page.evaluate(() => dispatchEvent(new Event('scroll'))); await page.waitForTimeout(400);
  assert.equal(await page.locator('[data-codex-translation]').count(), count, 'Repeated scans must not duplicate translations');
  await page.evaluate(() => { document.querySelector('#dynamic').innerHTML = '<p id="new-text">A new question loaded.</p>'; });
  await page.locator('#new-text').scrollIntoViewIfNeeded();
  await page.waitForFunction(() => document.querySelector('#new-text [data-codex-translation]'));
  await page.locator('#below').scrollIntoViewIfNeeded();
  await page.waitForFunction(() => document.querySelector('#below [data-codex-translation]'));
  await command({ type: 'restore' }); assert.equal(await page.locator('[data-codex-translation]').count(), 0);
  // Page changes while a request is in flight must never receive stale translations.
  await page.evaluate(() => { window.delay = 180; document.querySelector('#new-text').textContent = 'Before update'; });
  await page.locator('#new-text').scrollIntoViewIfNeeded(); await command({ type: 'start' });
  await page.evaluate(() => { document.querySelector('#new-text').textContent = 'After update'; });
  await page.waitForFunction(() => document.querySelector('#new-text [data-codex-translation]')?.shadowRoot.textContent.includes('After update'));
  assert(!(await page.locator('#new-text').textContent()).includes('Before update'));
  await command({ type: 'restore' });
  // Refresh during a pending request must schedule a new whole-page request, even for identical content.
  await page.evaluate(() => { window.requests = []; });
  await command({ type: 'start' }); await command({ type: 'start', force: true });
  await page.waitForFunction(() => requests.length === 2);
  await page.waitForFunction(() => document.querySelector('#below [data-codex-translation]'));
  assert.equal(await page.evaluate(() => requests[1].force), true);
  await command({ type: 'restore' });
  // Restore cancels rendering, even when a response arrives later.
  await page.evaluate(() => { window.requests = []; });
  await command({ type: 'start' }); await command({ type: 'start' });
  assert.equal(await page.evaluate(() => requests.length), 1, 'Repeated clicks must reuse the in-flight request');
  await command({ type: 'restore' }); await page.waitForTimeout(400);
  assert.equal(await page.locator('[data-codex-translation]').count(), 0);
  await page.evaluate(() => { window.delay = 0; const range = document.createRange(); range.selectNodeContents(document.querySelector('#question p')); const selection = getSelection(); selection.removeAllRanges(); selection.addRange(range); });
  await command({ type: 'start', selection: true }); await page.waitForFunction(() => document.querySelector('#question p [data-codex-translation]'));
  assert.equal(await page.locator('#question [data-codex-translation]').count(), 1);
  await command({ type: 'restore' });
  await page.evaluate(() => { window.fail = true; window.requests = []; }); await command({ type: 'start' });
  await page.waitForTimeout(300); await page.evaluate(() => dispatchEvent(new Event('scroll'))); await page.waitForTimeout(400);
  assert.equal(await page.evaluate(() => requests.length), 1, 'Failures pause instead of retrying on every scan');
  const errors = []; page.on('pageerror', error => errors.push(error.message));
  await page.evaluate(() => { window.fail = false; }); await page.getByRole('button', { name: 'Retry', exact: true }).click();
  await page.waitForFunction(() => document.querySelector('#below [data-codex-translation]'));
  assert.deepEqual(errors, []);
  await command({ type: 'restore' });
  // Streamed blocks render before the final response, in captured reading order.
  await page.evaluate(() => { window.delay = 700; window.requests = []; });
  await command({ type: 'start' });
  await page.evaluate(() => {
    const request = requests.at(-1); window.streamRequest = request;
    const row = index => ({ id: request.blocks[index].id, text: 'Stream ' + index });
    extensionListener({ type: 'translationProgress', streamId: request.streamId, translations: [row(1)] }, {}, () => {});
  });
  assert.equal(await page.locator('span[data-codex-translation]').count(), 0);
  await page.evaluate(() => extensionListener({ type: 'translationProgress', streamId: streamRequest.streamId, translations: [{ id: streamRequest.blocks[0].id, text: 'Stream 0' }] }, {}, () => {}));
  assert.equal(await page.locator('span[data-codex-translation]').count(), 2);
  await command({ type: 'restore' });
  await page.evaluate(() => extensionListener({ type: 'translationProgress', streamId: streamRequest.streamId, translations: [{ id: streamRequest.blocks[2].id, text: 'Late' }] }, {}, () => {}));
  await page.waitForTimeout(800);
  assert.equal(await page.locator('[data-codex-translation]').count(), 0);
  await page.evaluate(() => { document.querySelector('#dynamic').innerHTML = '<p>' + 'Long text '.repeat(7000) + '</p>'; window.requests = []; });
  await command({ type: 'start' });
  await page.waitForFunction(() => document.querySelector('#dynamic [data-codex-translation]'), { timeout: 10000 });
  assert(await page.evaluate(() => requests.length > 1 && requests.every(r => r.blocks.length <= 600 && r.blocks.reduce((n, b) => n + b.text.length, 0) <= 60000)), 'Large pages must use bounded waves without dropping text');
  console.log('Browser checks passed: quiz layout, interaction, exclusions, whole-page batching, dynamic content, stale responses, selection, cancellation, and bounded retry.');
} finally { await browser.close(); server.close(); }
