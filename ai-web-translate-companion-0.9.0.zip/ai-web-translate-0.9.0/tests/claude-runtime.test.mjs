import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { ClaudeRuntime } from '../companion/claude-runtime.mjs';
const input = { language: 'Simplified Chinese', instructions: 'Keep names.', glossary: 'LLM = 大语言模型', model: 'claude-haiku-5-5', effort: 'low', blocks: [{ id: 'a', text: 'Hello' }, { id: 'b', text: 'World' }] };
async function setup(t, name = 'claude') {
  const profile = await mkdtemp(join(tmpdir(), `translator-${name}-`));
  t.after(() => rm(profile, { recursive: true, force: true }));
  return { runtime: new ClaudeRuntime({ binary: resolve('tests/fake-claude.mjs'), profile }), profile };
}
const lastCall = async profile => JSON.parse(await readFile(join(profile, 'claude-workspace/last-call.json'), 'utf8'));

test('Claude streams complete rows and runs headless without tools or inherited keys', async t => {
  const { runtime, profile } = await setup(t);
  process.env.ANTHROPIC_API_KEY = 'must-not-leak';
  t.after(() => { delete process.env.ANTHROPIC_API_KEY; });
  const streamed = [];
  const result = await runtime.translate(input, undefined, row => streamed.push(row));
  assert.deepEqual(result.translations, [{ id: 'a', text: '译文 Hello' }, { id: 'b', text: '译文 World' }]);
  assert.deepEqual(streamed, result.translations);
  const { args, env } = await lastCall(profile);
  for (const flag of ['-p', '--strict-mcp-config', '--disable-slash-commands', '--no-session-persistence']) assert(args.includes(flag), flag);
  assert.equal(args[args.indexOf('--tools') + 1], '');
  assert.equal(args[args.indexOf('--setting-sources') + 1], '');
  assert.equal(args[args.indexOf('--model') + 1], 'claude-haiku-5-5');
  assert.equal(args[args.indexOf('--effort') + 1], 'low');
  const system = args[args.indexOf('--system-prompt') + 1];
  assert.match(system, /untrusted/); assert.match(system, /LLM = 大语言模型/); assert.match(system, /Simplified Chinese/);
  assert(!env.includes('ANTHROPIC_API_KEY'));
});

test('Claude status reports the signed-in subscription', async t => {
  const { runtime } = await setup(t);
  const status = await runtime.status();
  assert.equal(status.provider, 'claude'); assert.equal(status.signedIn, true); assert.equal(status.account.planType, 'max');
});

test('Claude effort outside its levels is omitted; code fences and retried messages are tolerated', async t => {
  const { runtime, profile } = await setup(t);
  const fenced = await runtime.translate({ ...input, effort: '', blocks: [{ id: 'f', text: 'fenced' }] });
  assert.deepEqual(fenced.translations, [{ id: 'f', text: '译文 fenced' }]);
  assert(!(await lastCall(profile)).args.includes('--effort'));
  const streamed = [];
  const retried = await runtime.translate({ ...input, blocks: [{ id: 'r', text: 'retry' }, { id: 's', text: 'second' }] }, undefined, row => streamed.push(row));
  assert.equal(retried.translations.length, 2); assert.equal(streamed.length, 2);
});

test('Claude sign-in failures and cancellation produce clear errors', async t => {
  const { runtime } = await setup(t);
  await assert.rejects(runtime.translate({ ...input, blocks: [{ id: 'u', text: 'unauthorized' }] }), /claude auth login/);
  await assert.rejects(runtime.translate({ ...input, blocks: [{ id: 'o', text: 'old-cli' }] }), /claude update/);
  const controller = new AbortController();
  setTimeout(() => controller.abort(), 300);
  await assert.rejects(runtime.translate({ ...input, blocks: [{ id: 't', text: 'timeout' }] }, controller.signal), /cancelled/);
  const signedOut = await setup(t, 'signed-out');
  await assert.rejects(signedOut.runtime.translate(input), /not signed in/);
});
