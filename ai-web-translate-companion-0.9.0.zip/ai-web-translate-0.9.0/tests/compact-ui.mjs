import { chromium } from 'playwright';
import assert from 'node:assert/strict';
const browser = await chromium.launch({ channel:'chromium', headless:true });
try {
 const page = await browser.newPage({viewport:{width:1000,height:600}});
 await page.setContent(`<style>body{font:18px system-ui}nav{height:32px;display:flex;gap:20px;overflow:visible}a{color:inherit}aside{width:240px}aside a{display:flex;align-items:center;gap:14px;height:70px}small{display:block}article{margin-top:50px}</style><nav><a id="world" href="#" title="World section">World</a><a href="#">Markets and Finance</a><a href="#">Politics</a></nav><nav id="second"><a href="#">Election coverage</a></nav><aside><a id="bilingual" href="#"><span>Overview<small>概览</small></span><span>主页</span></a><a id="saved" href="#"><span>Saved questions</span></a></aside><article><h1>Article title here</h1><p>Article text should still have a translation below the original.</p></article>`);
 await page.evaluate(()=>{
  window.before=[...document.querySelectorAll('nav,aside a,article')].map(el=>({el,rect:el.getBoundingClientRect().toJSON()}));
  window.sent=[];window.chrome={runtime:{onMessage:{addListener(fn){window.listener=fn}},async sendMessage(m){if(m.type==='cancel')return {ok:true,result:{}}; sent.push(...m.blocks);return {ok:true,result:{translations:m.blocks.map(b=>({id:b.id,text:'中文译文'}))}}}}};
  window.command=m=>new Promise(resolve=>listener(m,{},resolve));
 });
 await page.addScriptTag({path:'extension/content.js'});
 await page.evaluate(()=>command({type:'start'}));
 await page.waitForFunction(()=>document.querySelector('article p [data-codex-translation]'));
 assert.equal(await page.locator('#world').getAttribute('title'),'World section\n中文译文');
 assert.equal(await page.locator('#saved').getAttribute('title'),'中文译文');
 assert.equal(await page.locator('#bilingual [data-codex-translation]').count(),0);
 assert(await page.evaluate(()=>!sent.some(b=>b.text.includes('Overview'))));
 assert(await page.evaluate(()=>before.every(({el,rect})=>{const now=el.getBoundingClientRect();return now.top===rect.top && now.width===rect.width && (el.tagName==='ARTICLE'||now.height===rect.height)})), 'Compact labels must not resize navigation or move subsequent rows');
 await page.screenshot({path:'artifacts/compact-ui.png'});
 await page.evaluate(()=>command({type:'restore'}));
 assert.equal(await page.locator('#world').getAttribute('title'),'World section');
 assert.equal(await page.locator('#saved').getAttribute('title'),null);
 console.log('Compact UI passed: unchanged nav/sidebar geometry, existing bilingual labels skipped, article stacked, original tooltips restored.');
} finally {await browser.close();}
