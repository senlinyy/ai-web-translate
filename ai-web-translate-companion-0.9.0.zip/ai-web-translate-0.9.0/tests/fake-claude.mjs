#!/usr/bin/env node
import { writeFileSync } from 'node:fs';
const args = process.argv.slice(2);
const send = value => process.stdout.write(JSON.stringify(value) + '\n');
if (args[0] === 'auth') {
  send({ loggedIn: !process.cwd().includes('signed-out'), authMethod: 'claude.ai', email: 'reader@example.com', subscriptionType: 'max' });
  process.exit(0);
}
// Record the invocation in the private workspace so tests can inspect flags and environment.
writeFileSync('last-call.json', JSON.stringify({ args, env: Object.keys(process.env) }));
let input = '';
process.stdin.on('data', chunk => { input += chunk; });
process.stdin.on('end', async () => {
  const { sourceBlocks } = JSON.parse(input);
  send({ type: 'system', subtype: 'init', tools: [], mcp_servers: [] });
  if (sourceBlocks.some(b => b.text === 'timeout')) return setTimeout(() => {}, 60000);
  if (sourceBlocks.some(b => b.text === 'old-cli')) {
    send({ type: 'result', subtype: 'success', is_error: true, result: 'API Error: 400 {"error":{"message":"Claude Code 2.1.123 does not support this model","details":{"error_code":"claude_code_version_too_old"}}}' });
    return;
  }
  if (sourceBlocks.some(b => b.text === 'unauthorized')) {
    send({ type: 'result', subtype: 'success', is_error: true, result: 'Failed to authenticate. API Error: 401 OAuth access token is invalid.' });
    return;
  }
  const text = (sourceBlocks.some(b => b.text === 'fenced') ? '```json\n' : '') + JSON.stringify({ translations: sourceBlocks.map(b => ({ id: b.id, text: '译文 ' + b.text })) }) + (sourceBlocks.some(b => b.text === 'fenced') ? '\n```' : '');
  const message = async () => {
    send({ type: 'stream_event', event: { type: 'message_start', message: {} } });
    for (let i = 0; i < text.length; i += 7) {
      send({ type: 'stream_event', event: { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: text.slice(i, i + 7) } } });
      await new Promise(resolve => setImmediate(resolve));
    }
  };
  await message();
  // Simulate a retried message that repeats earlier rows.
  if (sourceBlocks.some(b => b.text === 'retry')) await message();
  send({ type: 'result', subtype: 'success', is_error: false, result: text });
});
