#!/usr/bin/env node
import { createInterface } from 'node:readline';
const send = value => process.stdout.write(JSON.stringify(value) + '\n');
let sequence = 0;
createInterface({ input: process.stdin }).on('line', line => {
  const { id, method, params } = JSON.parse(line); if (id === undefined) return;
  let result = {};
  if (method === 'initialize') result = { userAgent: 'test' };
  if (method === 'account/read') result = { account: { type: 'chatgpt', email: 'test@example.invalid' } };
  if (method === 'thread/start') { result = { thread: { id: `thread-${++sequence}` } }; send({ method: 'test/thread', params }); }
  if (method === 'turn/start') {
    send({ method: 'test/turn', params });
    const blocks = JSON.parse(params.input[0].text).sourceBlocks;
    if (blocks[0].text === 'timeout') { send({ id, result: { turn: { id: 'turn-pending' } } }); return; }
    const translations = blocks.map(b => ({ id: b.id, text: `译文 ${b.text}` }));
    for (const delta of JSON.stringify({ translations }).match(/.{1,7}/gs)) send({ method: 'item/agentMessage/delta', params: { threadId: params.threadId, itemId: 'answer', delta } });
    // Deliberately deliver completion before the response, which is legal on an event stream.
    send({ method: 'item/completed', params: { threadId: params.threadId, item: { type: 'agentMessage', text: JSON.stringify({ translations }) } } });
    send({ method: 'turn/completed', params: { threadId: params.threadId, turn: { id: 'turn-1', status: 'completed' } } });
    result = { turn: { id: 'turn-1' } };
  }
  send({ id, result });
});
