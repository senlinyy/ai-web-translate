import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtemp, cp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { FrameDecoder, encodeFrame } from '../companion/protocol.mjs';

test('native host forwards streamed rows with request IDs before final responses', { timeout: 10000 }, async t => {
  const dir = await mkdtemp(join(tmpdir(), 'translator-host-'));
  await cp('companion', join(dir, 'companion'), { recursive: true });
  await writeFile(join(dir, 'companion/install.json'), JSON.stringify({ extensionId: 'test', binary: resolve('tests/fake-codex.mjs'), profile: join(dir, 'profile') }));
  const proc = spawn(process.execPath, [join(dir, 'companion/host.mjs'), 'chrome-extension://test/'], { stdio: ['pipe', 'pipe', 'pipe'] });
  t.after(async () => { proc.stdin.end(); await new Promise(resolve => proc.once('exit', resolve)); await rm(dir, { recursive: true, force: true }); });
  const progress = new Map(), finals = [];
  const complete = new Promise((resolve, reject) => {
    proc.on('error', reject);
    const decoder = new FrameDecoder(message => {
      if (message.event === 'translationProgress') { assert(!finals.includes(message.id)); progress.set(message.id, message.translation); }
      else {
        if (message.error) return reject(new Error(message.error));
        assert.deepEqual(progress.get(message.id), message.result.translations[0]);
        finals.push(message.id); if (finals.length === 3) resolve();
      }
    });
    proc.stdout.on('data', chunk => { try { decoder.push(chunk); } catch (error) { reject(error); } });
  });
  for (let i = 0; i < 3; i++) proc.stdin.write(encodeFrame({ id: 'r' + i, method: 'translate', params: { blocks: [{ id: 'b' + i, text: 'Hello ' + i }] } }));
  await complete; assert.equal(progress.size, 3);
});

test('native host routes Claude models and Claude status to Claude Code', { timeout: 10000 }, async t => {
  const dir = await mkdtemp(join(tmpdir(), 'translator-host-claude-'));
  await cp('companion', join(dir, 'companion'), { recursive: true });
  await writeFile(join(dir, 'companion/install.json'), JSON.stringify({ extensionId: 'test', binary: resolve('tests/fake-codex.mjs'), claudeBinary: resolve('tests/fake-claude.mjs'), profile: join(dir, 'profile') }));
  const proc = spawn(process.execPath, [join(dir, 'companion/host.mjs'), 'chrome-extension://test/'], { stdio: ['pipe', 'pipe', 'pipe'] });
  t.after(async () => { proc.stdin.end(); await new Promise(resolve => proc.once('exit', resolve)); await rm(dir, { recursive: true, force: true }); });
  const responses = new Map(), progress = [];
  const done = new Promise((resolve, reject) => {
    const decoder = new FrameDecoder(message => {
      if (message.event === 'translationProgress') return progress.push(message.translation);
      responses.set(message.id, message); if (responses.size === 2) resolve();
    });
    proc.stdout.on('data', chunk => { try { decoder.push(chunk); } catch (error) { reject(error); } });
  });
  proc.stdin.write(encodeFrame({ id: 'status', method: 'status', params: { provider: 'claude' } }));
  proc.stdin.write(encodeFrame({ id: 'claude', method: 'translate', params: { model: 'claude-sonnet-5-5', blocks: [{ id: 'x', text: 'Hello' }] } }));
  await done;
  assert.equal(responses.get('status').result.provider, 'claude');
  assert.deepEqual(responses.get('claude').result.translations, [{ id: 'x', text: '译文 Hello' }]);
  assert.deepEqual(progress, [{ id: 'x', text: '译文 Hello' }]);
});

test('native host accepts every registered extension ID and rejects others', { timeout: 10000 }, async t => {
  const dir = await mkdtemp(join(tmpdir(), 'translator-host-ids-'));
  await cp('companion', join(dir, 'companion'), { recursive: true });
  await writeFile(join(dir, 'companion/install.json'), JSON.stringify({ extensionId: 'dev', extensionIds: ['dev', 'store'], binary: resolve('tests/fake-codex.mjs'), profile: join(dir, 'profile') }));
  t.after(() => rm(dir, { recursive: true, force: true }));
  const run = origin => new Promise(done => {
    const proc = spawn(process.execPath, [join(dir, 'companion/host.mjs'), origin], { stdio: ['pipe', 'pipe', 'pipe'] });
    const timer = setTimeout(() => { proc.stdin.end(); }, 300);
    proc.on('exit', code => { clearTimeout(timer); done(code); });
  });
  assert.equal(await run('chrome-extension://dev/'), 0);
  assert.equal(await run('chrome-extension://store/'), 0);
  assert.equal(await run('chrome-extension://someone-else/'), 1);
});
