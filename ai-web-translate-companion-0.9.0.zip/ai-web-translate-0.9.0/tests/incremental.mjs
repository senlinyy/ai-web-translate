import { chromium } from 'playwright';
import assert from 'node:assert/strict';
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage();
  await page.setContent('<main>' + Array.from({length:193}, (_, i) => `<p id="p${i}">News headline ${i}</p>`).join('') + '</main>');
  await page.evaluate(() => {
    window.requests = []; window.cancels = 0; window.delay = 100;
    window.chrome = { runtime: {
      onMessage: { addListener(fn) { window.listener = fn; } },
      async sendMessage(message) {
        if (message.type === 'cancel') { cancels++; return {ok:true,result:{}}; }
        requests.push(message);
        const rows = message.blocks.map(b => ({id:b.id,text:'译 '+b.text}));
        listener({type:'translationProgress',streamId:message.streamId,translations:rows.slice(0,180)}, {}, () => {});
        await new Promise(resolve => setTimeout(resolve, delay));
        return {ok:true,result:{translations:rows}};
      }
    }};
    window.command = message => new Promise(resolve => listener(message,{},resolve));
  });
  await page.addScriptTag({path:'extension/content.js'});
  await page.evaluate(() => { delay=1000; return command({type:'start'}); });
  await page.waitForFunction(() => document.querySelector('#p0 [data-codex-translation]'));
  await page.evaluate(() => {
    window.firstHost = document.querySelector('#p0 [data-codex-translation]'); window.initialCancels = cancels;
    document.querySelector('main').insertAdjacentHTML('beforeend', Array.from({length:13}, (_,i) => `<p>New story ${i}</p>`).join(''));
    dispatchEvent(new Event('scroll'));
  });
  await page.waitForTimeout(350);
  assert(await page.evaluate(() => firstHost.isConnected && firstHost === document.querySelector('#p0 [data-codex-translation]')));
  assert.equal(await page.evaluate(() => cancels), await page.evaluate(() => initialCancels));
  await page.waitForFunction(() => document.querySelectorAll('span[data-codex-translation]').length === 206);
  assert.deepEqual(await page.evaluate(() => requests.map(r => r.blocks.length)), [193,13]);
  await page.waitForTimeout(1100);
  await page.evaluate(() => {
    window.savedHost = document.querySelector('#p1 [data-codex-translation]');
    document.querySelector('#p0').firstChild.textContent = 'Changed headline'; delay=50;
  });
  await page.waitForFunction(() => document.querySelector('#p0 [data-codex-translation]')?.shadowRoot.textContent.includes('Changed headline'));
  assert.equal(await page.evaluate(() => requests.at(-1).blocks.length),1);
  assert(await page.evaluate(() => savedHost === document.querySelector('#p1 [data-codex-translation]')));
  await page.waitForTimeout(100);
  const count = await page.evaluate(() => requests.length);
  await page.evaluate(() => { document.querySelector('#p1').outerHTML = '<p id="p1">News headline 1</p>'; dispatchEvent(new Event('scroll')); });
  await page.waitForFunction(() => document.querySelector('#p1 [data-codex-translation]'));
  assert.equal(await page.evaluate(() => requests.length), count, 'Identical replacement nodes reuse completed text');
  await page.evaluate(() => command({type:'restore'}));
  assert.equal(await page.locator('[data-codex-translation]').count(),0);
  console.log('Incremental news page passed: 193 -> 206 blocks without reset or cancellation, only 13 new blocks requested, one changed headline requested, stable host identity, replacement reuse, and restoration.');
} finally { await browser.close(); }
