import { chromium } from 'playwright';
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
const server = createServer(async (req, res) => {
  if (!/^\/[a-z-]+\.(html|js|css)$/.test(req.url)) { res.writeHead(404).end(); return; }
  try { res.setHeader('Content-Type', req.url.endsWith('.js') ? 'text/javascript' : req.url.endsWith('.css') ? 'text/css' : 'text/html'); res.end(await readFile('extension' + req.url)); }
  catch { res.writeHead(404).end(); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({ channel: 'chromium', headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 360, height: 600 } });
  await page.addInitScript(() => {
    const listeners = [];
    window.requests = []; window.opened = [];
    window.shortcut = 'Alt+Shift+T';
    window.chrome = {
      commands: { async getAll() { return [{ name: 'toggle-translation', shortcut: window.shortcut }]; } },
      tabs: { async query() { return [{ url: 'https://example.com' }]; }, async create(tab) { opened.push(tab.url); } },
      storage: { onChanged: { addListener(fn) { listeners.push(fn); } }, local: {
        async get() { return JSON.parse(localStorage.getItem('stored') || '{}'); },
        async set(values) { const old = await this.get(); localStorage.setItem('stored', JSON.stringify({ ...old, ...values })); for (const fn of listeners) fn(Object.fromEntries(Object.entries(values).map(([k,v]) => [k,{oldValue:old[k],newValue:v}])), 'local'); }
      }, session: { async get() { return {}; } } },
      runtime: { onMessage: { addListener() {} }, openOptionsPage() {}, async sendMessage(message) {
        requests.push(message.type);
        return { ok: true, result: message.type === 'status' ? { signedIn: false } : message.type === 'models' ? { data: [] } : {} };
      } }
    };
  });
  const base = `http://127.0.0.1:${server.address().port}`;
  await page.goto(base + '/popup.html');
  await page.waitForFunction(() => !document.querySelector('#language').disabled);
  assert.equal(await page.locator('#translate').textContent(), '翻译页面');
  assert.equal(await page.locator('#language').inputValue(), 'Simplified Chinese');
  assert.deepEqual(await page.evaluate(() => requests), []);
  assert.equal(await page.locator('#model').inputValue(), 'gpt-6-luna');
  await page.locator('#model').selectOption('gpt-6-sol');
  assert.equal(await page.locator('#effort option[value=ultra]').count(), 1);
  await page.locator('#model').selectOption('gpt-6-luna');
  assert.equal(await page.locator('#effort option[value=ultra]').count(), 0);
  await page.waitForFunction(async()=> (await chrome.storage.local.get()).settings?.model === 'gpt-6-luna');
  await page.screenshot({path:'artifacts/interface-popup-cn.png',fullPage:true});
  await page.locator('#uiLanguage').selectOption('en');
  await page.waitForFunction(() => document.querySelector('#translate').textContent === 'Translate page');
  assert.equal(await page.locator('#language').inputValue(), 'Simplified Chinese');
  await page.screenshot({path:'artifacts/interface-popup.png',fullPage:true});
  assert(await page.locator('.footer').evaluate(el => el.getBoundingClientRect().bottom <= 600), String(await page.locator('.footer').evaluate(el => el.getBoundingClientRect().bottom)));
  await page.reload();
  await page.waitForFunction(() => document.documentElement.lang === 'en');
  await page.locator('#shortcuts').click();
  assert.deepEqual(await page.evaluate(() => opened), ['chrome://extensions/shortcuts']);
  await page.evaluate(() => { window.shortcut = 'Ctrl+Shift+Y'; dispatchEvent(new Event('focus')); });
  await page.waitForFunction(() => document.querySelector('#shortcuts').textContent === 'Ctrl+Shift+Y');
  await page.goto(base + '/options.html');
  await page.waitForFunction(() => document.documentElement.lang === 'en' && document.querySelector('#instructions').value);
  assert.equal(await page.locator('#glossary').inputValue(), '');
  assert.match(await page.locator('#glossary').getAttribute('placeholder'), /large language model.*LLM/);
  await page.locator('#instructions').fill('Unsaved custom instructions');
  await page.locator('#glossary').fill('fine-tuning = 自定义微调');
  await page.locator('#uiLanguage').selectOption('zh-CN');
  await page.waitForFunction(() => document.querySelector('#shortcuts').textContent === '自定义快捷键');
  await page.setViewportSize({width:1100,height:1300});
  await page.screenshot({path:'artifacts/interface-settings-cn.png',fullPage:true});
  assert.equal(await page.locator('#instructions').inputValue(), 'Unsaved custom instructions');
  assert.equal(await page.locator('#glossary').inputValue(), 'fine-tuning = 自定义微调');
  assert.equal(await page.evaluate(() => JSON.parse(localStorage.stored).settings.glossary), '');
  await page.locator('button[type=submit]').click();
  await page.waitForFunction(() => document.querySelector('#status').textContent.startsWith('已保存'));
  await page.locator('#uiLanguage').selectOption('en');
  await page.waitForFunction(() => document.querySelector('#status').textContent.startsWith('Saved.'));
  assert.equal(await page.locator('#effort').inputValue(), 'low');
  await page.reload();
  await page.waitForFunction(() => document.querySelector('#glossary').value === 'fine-tuning = 自定义微调');
  console.log('Interface checks passed: Chinese default, English persistence, live status labels, stable translation values, unsaved edits, LLM placeholder, shortcut editor and refreshed assignment.');
} finally { await browser.close(); server.close(); }
