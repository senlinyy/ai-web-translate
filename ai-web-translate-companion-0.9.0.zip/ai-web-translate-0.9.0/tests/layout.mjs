import { chromium } from 'playwright';
import { mkdir } from 'node:fs/promises';
import assert from 'node:assert/strict';
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1100, height: 850 } });
  await page.setContent(`<!doctype html><html><head><style>
    *{box-sizing:border-box}body{margin:0;color:#27483c;background:#f5f7f2;font:18px/1.5 system-ui}aside{width:290px;min-height:850px;background:#fcfdfa;border-right:1px solid #dce3d7;padding:28px 20px}h1{font-size:14px;letter-spacing:2px;color:#8a9786;margin:30px 0 16px}.label{display:flex;align-items:center;gap:14px;border-radius:9px;padding:16px 8px;margin:12px 0;width:100%}.logo{font-size:28px;font-weight:700}.icon{flex-shrink:0;display:block;width:30px;color:#769075}button{font:inherit;color:inherit;text-align:left;border:1px solid #d3ddcd;background:#edf2e7}.inline{display:inline-flex;width:auto}.grid{display:grid;grid-template-columns:30px 1fr;align-items:center}.right{margin-left:auto}main{position:absolute;left:330px;top:50px;max-width:690px;padding:20px}main h2{font-size:28px}main p{line-height:1.8}
  </style></head><body><aside>
    <div id="brand" class="label logo"><i class="icon" aria-hidden="true">☁</i>CloudQuiz</div>
    <h1>PERSONAL WORKSPACE</h1>
    <button id="overview" class="label"><i class="icon" aria-hidden="true">▦</i>Overview</button>
    <div id="saved" class="label grid"><i class="icon" aria-hidden="true">◇</i>Saved questions</div>
    <div id="profile" class="label"><i class="icon" aria-hidden="true">◉</i>Sunny Lin<i class="icon right" aria-hidden="true">↪</i></div>
    <button id="two-labels" class="label">Previous<i class="icon" aria-hidden="true">→</i>Next</button>
  </aside><main><h2>Read in two languages</h2><p>The original stays above its translation. Icons, buttons, and navigation keep their existing layout.</p>
    <button id="next" class="label inline">Next<i class="icon" aria-hidden="true">→</i></button>
    <button id="nested" class="label"><i class="icon" aria-hidden="true">◫</i><span>Copy Markdown</span></button>
  </main></body></html>`);
  await page.evaluate(() => {
    window.originals = new Map([...document.querySelectorAll('.label')].map(el => [el.id, [...el.childNodes]]));
    window.clicks = 0; document.querySelector('#overview').onclick = () => window.clicks++;
    const dict = { CloudQuiz: 'CloudQuiz', Overview: '概览', 'Saved questions': '保存的问题', 'Sunny Lin': 'Sunny Lin', Next: '下一页', Previous: '上一页', 'Copy Markdown': '复制 Markdown' };
    window.chrome = { runtime: {
      onMessage: { addListener(fn) { window.listener = fn; } },
      async sendMessage(message) { return { ok: true, result: message.type === 'cancel' ? {} : { translations: message.blocks.map(b => ({ id: b.id, text: dict[b.text] || '中文翻译' })) } }; }
    } };
    window.command = message => new Promise(resolve => listener(message, {}, resolve));
  });
  await page.addScriptTag({ path: process.env.TRANSLATION_SCRIPT || 'extension/content.js' });
  await page.evaluate(() => command({ type: 'start' }));
  await page.waitForFunction(() => document.querySelector('#next [data-codex-translation]'));
  const checks = await page.evaluate(() => {
    const results = [];
    for (const id of ['brand','saved','profile','next','nested']) {
      const el = document.getElementById(id);
      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
      let node; while ((node = walker.nextNode())) if (node.textContent.trim() && !node.parentElement.closest('[aria-hidden]')) break;
      const range = document.createRange(); range.selectNodeContents(node);
      const source = range.getBoundingClientRect(); const translated = el.querySelector('[data-codex-translation]').getBoundingClientRect();
      results.push({ id, sourceBottom: source.bottom, translationTop: translated.top, left: translated.left, right: translated.right, containerLeft: el.getBoundingClientRect().left, containerRight: el.getBoundingClientRect().right });
    }
    return results;
  });
  for (const row of checks) {
    assert(row.translationTop >= row.sourceBottom - 1, `${row.id}: translation must be BELOW the source, not in another column (${JSON.stringify(row)})`);
    assert(row.left >= row.containerLeft && row.right <= row.containerRight + 1, `${row.id}: translation must fit inside the container`);
  }
  assert.equal(await page.locator('#two-labels [data-codex-translation]').count(), 2);
  assert.equal(await page.locator('#overview').getAttribute('title'), '概览');
  await page.locator('#overview').click(); assert.equal(await page.evaluate(() => clicks), 1);
  const count = await page.locator('[data-codex-translation]').count();
  await page.evaluate(() => dispatchEvent(new Event('scroll'))); await page.waitForTimeout(600);
  assert.equal(await page.locator('[data-codex-translation]').count(), count, 'Wrapping text must not cause duplicate translations');
  await mkdir('artifacts', { recursive: true }); await page.screenshot({ path: 'artifacts/layout-stacked.png' });
  await page.evaluate(() => command({ type: 'restore' }));
  assert(await page.evaluate(() => [...originals].every(([id, nodes]) => { const actual = [...document.getElementById(id).childNodes]; return actual.length === nodes.length && actual.every((node, i) => node === nodes[i]); })), 'Restoring must preserve original node identities and order');
  assert.equal(await page.locator('[data-codex-source]').count(), 0);
  console.log('Layout regression passed: flex, inline-flex, grid, icons on both sides, separate labels, no duplicates, and exact DOM restoration.');
} finally { await browser.close(); }
