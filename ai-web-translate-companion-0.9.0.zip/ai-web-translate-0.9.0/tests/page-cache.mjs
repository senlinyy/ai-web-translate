import { chromium } from 'playwright';
import { readFile, mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createServer } from 'node:http';
import assert from 'node:assert/strict';
const server = createServer(async (req, res) => {
  if (['/page-cache.js', '/page-translations.js', '/batch-plan.js'].includes(req.url)) { res.setHeader('Content-Type', 'text/javascript'); res.end(await readFile('extension' + req.url)); }
  else { res.setHeader('Content-Type', 'text/html'); res.end('<!doctype html><title>Persistent page cache test</title>'); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const profile = await mkdtemp(join(tmpdir(), 'page-cache-test-')); let context;
async function launch() {
  context = await chromium.launchPersistentContext(profile, { headless: true });
  const page = await context.newPage(); await page.goto(`http://127.0.0.1:${server.address().port}/`);
  await page.evaluate(async () => {
    const { PageCache } = await import('/page-cache.js'); const { PageTranslations } = await import('/page-translations.js');
    window.PageCache = PageCache; window.PageTranslations = PageTranslations;
    window.calls = 0; window.delay = 0; window.sentInputs = [];
    window.transport = async input => { window.calls++; window.sentInputs.push(input); await new Promise(resolve => setTimeout(resolve, window.delay)); return { translations: input.blocks.map(block => ({ id: block.id, text: '译文 ' + block.text })) }; };
    window.input = { language: 'Simplified Chinese', model: 'gpt-5.6-luna', effort: 'low', instructions: 'Translate only.', glossary: '', blocks: Array.from({ length: 4 }, (_, i) => ({ id: 'b' + i, text: 'Block ' + i })) };
    window.service = new PageTranslations(new PageCache(), window.transport, new PageCache({name:'codex-block-translations',maxEntries:5000}));
    window.translate = (overrides = {}) => service.translate({ owner: 1, url: 'https://example.com/quiz?id=70', input, ...overrides });
  });
  return page;
}
try {
  let page = await launch();
  let result = await page.evaluate(async () => {
    const first = await translate(); const second = await translate({ input: { ...input, blocks: input.blocks.map((block, i) => ({ ...block, id: 'new' + i })) } });
    return { calls, first, second };
  });
  assert.equal(result.calls, 1); assert.equal(result.first.cached, false); assert.equal(result.second.cached, true); assert.equal(result.second.translations[0].id, 'new0');
  await context.close(); page = await launch();
  result = await page.evaluate(async () => ({ result: await translate(), calls }));
  assert.equal(result.result.cached, true); assert.equal(result.calls, 0, 'Cached page must survive a full browser restart and make zero model calls');
  result = await page.evaluate(async () => {
    for (const [key, value] of Object.entries({ language: 'French', model: 'gpt-5.5', effort: 'high', instructions: 'Use formal language.', glossary: 'Block = 块' })) await translate({ input: { ...input, [key]: value } });
    await translate({ input: { ...input, blocks: [{ id: 'changed', text: 'Changed page content' }] } });
    await translate({ url: 'https://example.com/quiz?id=71' });
    return calls;
  });
  assert.equal(result, 7, 'Each relevant source/settings/page change must invalidate cache');
  result = await page.evaluate(async () => {
    const first = await translate({ force: true }); const second = await translate(); return { calls, first, second };
  });
  assert.equal(result.calls, 8); assert.equal(result.first.cached, false); assert.equal(result.second.cached, true);
  result = await page.evaluate(async () => {
    delay = 80; const before = calls;
    const [a, b] = await Promise.all([translate({ url: 'https://example.com/new' }), translate({ url: 'https://example.com/new' })]);
    return { calls: calls - before, a, b };
  });
  assert.equal(result.calls, 1); assert.deepEqual(result.a.translations, result.b.translations);
  result = await page.evaluate(async () => {
    const before = calls;
    const pending = translate({ url: 'https://example.com/clear-during-request' });
    await new Promise(resolve => setTimeout(resolve, 20)); await service.clear(); await pending;
    await translate({ url: 'https://example.com/clear-during-request' });
    return calls - before;
  });
  assert.equal(result, 2, 'Clearing the cache must not be undone by an in-flight request');
  result = await page.evaluate(async () => {
    const before = calls; const pending = translate({ url: 'https://example.com/cancelled' }).catch(error => error.name);
    await new Promise(resolve => setTimeout(resolve, 20)); service.cancel(1); const error = await pending;
    await translate({ url: 'https://example.com/cancelled' }); return { error, calls: calls - before };
  });
  assert.equal(result.error, 'AbortError'); assert.equal(result.calls, 2, 'Cancelled translations must not populate cache');
  result = await page.evaluate(async () => {
    let now = 0; const cache = new PageCache({ name: 'eviction-test', maxEntries: 2, maxBytes: 200, ttl: 1000, now: () => now });
    await cache.put('a', ['A']); now++; await cache.put('b', ['B']); now++; await cache.get('a'); now++; await cache.put('c', ['C']);
    const evicted = await cache.get('b'), retained = await cache.get('a');
    now = 2000; const expired = await cache.get('a');
    const large = await cache.put('huge', ['x'.repeat(300)]);
    await cache.clear(); return { evicted, retained, expired, large, cleared: await cache.get('c') };
  });
  assert.deepEqual(result, { evicted: null, retained: ['A'], expired: null, large: false, cleared: null });
  result = await page.evaluate(async () => {
    delay = 0; await translate({url:'https://example.com/news'});
    const before = calls;
    await translate({url:'https://example.com/news', input:{...input, blocks:[...input.blocks,{id:'new',text:'New story'}]}});
    const sent = sentInputs.at(-1).blocks;
    const reordered = await translate({url:'https://example.com/news', input:{...input, blocks:[...input.blocks].reverse()}});
    return {calls:calls-before,sent,cached:reordered.cached};
  });
  assert.equal(result.calls,1); assert.deepEqual(result.sent,[{id:'new',text:'New story'}]); assert.equal(result.cached,true);
  await context.close(); page = await launch();
  result = await page.evaluate(async () => {
    const result = await translate({url:'https://example.com/news',input:{...input,blocks:[input.blocks[1],input.blocks[0]]}});
    return {cached:result.cached,calls};
  });
  assert.deepEqual(result,{cached:true,calls:0},'Individual block cache must survive restart and different page compositions');
  console.log('Persistent page cache passed: browser restart with zero model calls, ID remapping, settings/content invalidation, refresh, duplicate requests, cancellation, clear-during-request, expiry, and LRU bounds.');
} finally { await context?.close(); await rm(profile, { recursive: true, force: true }); server.close(); }
