import { chromium } from 'playwright';
import assert from 'node:assert/strict';
const browser = await chromium.launch({channel:'chromium',headless:true});
try {
 const page = await browser.newPage();
 await page.setContent('<main><p id="first">Original first paragraph</p><div id="new"></div></main>');
 await page.evaluate(()=>{
  window.requests=[];
  window.chrome={runtime:{onMessage:{addListener(fn){window.listener=fn}},async sendMessage(m){
   if(m.type==='cancel')return {ok:true,result:{}};
   return new Promise(resolve=>requests.push({m,finish:()=>resolve({ok:true,result:{translations:m.blocks.map(b=>({id:b.id,text:'译 '+b.text}))}})}));
  }}};
  window.command=m=>new Promise(resolve=>listener(m,{},resolve));
 });
 await page.addScriptTag({path:process.env.TRANSLATION_SCRIPT || 'extension/content.js'});
 await page.evaluate(()=>command({type:'start'}));
 await page.waitForFunction(()=>requests.length===1);
 await page.evaluate(()=>requests[0].finish());
 await page.waitForFunction(()=>document.querySelector('#first [data-codex-translation]'));
 await page.evaluate(()=>{
  window.firstHost=document.querySelector('#first [data-codex-translation]');
  document.querySelector('#new').innerHTML='<p id="pending">New earlier paragraph</p><p id="cached">Original first paragraph</p>';
 });
 await page.waitForFunction(()=>requests.length===2);
 assert.equal(await page.locator('#cached [data-codex-translation]').count(),0,'Reused text below an unfinished paragraph must wait');
 assert.deepEqual(await page.evaluate(()=>requests[1].m.blocks.map(b=>b.text)),['New earlier paragraph'],'Reuse must still avoid a second model call');
 assert(await page.evaluate(()=>firstHost===document.querySelector('#first [data-codex-translation]')));
 // Insert a new earlier record while the second request is already running.
 await page.evaluate(()=>document.querySelector('#pending').insertAdjacentHTML('beforebegin','<p id="inserted">Inserted while translating</p>'));
 await page.waitForFunction(()=>[...document.querySelectorAll('[data-codex-translation]')].some(el=>el.shadowRoot?.querySelector('[role=status]')?.textContent.includes('/ 4 blocks')));
 await page.evaluate(()=>requests[1].finish());
 await page.waitForFunction(()=>requests.length===3);
 assert.equal(await page.locator('#pending [data-codex-translation]').count(),0,'A completed wave cannot bypass new earlier source');
 assert.equal(await page.locator('#cached [data-codex-translation]').count(),0);
 await page.evaluate(()=>requests[2].finish());
 await page.waitForFunction(()=>document.querySelector('#cached [data-codex-translation]'));
 assert.equal(await page.locator('#inserted [data-codex-translation]').count(),1);
 assert.equal(await page.locator('#pending [data-codex-translation]').count(),1);
 assert(await page.evaluate(()=>firstHost===document.querySelector('#first [data-codex-translation]')));
 console.log('Page-wide order passed: reused content and completed waves wait for newly inserted earlier text; existing translations remain attached.');
} finally {await browser.close();}
