import { chromium } from 'playwright';
import { readFile, writeFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import assert from 'node:assert/strict';
const server = createServer(async (req,res) => {
  const file = req.url.split('?')[0];
  if (!/^\/[a-z-]+\.(html|js|css)$/.test(file)) { res.writeHead(404); res.end(); return; }
  try { res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':'text/html'); res.end(await readFile('extension'+file)); } catch { res.writeHead(404); res.end(); }
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({headless:true});
try {
 const page=await browser.newPage({viewport:{width:360,height:600}});
 await page.addInitScript(()=>{
  window.calls=[];
  const slow=()=>new Promise(resolve=>setTimeout(resolve,2000));
  window.chrome={tabs:{async query(){await slow();return [{url:'https://example.com'}]}},storage:{local:{async get(){await slow();return {settings:{language:'French',effort:'high'}}},async set(){}}},runtime:{onMessage:{addListener(){}},async sendMessage(message){calls.push(message.type);if(message.type==='status')await new Promise(()=>{});return {ok:true,result:{}}},openOptionsPage(){window.optionsOpened=true}}};
 });
 await page.goto(`http://127.0.0.1:${server.address().port}/popup.html`);
 await page.waitForFunction(()=>performance.getEntriesByType('paint').some(e=>e.name==='first-contentful-paint'));
 const firstPaint=await page.evaluate(()=>performance.getEntriesByType('paint').find(e=>e.name==='first-contentful-paint').startTime);
 assert(firstPaint<1000,`Popup paint waited for slow services: ${firstPaint} ms`);
 assert.equal(await page.locator('#model').inputValue(),'gpt-6-luna');
 assert(await page.locator('#translate').isVisible());
 await page.locator('#settings').click();
 assert(await page.evaluate(()=>optionsOpened),'Settings link works while connection and preference checks are pending');
 await page.waitForFunction(()=>!document.querySelector('#language').disabled);
 assert.equal(await page.locator('#language').inputValue(),'French');
 assert.equal(await page.locator('#effort').inputValue(),'high');
 assert(await page.locator('.footer').evaluate(el=>el.getBoundingClientRect().bottom<=600));
 assert.deepEqual(await page.evaluate(()=>calls), [], 'Opening the popup must not contact or wake the companion');
 await page.locator('#reconnect').click();
 assert.deepEqual(await page.evaluate(()=>calls), ['status'], 'Only an explicit connection check may start the companion');
 const report={automaticCompanionRequests:0,explicitConnectionCheck:true,firstContentfulPaintMs:firstPaint,simulatedSettingsDelayMs:2000,companion:'never responds',settingsLinkResponsive:true};
 await writeFile('artifacts/popup-startup.json',JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify(report));
}finally{await browser.close();server.close()}
