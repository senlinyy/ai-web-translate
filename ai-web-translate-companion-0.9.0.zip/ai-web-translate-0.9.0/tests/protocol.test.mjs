import test from 'node:test';
import assert from 'node:assert/strict';
import { FrameDecoder, encodeFrame, validateTranslation, validateOutput, MAX_FRAME } from '../companion/protocol.mjs';
test('native framing handles split UTF-8, partial headers and coalesced messages', () => {
  const expected = [{ id: '1', text: '翻译中文🙂' }, { id: '2', value: true }]; const actual = [];
  const bytes = Buffer.concat(expected.map(encodeFrame)); const decoder = new FrameDecoder(m => actual.push(m));
  for (const byte of bytes) decoder.push(Buffer.from([byte]));
  assert.deepEqual(actual, expected);
  const coalesced = []; new FrameDecoder(m => coalesced.push(m)).push(bytes); assert.deepEqual(coalesced, expected);
});
test('rejects excessive native frame size before buffering its body', () => {
  const header = Buffer.alloc(4); header.writeUInt32LE(MAX_FRAME + 1);
  assert.throws(() => new FrameDecoder(() => {}).push(header), /size/);
});
test('validates text limits and duplicate IDs', () => {
  const blocks = [{ id: 'a', text: 'Hello' }]; assert.equal(validateTranslation({ blocks }).language, 'Simplified Chinese');
  assert.throws(() => validateTranslation({ blocks: [...blocks, ...blocks] }), /duplicate/);
  assert.throws(() => validateTranslation({ blocks: [{ id: 'a', text: 'x'.repeat(6001) }] }), /text block/);
  assert.throws(() => validateTranslation({ blocks, instructions: 'x'.repeat(8001) }), /instructions/);
  assert.throws(() => validateTranslation({ blocks, language: ' ' }), /language/);
});
test('requires exactly one nonempty translation for each input ID', () => {
  const blocks = [{ id: 'a' }, { id: 'b' }];
  assert.equal(validateOutput(JSON.stringify({ translations: [{ id: 'b', text: '二' }, { id: 'a', text: '一' }] }), blocks).length, 2);
  for (const translations of [[{ id: 'a', text: '一' }], [{ id: 'a', text: '一' }, { id: 'a', text: '一' }], [{ id: 'a', text: '' }, { id: 'b', text: '二' }]]) assert.throws(() => validateOutput(JSON.stringify({ translations }), blocks));
});

test('translation defaults to Luna and low thinking, rejecting invalid efforts', () => {
  const blocks = [{ id: 'a', text: 'Hello' }];
  const input = validateTranslation({ blocks });
  assert.equal(input.model, 'gpt-6-luna'); assert.equal(input.effort, 'low');
  assert.equal(validateTranslation({ blocks, model: '' }).model, 'gpt-6-luna');
  assert.throws(() => validateTranslation({ blocks, effort: 'invented' }), /thinking level/);
});

test('whole-page limits allow one large request and reject oversize explicitly', () => {
  assert.equal(validateTranslation({ blocks: Array.from({ length: 600 }, (_, i) => ({ id: 'b' + i, text: 'Label ' + i })) }).blocks.length, 600);
  assert.throws(() => validateTranslation({ blocks: Array.from({ length: 601 }, (_, i) => ({ id: 'b' + i, text: 'Label' })) }), /600/);
  const blocks = Array.from({ length: 10 }, (_, i) => ({ id: 'b' + i, text: 'a'.repeat(6000) }));
  assert.equal(validateTranslation({ blocks }).blocks.length, 10);
  assert.throws(() => validateTranslation({ blocks: [...blocks, { id: 'extra', text: 'a' }] }), /too large/);
});
