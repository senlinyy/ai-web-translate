import { chromium } from 'playwright';
import assert from 'node:assert/strict';
const browser = await chromium.launch({headless:true});
try {
 const page = await browser.newPage({viewport:{width:1200,height:800}});
 await page.setContent(`<style>body{margin:0}#drawer{position:absolute;left:-1000px;width:300px}#transparent{opacity:0}#footer{position:absolute;top:2000px}.story{position:absolute;width:400px}#left{left:40px;top:80px}#right{left:600px;top:80px}#later{left:40px;top:400px}</style>
 <div id="drawer">${Array.from({length:66},(_,i)=>`<p>Invisible menu ${i}</p>`).join('')}</div>
 <div id="transparent"><p>Transparent menu</p></div><p id="footer">Footer first in HTML</p>
 <h2 class="story" id="later">Lower story first in HTML</h2><h2 class="story" id="right">Right top story</h2><h2 class="story" id="left">Left top story</h2>`);
 await page.evaluate(() => {
  window.requests=[];
  window.chrome={runtime:{onMessage:{addListener(fn){window.listener=fn}},async sendMessage(message){
   if(message.type==='cancel')return {ok:true,result:{}};
   requests.push(message); return await new Promise(resolve=>{window.finish=()=>resolve({ok:true,result:{translations:message.blocks.map(b=>({id:b.id,text:'译 '+b.text}))}})});
  }}};
  window.command=m=>new Promise(resolve=>listener(m,{},resolve));
 });
 await page.evaluate(()=>scrollTo(0, 300));
 await page.addScriptTag({path:process.env.TRANSLATION_SCRIPT || 'extension/content.js'});
 await page.evaluate(()=>command({type:'start',uiLanguage:'zh-CN'}));
 assert.deepEqual(await page.evaluate(()=>requests[0].blocks.map(b=>b.text)),['Left top story','Right top story','Lower story first in HTML','Footer first in HTML']);
 await page.evaluate(()=>{const r=requests[0];listener({type:'translationProgress',streamId:r.streamId,translations:[{id:r.blocks[1].id,text:'右侧新闻'}]}, {},()=>{});});
 assert.equal(await page.locator('#right [data-codex-translation]').count(),0,'A faster sidebar result must wait for the earlier headline');
 assert.equal(await page.locator('#left [data-codex-translation]').count(),0);
 await page.evaluate(()=>{const r=requests[0];listener({type:'translationProgress',streamId:r.streamId,translations:[{id:r.blocks[3].id,text:'页尾'}]}, {},()=>{});});
 assert.equal(await page.locator('#footer [data-codex-translation]').count(),0,'Later cached or streamed rows cannot jump the frontier');
 await page.evaluate(()=>{const r=requests[0];listener({type:'translationProgress',streamId:r.streamId,translations:[{id:r.blocks[0].id,text:'左侧新闻'}]}, {},()=>{});});
 assert.equal(await page.locator('#left [data-codex-translation]').count(),1);
 assert.equal(await page.locator('#right [data-codex-translation]').count(),1,'Buffered sidebar releases with the earlier headline, before the full request completes');
 assert.equal(await page.locator('#footer [data-codex-translation]').count(),0);
 assert(await page.getByRole('button',{name:'原文',exact:true}).isVisible());
 assert.match(await page.getByRole('status').textContent(), /正在翻译/);
 await page.screenshot({path:'artifacts/reading-order-progress.png'});
 await page.evaluate(()=>finish());
 await page.waitForFunction(()=>document.querySelector('#left [data-codex-translation]'));
 assert.equal(await page.locator('#drawer [data-codex-translation]').count(),0);
 console.log('Visual reading order passed: 66 off-canvas labels excluded, opacity-hidden text excluded, top-to-bottom/left-to-right order even when starting scrolled down, offscreen footer last, ordered progressive rendering with a slow first block and buffered later results.');
}finally{await browser.close()}
