import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { CodexRuntime, RUNTIME_CONFIG } from '../companion/runtime.mjs';
const input = { language: 'Simplified Chinese', instructions: 'Use technical terminology.', glossary: '', model: 'gpt-6-luna', effort: 'low', blocks: [{ id: 'a', text: 'Hello' }] };
async function setup(t) {
  const profile = await mkdtemp(join(tmpdir(), 'translator-test-'));
  const runtime = new CodexRuntime({ binary: resolve('tests/fake-codex.mjs'), profile });
  t.after(async () => { runtime.close(); await rm(profile, { recursive: true, force: true }); }); return runtime;
}
test('structured translation handles completion arriving before turn response', async t => {
  const runtime = await setup(t); const events = []; runtime.on('notification', e => events.push(e));
  const streamed = []; const result = await runtime.translate(input, undefined, row => streamed.push(row));
  assert.deepEqual(streamed, result.translations);
  assert.deepEqual(result.translations, [{ id: 'a', text: '译文 Hello' }]);
  const thread = events.find(e => e.method === 'test/thread').params;
  assert.equal(thread.model, 'gpt-6-luna'); assert.equal(thread.ephemeral, true); assert.equal(RUNTIME_CONFIG.default_permissions, 'translation'); assert.match(thread.baseInstructions, /untrusted/);
  const turn = events.find(e => e.method === 'test/turn').params;
  assert.equal(turn.effort, 'low'); assert.equal(RUNTIME_CONFIG['permissions.translation.filesystem.:workspace_roots'], 'read'); assert.equal(RUNTIME_CONFIG['permissions.translation.network.enabled'], false);
  assert.equal(Object.hasOwn(turn, 'sandboxPolicy'), false); assert.equal(Object.hasOwn(thread, 'sandbox'), false);
  assert.equal(RUNTIME_CONFIG['features.shell_tool'], false); assert.equal(RUNTIME_CONFIG['features.plugins'], false);
  assert.equal(runtime.listenerCount('failure'), 0);
});
test('cancelling an active translation rejects and removes listeners', async t => {
  const runtime = await setup(t); const controller = new AbortController();
  runtime.on('notification', e => { if (e.method === 'test/turn') setTimeout(() => controller.abort(), 20); });
  await assert.rejects(runtime.translate({ ...input, blocks: [{ id: 'a', text: 'timeout' }] }, controller.signal), /cancelled/);
  assert.equal(runtime.listenerCount('failure'), 0);
});
test('refuses all server-initiated execution approvals', async t => {
  const runtime = await setup(t); const responses = []; runtime.send = m => responses.push(m);
  runtime.receive({ id: 91, method: 'item/commandExecution/requestApproval' });
  runtime.receive({ id: 92, method: 'item/tool/call' });
  assert.equal(responses[0].result.decision, 'decline'); assert.equal(responses[1].error.code, -32601);
});

test('thinking levels are forwarded and model-default leaves effort unset', async t => {
  const runtime = await setup(t); const turns = []; runtime.on('notification', e => { if (e.method === 'test/turn') turns.push(e.params); });
  await runtime.translate({ ...input, effort: 'high' });
  await runtime.translate({ ...input, effort: '' });
  assert.equal(turns[0].effort, 'high'); assert.equal(Object.hasOwn(turns[1], 'effort'), false);
});

test('a batch uses one Codex turn with every supplied block', async t => {
  const runtime = await setup(t); const turns = []; runtime.on('notification', e => { if (e.method === 'test/turn') turns.push(e.params); });
  const blocks = Array.from({ length: 40 }, (_, i) => ({ id: 'block' + i, text: 'Page paragraph ' + i }));
  const result = await runtime.translate({ ...input, blocks });
  assert.equal(turns.length, 1); assert.equal(result.translations.length, 40);
  assert.equal(JSON.parse(turns[0].input[0].text).sourceBlocks.length, 40);
});
