// App-shell pages scroll an inner panel, not the window. Text below the panel's
// viewport is still page content, and scrolling must not drop translations.
import { chromium } from 'playwright';
import assert from 'node:assert/strict';
const paragraphs = Array.from({ length: 40 }, (_, i) => `<p id="p${i}">Paragraph ${i} about model serving, request routing, and batching on shared accelerators.</p>`).join('');
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1200, height: 700 } });
  await page.setContent(`<style>body{margin:0;height:100vh;overflow:hidden}.shell{display:flex;flex-direction:column;height:100vh;overflow:hidden}.frame{flex:1;display:flex;flex-direction:column;overflow:hidden;min-width:0}
  header{height:60px}.panel{flex:1;overflow-y:auto;overflow-x:hidden;padding:24px}p{margin:0 0 40px;font:16px/1.6 system-ui}
  #collapsed{overflow:hidden;height:0}#clip{overflow:hidden;width:200px}#clip p{margin-left:400px;width:200px}</style>
  <div class="shell"><header><div id="collapsed"><p>Collapsed menu entry</p></div><div id="clip"><p>Clipped sideways entry</p></div></header>
  <div class="frame"><main class="panel" id="panel"><h1 id="title">Parts of a model serving system</h1>${paragraphs}</main></div></div>`);
  await page.evaluate(() => {
    window.requests = []; window.cancels = 0;
    window.chrome = { runtime: { onMessage: { addListener(fn) { window.listener = fn; } }, async sendMessage(message) {
      if (message.type === 'cancel') { cancels++; return { ok: true, result: {} }; }
      const entry = { message }; requests.push(entry);
      return await new Promise(resolve => { entry.finish = () => resolve({ ok: true, result: { translations: message.blocks.map(b => ({ id: b.id, text: '译 ' + b.text })) } }); });
    } } };
    window.command = m => new Promise(resolve => listener(m, {}, resolve));
    window.stream = (from, to) => { const { message } = requests[0];
      listener({ type: 'translationProgress', streamId: message.streamId, translations: message.blocks.slice(from, to).map(b => ({ id: b.id, text: '译 ' + b.text })) }, {}, () => {}); };
  });
  await page.addScriptTag({ path: 'extension/content.js' });
  await page.evaluate(() => command({ type: 'start', uiLanguage: 'en' }));
  const startCancels = await page.evaluate(() => cancels);
  const sent = await page.evaluate(() => requests[0].message.blocks.map(b => b.text));
  assert.equal(sent.length, 41, 'The whole scroll panel is one wave, not just the visible part');
  assert.equal(sent[0], 'Parts of a model serving system');
  assert(!sent.some(text => /Collapsed|Clipped/.test(text)), 'Text clipped by overflow:hidden stays excluded');
  await page.evaluate(() => stream(0, 6));
  assert.equal(await page.locator('#panel [data-codex-translation]').count(), 6);
  // Scroll far down and change the page, which triggers a rescan mid-request.
  await page.evaluate(() => { panel.scrollTop = panel.scrollHeight; document.body.append(document.createElement('div')); });
  await page.waitForTimeout(1500);
  assert.equal(await page.locator('#panel [data-codex-translation]').count(), 6, 'Scrolling must not remove finished translations');
  await page.evaluate(() => stream(6, 41));
  assert.equal(await page.locator('#panel [data-codex-translation]').count(), 41, 'Rows streamed after scrolling still render');
  await page.evaluate(() => requests[0].finish());
  await page.getByRole('status').filter({ hasText: 'page translated' }).waitFor();
  await page.evaluate(() => { panel.scrollTop = 0; panel.dispatchEvent(new Event('scroll')); });
  await page.waitForTimeout(1500);
  assert.equal(await page.locator('#panel [data-codex-translation]').count(), 41, 'Scrolling back keeps every translation');
  assert.equal(await page.evaluate(() => requests.length), 1, 'Nothing is translated twice');
  assert.equal(await page.evaluate(() => cancels), startCancels, 'Scrolling never cancels the request');
  console.log('Scroll container passed: the whole inner scroll panel is one wave, overflow-clipped text stays excluded, scrolling mid-request keeps finished and streamed translations, and nothing is re-requested.');
} finally { await browser.close(); }
