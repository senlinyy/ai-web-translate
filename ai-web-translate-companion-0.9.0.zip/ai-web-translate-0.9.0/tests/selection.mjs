// Selection bubble: select text, click the bubble, read the translation in a card. The page is not changed.
import { chromium } from 'playwright';
import assert from 'node:assert/strict';
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1000, height: 700 } });
  await page.setContent(`<style>body{font:16px/1.6 system-ui;margin:40px}</style>
  <p id="one">Even with the EFS driver installed, EKS does not create the parent file system for you.</p>
  <p id="two">An admin creates one parent EFS file system ahead of time.</p>
  <p id="long">${'Long text. '.repeat(600)}</p><textarea id="field">Editable words here</textarea>`);
  await page.evaluate(() => {
    window.requests = [];
    window.chrome = {
      storage: { local: {
        store: { settings: { language: 'Japanese' }, uiLanguage: 'en', selectionInstructions: 'Keep EFS and EKS in English.' },
        async get(key) { return { [key]: this.store[key] }; }, async set(values) { Object.assign(this.store, values); }
      }, onChanged: { addListener() {} } },
      runtime: { onMessage: { addListener(fn) { window.listener = fn; } }, async sendMessage(message) {
        const entry = { message }; requests.push(entry);
        return await new Promise(resolve => { entry.finish = () => resolve({ ok: true, result: { translations: message.blocks.map(b => ({ id: b.id, text: `[${message.language}] ${b.text}` })) } }); });
      } }
    };
    window.select = (startId, endId) => {
      document.activeElement?.blur();
      const range = document.createRange(); range.setStart(document.getElementById(startId).firstChild, 0);
      const end = document.getElementById(endId).firstChild; range.setEnd(end, end.length);
      getSelection().removeAllRanges(); getSelection().addRange(range);
      document.getElementById(endId).dispatchEvent(new MouseEvent('mouseup', { bubbles: true, button: 0 }));
    };
  });
  const paragraphsHtml = () => page.evaluate(() => [...document.querySelectorAll('p')].map(p => p.outerHTML).join('\n'));
  const original = await paragraphsHtml();
  await page.addScriptTag({ path: 'extension/selection.js' });
  await page.evaluate(() => select('one', 'two'));
  const bubble = page.locator('button.bubble');
  await bubble.waitFor();
  assert.equal(await page.evaluate(() => requests.length), 0, 'Selecting text alone makes no request');
  await bubble.click();
  await page.waitForFunction(() => requests.length === 1);
  const sent = await page.evaluate(() => requests[0].message);
  assert.equal(sent.type, 'translateSelection'); assert.equal(sent.language, 'Japanese', 'The saved target language is the default');
  assert.deepEqual(sent.blocks.map(b => b.id), ['s0', 's1'], 'Each selected paragraph is its own streamed block');
  assert.equal(sent.instructions, 'Keep EFS and EKS in English.', 'Saved selection instructions are sent by default');
  assert.equal(await page.evaluate(() => getSelection().toString().includes('admin')), true, 'Clicking the bubble keeps the selection');
  await page.evaluate(() => listener({ type: 'translationProgress', streamId: requests[0].message.streamId, translations: [{ id: 's0', text: '最初の段落' }] }));
  const card = page.locator('section.card');
  await card.getByText('最初の段落').waitFor();
  assert.equal(await card.locator('.pending').count(), 1, 'The unfinished paragraph shows a placeholder');
  await page.evaluate(() => requests[0].finish());
  await card.getByText('[Japanese] An admin creates').waitFor();
  assert(await card.getByRole('button', { name: 'Copy' }).isVisible());
  await card.locator('select').selectOption('French');
  await page.waitForFunction(() => requests.length === 2);
  assert.equal(await page.evaluate(() => requests[1].message.language), 'French');
  await page.evaluate(() => requests[1].finish());
  await card.getByText('[French] Even with the EFS driver').waitFor();
  // One-off instructions, then saving them as the default.
  await card.getByRole('button', { name: 'Instructions for this translation' }).click();
  const field = card.getByRole('textbox', { name: 'Selection translation instructions' });
  assert.equal(await field.inputValue(), 'Keep EFS and EKS in English.');
  await field.fill('Use a casual tone.');
  await page.keyboard.press('ControlOrMeta+Enter');
  await page.waitForFunction(() => requests.length === 3);
  assert.equal(await page.evaluate(() => requests[2].message.instructions), 'Use a casual tone.');
  assert.equal(await page.evaluate(() => requests[2].message.language), 'French', 'Changing instructions keeps the chosen language');
  assert.equal(await page.evaluate(() => chrome.storage.local.store.selectionInstructions), 'Keep EFS and EKS in English.', 'Apply alone does not change the saved default');
  await page.evaluate(() => requests[2].finish());
  await card.getByRole('button', { name: 'Save as default' }).click();
  await page.waitForFunction(() => requests.length === 4);
  assert.equal(await page.evaluate(() => chrome.storage.local.store.selectionInstructions), 'Use a casual tone.');
  await page.evaluate(() => requests[3].finish());
  await card.getByText('[French] Even with the EFS driver').waitFor();
  await page.screenshot({ path: 'artifacts/selection-card.png' });
  await page.keyboard.press('Escape');
  assert.equal(await card.count(), 0, 'Escape closes the card');
  assert.equal(await paragraphsHtml(), original, 'The page text is untouched');
  // Editable fields and over-long selections.
  await page.evaluate(() => { getSelection().removeAllRanges(); const f = document.getElementById('field'); f.focus(); f.select(); f.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, button: 0 })); });
  await page.waitForTimeout(100);
  assert(await bubble.isHidden(), 'No bubble for text inside an input');
  await page.evaluate(() => select('long', 'long'));
  await bubble.click();
  await card.getByText(/Select less text/).waitFor();
  assert.equal(await page.evaluate(() => requests.length), 4, 'Over-long selections are not sent');
  await page.mouse.click(5, 5);
  assert.equal(await card.count(), 0, 'Clicking elsewhere closes the card');
  await page.evaluate(() => select('one', 'one')); await bubble.waitFor();
  await page.mouse.click(5, 5); await page.waitForTimeout(250);
  assert(await bubble.isHidden(), 'Clicking elsewhere hides the bubble');
  console.log('Selection bubble passed: the bubble appears only after selecting page text, paragraphs stream into a floating card in the saved language, switching language retranslates, saved and one-off selection instructions are sent, Save as default persists them, Copy appears when done, Escape and outside clicks close it, inputs and over-long selections are skipped, and the page is not modified.');
} finally { await browser.close(); }
