import test from 'node:test';
import assert from 'node:assert/strict';
import { readSettings, normalizeSettings, withSelectionInstructions } from '../extension/settings.js';
test('legacy defaults become Luna and Low; explicit choices and site overrides survive', async () => {
  let saved = { model: '', sites: {} };
  globalThis.chrome = { storage: { local: { get: async () => ({ settings: saved }) } } };
  assert.equal((await readSettings()).model, 'gpt-6-luna');
  assert.equal((await readSettings()).effort, 'low');
  saved = { model: 'gpt-5.5', effort: 'high', sites: { 'example.com': { model: '', effort: '' } } };
  assert.equal((await readSettings()).model, 'gpt-5.5');
  assert.equal((await readSettings()).effort, 'high');
  assert.equal((await readSettings('example.com')).model, 'gpt-6-luna');
  assert.equal((await readSettings('example.com')).effort, '');
  const normalized = normalizeSettings(await readSettings());
  assert.equal(normalized.effort, 'high');
  assert.notDeepEqual(normalized, normalizeSettings({ ...normalized, effort: 'low' }), 'Cache input must distinguish effort');
  saved = { model: 'gpt-5.6-luna', effort: 'none', sites: { 'example.com': { model: 'gpt-5.6-sol', effort: 'high' } } };
  assert.equal((await readSettings()).model, 'gpt-6-luna');
  assert.equal((await readSettings()).effort, 'low');
  assert.equal((await readSettings('example.com')).model, 'gpt-6-sol');
  assert.equal((await readSettings()).sites['example.com'].model, 'gpt-6-sol');
  assert.equal((await readSettings('example.com')).effort, 'high');
  delete globalThis.chrome;
});

test('selection instructions are added after the general instructions', () => {
  assert.equal(withSelectionInstructions('Translate naturally.', '  Keep EFS in English. '), 'Translate naturally.\n\nFor this selected text: Keep EFS in English.');
  assert.equal(withSelectionInstructions('Translate naturally.', ''), 'Translate naturally.');
  assert.equal(withSelectionInstructions('', 'Be casual.'), 'For this selected text: Be casual.');
  assert.throws(() => withSelectionInstructions('x'.repeat(7990), 'Keep EFS in English.'), /too long/);
});
