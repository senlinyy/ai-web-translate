import test from 'node:test';
import assert from 'node:assert/strict';
import { TranslationStream, RequestPool } from '../companion/stream.mjs';
import { PageTranslations } from '../extension/page-translations.js';
import { CONCURRENCY } from '../extension/batch-plan.js';
const blocks = Array.from({ length: 28 }, (_, i) => ({ id: 'b' + i, text: 'Source ' + i + ' article text'.repeat(40) }));
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const cache = () => ({ writes: 0, async get() { return null; }, async put() { this.writes++; } });

test('stream decodes arbitrary boundaries, escapes and braces without exposing partial text', () => {
  const rows = [{ id: 'b0', text: '引号 " and \\ newline\n {braces} 😀' }, { id: 'b1', text: 'Second' }], emitted = [];
  const stream = new TranslationStream(blocks.slice(0, 2), row => emitted.push(row));
  for (const char of JSON.stringify({ translations: rows })) stream.push(char);
  assert.deepEqual(emitted, rows);
  assert.throws(() => new TranslationStream(blocks, () => {}).push('{"translations":[{"id":"unknown","text":"bad"}]}'));
});

test('transport streams concurrent threads out of order for the UI to buffer; cache waits for completion', async () => {
  let active = 0, peak = 0, calls = 0, finished = 0;
  const store = cache(), shown = [];
  const service = new PageTranslations(store, async (input, signal, emit) => {
    active++; peak = Math.max(active, peak); calls++;
    const start = Number(input.blocks[0].id.slice(1));
    await delay(start === 0 ? 40 : 5);
    for (const block of input.blocks) { signal.throwIfAborted(); emit({ id: block.id, text: '译 ' + block.text }); }
    await delay(20); active--; finished++;
    return { translations: input.blocks.map(b => ({ id: b.id, text: '译 ' + b.text })) };
  });
  const result = await service.translate({ owner: 1, url: 'https://example.com', input: { blocks }, onProgress(rows) {
    assert.equal(store.writes, 0); assert.ok(finished < calls);
    shown.push(...rows.map(r => r.id));
    assert.equal(new Set(shown).size, shown.length);
  } });
  assert.equal(peak, CONCURRENCY.codex); assert.equal(calls, CONCURRENCY.codex); assert.equal(store.writes, 1);
  assert.equal(result.translations.length, blocks.length); assert.deepEqual(new Set(shown), new Set(blocks.map(b => b.id))); assert.notEqual(shown[0], "b0");
});

test('failure cancels sibling threads and does not cache partial translations', async () => {
  const store = cache(); let aborted = 0;
  const service = new PageTranslations(store, async (input, signal, emit) => {
    if (input.blocks[0].id === 'b0') { emit({ id: 'b0', text: 'Partial' }); await delay(10); throw new Error('provider failed'); }
    await new Promise((resolve, reject) => signal.addEventListener('abort', () => { aborted++; reject(signal.reason); }, { once: true }));
  });
  await assert.rejects(service.translate({ owner: 1, url: 'https://example.com', input: { blocks } }), /provider failed/);
  assert.equal(store.writes, 0); assert.equal(aborted, CONCURRENCY.codex - 1);
});

test('shared flight replays progress using each caller IDs', async () => {
  let calls = 0; const store = cache();
  const service = new PageTranslations(store, async (input, signal, emit) => {
    calls++; emit({ id: input.blocks[0].id, text: 'First' }); await delay(30);
    return { translations: input.blocks.map((b, i) => ({ id: b.id, text: i ? 'Other' : 'First' })) };
  });
  const input = { blocks: blocks.slice(0, 3).map((block, i) => ({ ...block, text: 'Shared source ' + i })) }, shown = [];
  const first = service.translate({ owner: 1, url: 'https://example.com', input });
  await delay(10);
  const second = service.translate({ owner: 1, url: 'https://example.com', input: { blocks: input.blocks.map((b, i) => ({ ...b, id: 'new' + i })) }, onProgress: rows => shown.push(...rows.map(r => r.id)) });
  await Promise.all([first, second]); assert.equal(calls, 1); assert.deepEqual(shown, ['new0', 'new1', 'new2']);
});

test('native pool bounds concurrent pages and cancels waiting work', async () => {
  const pool = new RequestPool(3); let active = 0, peak = 0;
  const work = () => pool.run(new AbortController().signal, async () => { active++; peak = Math.max(peak, active); await delay(20); active--; });
  const running = [work(), work(), work()]; const controller = new AbortController();
  const waiting = pool.run(controller.signal, () => assert.fail('Cancelled work ran'));
  controller.abort(); await assert.rejects(waiting, { name: 'AbortError' });
  await Promise.all([...running, work()]); assert.equal(peak, 3); assert.equal(pool.active, 0);
});
