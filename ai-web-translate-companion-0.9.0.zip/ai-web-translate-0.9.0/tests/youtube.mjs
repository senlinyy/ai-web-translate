import { chromium } from 'playwright';
import assert from 'node:assert/strict';
const browser = await chromium.launch({ channel: 'chromium', headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const fixture = `<style>body{font:18px system-ui;margin:0}ytd-watch-flexy{display:grid;grid-template-columns:900px 300px;gap:30px}ytd-watch-metadata{display:block}#title{height:50px}#description{background:#eee;padding:12px}#snippet{max-height:65px;overflow:hidden}#secondary{grid-column:2;grid-row:1/3}#secondary a{display:block;height:70px}#comments{margin-top:30px}#owner,#actions{display:flex;height:55px;gap:20px}</style>
  <ytd-watch-flexy><ytd-watch-metadata><div id="title"><h1><yt-formatted-string>The last IMO problem AI could not solve</yt-formatted-string></h1></div>
  <div id="owner">3Blue1Brown <button>Subscribe</button><span>1.9m views</span></div><div id="actions"><button>Like</button><button>Share</button><button>More</button></div>
  <div id="description"><div id="description-inner"><span>1.9m views 4 days ago</span><ytd-text-inline-expander><div id="snippet"><span id="snippet-text"><yt-attributed-string id="attributed-snippet-text"><span>A beautiful puzzle that eluded AI, and the intuition it requires. <a href="#">https://example.com</a></span></yt-attributed-string></span></div><button>...more</button></ytd-text-inline-expander></div></div></ytd-watch-metadata>
  <div id="secondary"><a class="ytLockupMetadataViewModelTitle" href="#">Testing Viral AI 3D Products</a><a class="ytLockupMetadataViewModelTitle" href="#">The paradox at the heart of AI</a><span>342k views</span></div>
  <div id="comments"><h2>1,494 Comments</h2><button>Sort by</button><input placeholder="Add a comment"><ytd-comment-view-model><span>Pinned by @3blue1brown</span><yt-attributed-string id="content-text">Here is that guest post I referenced on Terry Tao's blog.</yt-attributed-string><button>Read more</button></ytd-comment-view-model></div></ytd-watch-flexy>`;
  await page.route('https://www.youtube.com/watch?v=test', route => route.fulfill({status:200,contentType:'text/html',body:fixture}));
  await page.goto('https://www.youtube.com/watch?v=test');
  await page.evaluate(() => {
    window.sourceNodes = [...document.querySelectorAll('h1 yt-formatted-string,#attributed-snippet-text,#content-text')];
    window.requests = [];
    window.chrome = { runtime: { onMessage: { addListener(fn) { window.listener = fn; } }, async sendMessage(message) {
      if (message.type === 'cancel') return { ok: true, result: {} };
      requests.push(message);
      return { ok: true, result: { translations: message.blocks.map(b => ({ id: b.id, text: '译 ' + b.text })) } };
    } } };
    window.command = m => new Promise(resolve => listener(m, {}, resolve));
    window.before = ['#title','#owner','#actions','#secondary a','#snippet'].map(sel => ({sel,height:document.querySelector(sel).getBoundingClientRect().height,top:document.querySelector(sel).getBoundingClientRect().top}));
  });
  await page.addScriptTag({path:'extension/content.js'});
  await page.evaluate(() => command({type:'start'}));
  await page.waitForFunction(() => document.querySelector('#comments #content-text + [data-codex-translation]'));
  const requested = await page.evaluate(() => requests.flatMap(r => r.blocks.map(b => b.text)));
  assert(requested.some(t => t.includes('IMO problem')));
  assert(requested.some(t => t.includes('A beautiful puzzle')));
  assert(requested.some(t => t.includes('guest post')));
  assert(requested.some(t => t.includes('Testing Viral AI')));
  for (const noise of ['Subscribe','Like','Share','More','1.9m views','4 days ago','Sort by','342k views','Read more']) assert(!requested.includes(noise), `Unwanted YouTube chrome: ${noise}`);
  assert.equal(await page.locator('#secondary [data-codex-translation]').count(), 2);
  assert.equal(await page.locator('#description #snippet [data-codex-translation]').count(), 0,'Translation must sit outside YouTube’s clipped preview');
  assert.equal(await page.locator('#description ytd-text-inline-expander + [data-codex-translation]').count(),1);
  assert(await page.evaluate(() => before.every(({sel,height,top})=>{const r=document.querySelector(sel).getBoundingClientRect();return r.height===height && (sel==='#secondary a' ? r.top===top : true)})), 'Controls, thumbnails and collapsed description keep their geometry');
  assert.equal(await page.locator('#comments #content-text + [data-codex-translation]').count(),1);
  await page.evaluate(() => document.querySelector('#comments').insertAdjacentHTML('beforeend','<ytd-comment-view-model><yt-attributed-string id="content-text">A newly loaded thoughtful comment.</yt-attributed-string></ytd-comment-view-model>'));
  await page.waitForFunction(() => document.querySelectorAll('#comments #content-text + [data-codex-translation]').length === 2);
  await page.evaluate(() => command({type:'restore'}));
  assert.equal(await page.locator('[data-codex-translation]').count(),0);
  assert(await page.evaluate(() => sourceNodes.every(n => n.isConnected)));
  console.log('YouTube watch regression passed: title, description, comments and recommendations translated; controls excluded; clipped preview and layout preserved; new comments handled; exact restore.');
} finally {await browser.close();}
